


print("Create Task Calculator: ") #Write title for code
print() #Creates blank space between lines
print() #Add a space between lines



def acquireData(inNumberList):
   listamount=float(input("Please enter how many numbers you want to work with: "))
   print()
   while(listamount>len(inNumberList)):
       listvalue=float(input("Please enter one of your numbers: "))
       inNumberList.append(listvalue)
   print()
   print()
   return inNumberList




def doCalulate(numberlist, calculatortask):


      if (calculatortask==1):
          print("You chose the add task!")

          sumvalue=0
          for ele in range(len(numberlist)):
              sumvalue=sumvalue+numberlist[ele]

          print("The sum of all the numbers entered:",sumvalue)
          print()
          print()


      if(calculatortask==2):
          print("You chose the subtract task!")

          differencevalue=numberlist[0]
          for ele in range(1,len(numberlist)):
              differencevalue=differencevalue-numberlist[ele]

          print("The difference of all the numbers entered:",differencevalue)
          print()
          print()

      
      if(calculatortask==3):
          print("You chose the multiply task: ")

          multiplyvalue=1
          for ele in range(len(numberlist)):
                multiplyvalue=multiplyvalue*numberlist[ele]

          print("The product of all the numbers entered:",multiplyvalue)
          print()
          print()


      if(calculatortask==4):


         print("You chose the divide task: ")
     
         dividevalue=numberlist[0]
         for ele in range(1,len(numberlist)):
           dividevalue=dividevalue/numberlist[ele]
          
         print("The quotient of all the numbers entered:",dividevalue)
         print()
         print()




def menu():
   tasknumber=0


   while(tasknumber!=5):


       numList=[]
       tasknumber=float(input("1.Add\n2.Subtract\n3.Multiply\n4.Divide\n5.Quit Calculator\n\nPlease enter what the number based on what task you want to do: "))
       print()
            
       if(tasknumber!=5):
           acquireData(numList)

           doCalulate(numList, tasknumber)

       print()
       print()


   print("Thank you for using the calculator!")   





menu()

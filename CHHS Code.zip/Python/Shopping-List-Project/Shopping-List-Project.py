



print("Python Shopping List: ") #Write title for code
print("Ayush Bindal 3rd Period AP CSP") #Write Name, Class Period, and Class
print() #Creates blank space between lines
print() #Add a space between lines



def additem(inShopList): #Creates additem function that takes in the shopping list as a parameter to have an item added to it
   additemvalue=input("Please enter what you want to add to your shopping list: ") #Allows user to enter value for additemvalue
   print() #Creates blank space between lines
   inShopList.append(additemvalue) #Adds additemvalue which user entered to the end of the shopping list




def removeitem(inShoplist): #Creates removeitem function that takes in the shopping list as a paramter to have an item removed from it
   removeitemvalue=input("Please enter what you want to remove from your shopping list: ") #Allows user to enter value for removeitemvalue
   print() #Creates blank space between lines


   while(removeitemvalue not in inShoplist): #Runs the following code until the statement becomes false. This means that the user enetered a value that was in their shopping list that can be removed
       print(removeitemvalue,"was not in your shopping list") #Prints following statement
       print("This is your list:",inShoplist) #Prints following statement
       removeitemvalue=input("Please enter what you want to remove from your shopping list: ") #Allows user to renter what they want to remove from the list
       print() #Creates blank space between lines


   inShoplist.remove(removeitemvalue) #Removes the item the user entered in removeitemvalue from the list
   




def printlist(inShoplist): #Creates printlist function that takes the shopping list in as a parameter prints out what is in the shopping list
    print("Your shopping list:",inShoplist) #Prints out following statement with shopping list
    print() #Creates blank space between lines




def menu(): #Creates menu function that runs what the user wants to do
   shoppinglist=[] #Creates an empty shopping list for the user to add or remove items from
   shoppinglisttask=0
   while(shoppinglisttask!=4): #Allows the indented code to repeat allowing the user to continue doing tasks until the following statement is true which means they want to exit the program



     shoppinglisttask=float(input("\n1. Add Item to List \n2. Remove Item from List \n3. Print Items in List \n4. Exit Creating Your List \nEnter the number that corresponds to an action: ")) #Allows user to enter number that cooresponds to a certain task that the menu will do and is assigned to the shoppinglisttask variable



     while (shoppinglisttask<1 or shoppinglisttask>4): #Does the indented code until the boolean statement becomes false. This means the user entered a number that does not correpsond with any task.
         print() #Creates blank space between lines
         print("You did not enter a number that cooresponds with the options avilable") #Prints out the following statement
         shoppinglisttask=float(input("1. Add Item to List \n2. Remove Item from List \n3. Print Items in List \n4. Exit Creating Your List \nEnter the number that corresponds to an action: ")) #Allows user to reenter a number to run one of the tasks
         print() #Creates blank space between lines



     if (shoppinglisttask==1): #If the statement is true the following code will run
         additem(shoppinglist) #Runs the additem function with the shoppinglist list as a parameter



     if (shoppinglisttask==2): #If the statement is true the following code will run
         removeitem(shoppinglist) #Runs the removeitem function with the shoppinglist list as a parameter



     if (shoppinglisttask==3): #If the statement is true the following code will run
         printlist(shoppinglist) #Runs the printitem function with the shoppinglist list as a parameter




menu() #Runs the menu function 




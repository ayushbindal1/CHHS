print("Python String Program") #Write title for code
print("Ayush Bindal 3rd Period AP CSP") #Write Name, Class Period, and Class


Stringvalue= input("Please enter a five character string or longer: ") #Prints out following statement and allows for user to enter a string


Stringvaluelength=len(Stringvalue) #Measures length of string user entered

print("Length of the string entered:",Stringvaluelength) #Prints out following statement


print("String of first two and last two characters:",Stringvalue[0:2]+Stringvalue[(Stringvaluelength-2):(Stringvaluelength)]) #Prints out following statement with first two characters and last two characters


firstcharacter=Stringvalue[0] ##Stores value of first character in String
endcharacter=Stringvalue[Stringvaluelength-1] ##Stores value of last character in String
middlecharacters=Stringvalue[1:Stringvaluelength-1] ##Stores middle values exluding the first and last character of the String
print("First and last character swapped:",endcharacter+middlecharacters+firstcharacter) #Prints out following statement


Stringend=(Stringvalue[Stringvaluelength-3:Stringvaluelength]) #Stores value of last three characters of the String the user entered. This can be used to see if the String ends in ing or not
if(Stringend!="ing"): #If the following statement is true than the statement below prints
  print("String entered + ing:",Stringvalue+"ing") # If the If statement is true than the following command prints adding ing.
else: #Prints the following statement if the String ends in ing
  print("String entered + ly:",Stringvalue+"ly") #If the If statement is false than the following command prints ending ly to the ing word.

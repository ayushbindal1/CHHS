print("Python Lists and Loops: ") #Write title for code
print("Ayush Bindal 3rd Period AP CSP") #Write Name, Class Period, and Class
print() #Creates blank space between lines
print() #Add a space between lines



print("1. Create the list [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] starting with an empty list and using append and a loop.") #Prints out instructions
list1=[] #Creates empty list
list1i=1 #Creates variable to store the index of the first list
while list1i<=10: #While the statement is true the following code will run
  list1.append(list1i) #Adds index value to end of the list
  list1i+=1 #Increases the index of the first list by 1
print(list1) #Prints out the new first list
print() #Add a space between lines
print() #Add a space between lines



print("2.Write a loop that creates the list [-5,-3,-1,1,3,5,7,9] by starting with an empty list and using append.") #Prints out instructions
list2=[] #Creates empty list
list2i=-5 #Creates variable to store the index for the second list
while list2i<=9: #While the statement is true the following code will run
  list2.append(list2i) #Adds index value to end of list 
  list2i+=2 #Increases the value of the index by 2
print(list2) #Prints out new second list
print() #Add a space between lines
print() #Add a space between lines



print("3.Use a loop to add up the values in one of the previous lists. You will need a separate variable that starts at zero to hold the sum.") #Prints out instructions
sumvalue=0 #Sets sum value variable to zero to calculate the sum of all the numbers in the list
list1i=0 #Sets the index of the first list back to zero
while list1i<len(list1): #While the index is less than the length of the first list the following code will run
  sumvalue+=list1[list1i] #Adds value located in index to the sumvalue
  list1i+=1 #Increases value of the index by 1 
print("Sum value of list 1:",sumvalue) #Prints out following statement
print() #Add a space between lines
print() #Add a space between lines



print("4.Use a loop to print out all of the values that are larger than 5 in one of the previous loops. You will have an if statement in your loop.") #Prints out instructions
print() #Add a space between lines
list1i=0 #Sets value of index for first list back to zero
while list1i<len(list1): #While the index is less than the length of the first list the following code will run 
  if (list1[list1i]>5): #If the value at the index of list 1 is greater than 5 the following code will run
    print("Value in list 1 greater than 5:",list1[list1i]) #Prints value greater than 5
  list1i+=1 #Increases value of index by 1
print() #Add a space between lines
print() #Add a space between lines



print("5.Use a loop to remove all of the instances of an inputted number from a list (Hint: Start from the back to avoid skipping over values when you remove.)") #Prints out instructions
print() #Add a space between lines
list3=[3,7,9,10,13,9,15,10,13,15,19,19,20,32,35,3] #Creates new list
list3i=len(list3)-1
print("Values of list 3:",list3) #Prints out following statement 
print() #Add a space between lines
userremovevalue=float(input("Please enter a number that you would like to remove from list 3: ")) #Prints out instructions and allows user to enter number to remove from list3
while (list3i>=0):#While the index is greater than or equal to zero the following code runs
  if(list3[list3i]==userremovevalue): #If the value of the list at the index is equal to the value the user wants to remove the following code runs
   del list3[list3i] #Removes the value at the index which contained the number the user wanted to remove
  list3i-=1 #Decreases the index by 1 
print("New values of list 3:",list3) #Prints out following statement
print() #Add a space between lines
print() #Add a space between lines



print("6.Use a loop to change all negative values in a list to positive values. You will need an if statement in your loop.") #Prints out instructions
list4=[-5,-3,-5,3,6,7,8,2,-5,10,-13,-99,32] #Creates new list
print("List 4 values:",list4) #Prints out list 4
list4i=0 #Sets index of list 4 to 0
while (list4i<len(list4)): #While the index is less than the length of the first list the following code will run 
  if(list4[list4i]<0): #If the value at the index is less than zero or negative the code will run
   list4[list4i]*=-1 #Multiplies value of index by -1 to convert to a postive number
  list4i+=1 #Increases the index by 1 
print("New values of list 4:",list4) #Prints out following statement
print() #Add a space between lines
print() #Add a space between lines



print("7.Use a loop to multiply all of the values in a list by a user inputted value.") #Prints out instructions
list5=[23,89,67,3,4,5,675,33,9,-5,-15,20] #Creates new list
print("List 5 values:",list5) #Prints out following statement
print() #Add a space between lines
list5i=0 #Sets index to zero
usertimesvalue=(float(input("Please enter a value that you would like to multiply the list by: "))) #Gives instructions and allows user to enter value to mutliply index value
while(list5i<len(list5)): #While the index is less than the length of the first list the following code will run 
  list5[list5i]*=usertimesvalue #Multiplies the value at the index by value user entered
  list5i+=1 #Increases the index by 1 
print("New values of list 5 values:",list5) #Prints out following statement 
print() #Add a space between lines
print() #Add a space between lines


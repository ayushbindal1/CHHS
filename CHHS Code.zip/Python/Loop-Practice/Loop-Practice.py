print("Python Loops ") #Write title for code
print("Ayush Bindal 3rd Period AP CSP") #Write Name, Class Period, and Class
print() #Creates blank space between lines



print("1. First Ten Powers:" ) #Prints title for program
base=float(input("Please enter a number: ")) #Prints instructions for user and allows user to enter a float value
exponent=1 #Sets exponent value to 1 to start with base^1

while (exponent<11): #Does following code until the exponent value is greater than 11. This will display the first 10 exponents of base the user entered
 raisedvalue=base**exponent #Calculates the value of the base raised to the xponent
 print("The value of the base raised to the",exponent,"power:",raisedvalue) #Prints following statement
 exponent+=1 #Increases the value of the exponent by one
print() #Creates blank space between lines



print("2. Loan Amount: ") #Prints title for program
loanamount=float(input("Please enter the amount of the loan: ")) #Prints instructions for user and allows user to enter a float value for the loan amount
monthlypayment=float(input("Please enter the amount of the monthly payment: ")) #Prints instructions for user and allows user to enter a float value for the monthly payment
monthspassed=0 #Sets the value of the months passed to zero to track how many months have passed and how much money still needs to be paid

while(loanamount>0): #Does the following code until the loan amount is less than or equal to zero. This means that the loan has been fully paid off
  print("Loan value after",monthspassed,"month(s) have passed:",loanamount) #Prints out the following statement
  loanamount-=monthlypayment #Subtracts the monthly payment from the loanamount to show how much money still needs to be paid off
  monthspassed+=1 #Adds 1 to monthspassed variable 
print("Loan value after",monthspassed,"month(s) have passed:","0") #Prints out the following statement
print() #Creates blank space between lines



print("3. Less Than or Equal To: " ) #Prints title for program
greaterthanzero=float(input("Please enter any number greater than zero: ")) #Prints instructions and allows user to enter a value to be subtracted
while(greaterthanzero<0): #Does following code if the user does not enter a number greater than zero and does so until the user enters a number greater than zero
 print("You did not enter a number greater than zero.") #Prints out following statement
 greaterthanzero=float(input("Please enter any number greater than zero: ")) #Prints instructions and allows user to enter a value to be subtracted

while(greaterthanzero>0): #Does following code until the value the user entered is less than zero
 print(greaterthanzero) #Prints out the variable the user entered
 greaterthanzero-=1 #Decreases the variable the user entered by one which goes back into the loop to be compared until it is less than zero.


 
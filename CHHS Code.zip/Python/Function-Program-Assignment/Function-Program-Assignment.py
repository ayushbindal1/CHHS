from random import randint
import math



print("Python Lists and Loops: ") #Write title for code
print("Ayush Bindal 3rd Period AP CSP") #Write Name, Class Period, and Class
print() #Creates blank space between lines
print() #Add a space between lines



def function1():
   randomvalue=randint(1,10)
   return randomvalue



def average(numaverage1, numaverage2, numaverage3):
   return (numaverage1+numaverage2+numaverage3)/3>50



def closeto20(num1, num2):
   num1to20=abs(20-num1)
   num2to20=abs(20-num2)
   if(num2to20>num1to20):
       return num1
   else: 
       return num2



def functionfour(userstringvalue1):
   newstringvalue=userstringvalue1[0:2]+userstringvalue1[-2:]
   return newstringvalue



def functionfive(userstringvalue2):
   middleindex=math.floor(len(userstringvalue2)/2)
   charatmid=userstringvalue2[middleindex]
   return charatmid



def driver():


   print("1. A function with no parameters that returns a random statement. Generate a random number between 1 and 10, and return a different message for each number.")
   print("The random value:",function1())
   print()
   print()


   print("2. A function that takes a three numbers as parameters and returns true if the average is over 50, false otherwise.")
   numaverage1=float(input("Please enter your first number to average: "))
   numaverage2=float(input("Please enter your second number to average: "))
   numaverage3=float(input("Please enter your third number to average: "))
   print("Is the average greater than 50:",average(numaverage1,numaverage2,numaverage3))
   print()
   print()


   print("3. A function that takes 2 numerical parameters and returns the one that's closest to 20 (use absolute value of the difference)")
   num1=float(input("Please enter the first number to compare to 20: "))
   num2=float(input("Please enter the second number to compare to 20: "))
   print("The number closest to 20:",closeto20(num1,num2))
   print()
   print()


   print("4. A function that takes a string as a parameter and returns a new string made up of the first two characters added to the last two characters.")
   userstringvalue1=input("Please enter a string value: ")
   print("The first and last two characters:",functionfour(userstringvalue1))
   print()
   print()


   print("5. A function that takes a string as a parameter and returns the character in the middle of the String. If the length is even, either middle character can be returned.")
   userstringvalue2=input("Please enter a string value: ")
   print("The middle character of the string entered:",functionfive(userstringvalue2))
   print()
   print()



driver()



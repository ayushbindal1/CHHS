
print("Function Practice: ") #Write title for code
print("Ayush Bindal 3rd Period AP CSP") #Write Name, Class Period, and Class
print() #Creates blank space between lines
print() #Add a space between lines




def averagegrade(testgrade1, testgrade2, testgrade3, testgrade4, testgrade5): #Creates new function with 5 parameters for each test grade
    averagetestgrade=(testgrade1+testgrade2+testgrade3+testgrade4+testgrade5)/5 #Calculates the average of the five test grades that were parameters
    return averagetestgrade #Returns the averagetestgrade variable




def driver(): #Creates driver function which runs rest of the program


    testgrade1=float(input("Please enter your first test grade: ")) #Allows the user to enter their first test grade
    testgrade2=float(input("Please enter your second test grade: ")) #Allows the user to enter their second test grade
    testgrade3=float(input("Please enter your third test grade: ")) #Allows the user to enter their third test grade
    testgrade4=float(input("Please enter your fourth test grade: ")) #Allows the user to enter their fourth test grade
    testgrade5=float(input("Please enter your fifth test grade: ")) #Allows the user to enter their fifth test grade
    averagegrade(testgrade1,testgrade2,testgrade3,testgrade4,testgrade5) #Calls the averagegrade function with five values the user entered
    print() #Creates blank line



    while((averagegrade(testgrade1,testgrade2,testgrade3,testgrade4,testgrade5))<70): #While the statement is true the following code runs allowing the user to retake the class


        print("Sorry, you failed the class with an average of",averagegrade(testgrade1,testgrade2,testgrade3,testgrade4,testgrade5)) #Prints out following statement
        print()
        testgrade1=float(input("Please enter your first test grade after retaking the class: ")) #Allows the user to re-enter their first test grade
        testgrade2=float(input("Please enter your second test grade after retaking the class:  ")) #Allows the user to re-enter their second test grade
        testgrade3=float(input("Please enter your third test grade after retaking the class:  ")) #Allows the user to re-enter their third test grade
        testgrade4=float(input("Please enter your fourth test grade after retaking the class:  ")) #Allows the user to re-enter their fourth test grade
        testgrade5=float(input("Please enter your fifth test grade after retaking the class:  ")) #Allows the user to re-enter their fifth test grade
        print() #Creates blank line


    if ((averagegrade(testgrade1,testgrade2,testgrade3,testgrade4,testgrade5))>70 or (averagegrade(testgrade1,testgrade2,testgrade3,testgrade4,testgrade5))==70 ): #If statement is true which means average is greater than 70 following code runs
        print("Great job, you passed the class with an average of",averagegrade(testgrade1,testgrade2,testgrade3,testgrade4,testgrade5)) #Prints out following statement
        print() #Creates blank line



driver() #Calls driver function which runs rest of program
print("Python If Statement") #Write title for code
print("Ayush Bindal 3rd Period AP CSP") #Write Name, Class Period, and Class


print("Have the user enter in three test grades. If their average is over a 90, tell them that they made the honor roll.") #Prints instructions for user

testgrade1=float(input("Please enter your first test grade: ")) #Prints instructions for user and allows user to enter float value for test grade.
testgrade2=float(input("Please enter your second test grade: ")) #Prints instructions for user and allows user to enter float value for test grade.
testgrade3=float(input("Please enter your third test grade: ")) #Prints instructions for user and allows user to enter float value for test grade.

testaverage=(testgrade1+testgrade2+testgrade3)/3 #Calculates average of test scores

if(testaverage>90): #If the average is above 90 the statement below prints out
 print("You made the honor roll, congrats! Your average was:",testaverage) #Prints out statement if If statement is true.
else: #If the average is below 90 the statement below prints out
 print("You did not make the honor roll, sorry! Your average was:",testaverage) #Prints out statement if If statement is true
print() #Adds empty line/space


print("Have the user type in three real numbers (use float instead of int). Tell the user if the sum of the numbers is greater than 100 and if the product of the numbers is greater than 1000.") #Prints out instructions for user

realnum1=float(input("Please enter your first real number: ")) #Prints instructions for user and allows user to enter float value for a real number.
realnum2=float(input("Please enter your second real number: ")) #Prints instructions for user and allows user to enter float value for a real number.
realnum3=float(input("Please enter your third real number: ")) #Prints instructions for user and allows user to enter float value for a real number.

realnumsum=(realnum1+realnum2+realnum3) #Calculates sum of real numbers entered
realnumproduct=(realnum1*realnum2*realnum3) #Calculates product of real number entered

if (realnumsum>100): #If the sum of the real numbers is greater than 100 the following statement prints out
  print("The sum of the three numbers is greater than 100. The sum was",realnumsum) #Prints out the statement if the If statement is true.
else: #If the sum of the real numbers is less than 100 the following statement prints out
  print("The sum of the three numbers is less than 100. The sum was",realnumsum) #Prints out the statement if the If statement is not true

if(realnumproduct>1000): #If the product of the real numbers is greater than 1000 the following statement prints out
  print("The product of the three numbers is greater than 1000. The prodcut was",realnumproduct) #Prints out the statement if the If statement is true.
else:  #If the product of the real numbers is less than 1000 the following statement prints out
  print("The product of the three numbers is less than 1000. The prodcut was",realnumproduct) #Prints out the statement if the If statement is not true
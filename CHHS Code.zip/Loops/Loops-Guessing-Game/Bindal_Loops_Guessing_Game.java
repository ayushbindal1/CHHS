import java.util.Scanner;

class Main {
 public static void main(String[] args) {

 
 System.out.println(""); //Add space between lines.
 System.out.println("Loops Guessing Game"); //Write title for code
 System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class

 System.out.println(""); //Add space between lines.


 /* Loops Guessing Game Psuedocode
 Get Information:
 1.1 Have the user enter a username
 1.2 Have the user enter a difficulty 1 being easy and 2 being hard
 1.3 If the user chose 1 in 1.2 have the user enter a number between 1 and 50
 1.4 If the user chose 2 in 1.2 have the user enter a number between 1 and 500
 1.5 Repeat 1.3 until the value in 1.3 is equal to the value in 2.1
 1.6 Repeat 1.4 until the value in 1.4 is equal to the value in 2.2 
 1.7 If the value the user entered in 1.3 is equal to the value found in 2.1 have the user enter 1 or 2 to repeat or end the game, respectively.

 Do Calculations:
 2.1 If the user entered 1 in 1.2 for the difficulty create a random number from 1 to 50
 2.2 If the user entered 2 in 1.2 for the difficulty create a random number from 1 to 500
 2.3 Each time the user guesses increase the attempts variable by 1 for their score on both easy and hard

 Print Results:
 3.1 If the value the user guessed in 1.3 is greater than the number in 2.1 state that the number in 1.3 is greater than 2.1. Print their score found in 2.3
 3.2 If the value the user gussed in 1.3 is less than the number in 2.1 state that the number in 1.3 is greater than 2.1.  Print their score found in 2.3
 3.3 If the value the user entered in 1.3 is outside the range created in 2.1 tell the user that it is
 3.4 If the value the user guessed in 1.4 is greater than the number in 2.2 state that the number in 1.4 is greater than 2.2.  Print their score found in 2.3
 3.5 If the value the user gussed in 1.4 is less than the number in 2.2 state that the number in 1.4 is greater than 2.2.  Print their score found in 2.3
 3.6 If the value the user entered in 1.4 is outside the range created in 2.2 tell the user that it is.
 3.7 If the value the user entered in 1.4 is equal to the value in 2.2 tell the user the value in 2.2 and that they have found the number. Also tell the score calculated in 2.3
 3.8 If the value the user entered in 1.7 is 1 than repeat 1.1-3.4 If it is equal to 2 print that the game is over.
 */


 int replaygame=0; //Clear and create variable to store information
 String username=""; //Clear and create variable to store information


 do{ //Create a do while loop 
 int gamemodedifficulty; //Creates new variable to store information
 int easymodenumber=0; //Clear and create variable to store information about number user has to guess for easy mode.
 int easymodeguess; //Creates variable to store information about the user's guess for easy mode.
 int attemptstaken=0; //Clear and create variable to store information
 int hardmodenumber=0; //Clear and create variable to store information about number user has to guess for hard mode.
 int hardmodeguess; //Creates variable to store information about the user's guess for hard mode.
 Scanner guessinggame= new Scanner(System.in); //Create a new scanner
 
 System.out.println("In this game you will be given the option between easy and hard. Depending on what you choose it will create a range of numbers and choose one specific number for you to guess. It will tell you if you are too high or too low. It will also record your score (How many attempts it took for you to guess correctly) once you have guessed the correct number. Be sure to enter a number in the right range. You can always play again if you are right. Good Luck!"); //Print out instructions for game.
 System.out.println(""); //Add space between lines.
 System.out.print("Please enter a username: "); //Print out instructions for what the user should enter
 username=guessinggame.nextLine(); //Allows the user to enter their username and stores it.
 System.out.print("Choose your difficulty: Easy (1) or Hard (2): "); //Print out instructions for what the user should enter
 gamemodedifficulty=guessinggame.nextInt(); //Allow the user to enter difficulty and stores it.
 guessinggame.nextLine(); //Reads next line to gather all the data including the enter button.
 System.out.println(""); //Add space between lines.


 if(gamemodedifficulty == 1) //If the statement is true the program in brackets will run the easy version of the game.
  {
   System.out.println( username+" you chose the easy difficulty."); //Print out what difficulty the user chose.
   System.out.println( username+" you has to guess a number between 1 and 50"); //Print out instructions for what the user has to guess.

   easymodenumber=((int)((Math.random()*50)+1)); //Creates a random number between 1 and 50 for the easy mode. 


   System.out.print("Please guess a number between 1 and 50: "); //Prints out instructions for what the user should enter
   easymodeguess=guessinggame.nextInt(); //Allows the user the enter a value for their first guess.
   System.out.println(""); //Add space between lines.
   attemptstaken++; //Increases the variable attempts taken by 1 which is used for the score.
   do { //Creates a do while loop
    

    if(easymodeguess>easymodenumber && easymodeguess<=50 && easymodeguess>=1) //If the value the user entered is larger than the number the user has to guess and is inside the parameters the code below will print out.
     {
       System.out.print(username+" you guessed "+easymodeguess+". That number was too large, guess a smaller number between 1 and 50: "); //Prints out following statement and instructions
       easymodeguess=guessinggame.nextInt(); //Allows the user to enter another value for their guess.
       attemptstaken++; //Increases the variable attempts taken by 1 which is used for the score.
       System.out.println(username+" has taken "+attemptstaken+" attempts so far."); //Prints out following statement
       System.out.println(""); //Add space between lines.
     }


     if(easymodeguess<easymodenumber && easymodeguess<=50 && easymodeguess>=1) //If the value the user entered is smaller than the number the user has to guess and is inside the parameters the code below will print out. 
      {
        System.out.print(username+" you guessed "+easymodeguess+". That number was too small, guess a larger number between 1 and 50: "); //Prints out following statement and instructions
        easymodeguess=guessinggame.nextInt(); //Allows the user to enter another value for their guess.
        attemptstaken++; //Increases the variable attempts taken by 1 which is used for the score.
        System.out.println(username+" has taken "+attemptstaken+" attempts so far."); //Prints out following statement
        System.out.println(""); //Add space between lines.
      }


      if(easymodeguess>50 || easymodeguess<1) //If either statement is true than following code below prints out. States that user went outside the range.
      {
        System.out.print(username+" you did not enter a number bewteen 1 and 50. Please enter a number between 1 and 50: "); //Prints out following statement and instructions
        easymodeguess=guessinggame.nextInt(); //Allows the user to enter another value for their guess.
        System.out.println(""); //Add space between lines.
      }
  

    } while(easymodeguess != easymodenumber); //Contiunes to do the loop until the value the user entered is the same as the random number the user has to guess. This means that the user guessed the correct value and does not need to try again anymore.


   System.out.println("Congratulations "+username+" you guessed the correct number. The number was "+easymodenumber+", Great Job!"); //Prints out following statement
   System.out.println(username+" you took "+attemptstaken+" attempts."); //Prints out following statement about user score
   System.out.println(""); //Add space between lines.
   System.out.print("Would you like to play again "+username+"? Yes(1) No(Any other number): "); //Prints out following statement and instructions.
   replaygame=guessinggame.nextInt(); //Allows the user to enter a value to determine if they want to replay the game
  }










 if(gamemodedifficulty == 2) //If the statement is true the program in brackets will run the hard version of the game.
  {
   System.out.println( username+" chose the hard difficulty."); //Print out what difficulty the user chose.
   System.out.println( username+" has to guess a number between 1 and 500"); //Print out instructions for what the user has to guess.
   System.out.println(""); //Add space between lines.
   hardmodenumber=((int)((Math.random()*500)+1)); //Creates a random number between 1 and 500 for the hard mode. 


   System.out.print("Please guess a number between 1 and 500: "); //Prints out instructions for what the user should enter
   hardmodeguess=guessinggame.nextInt(); //Allows the user the enter a value for their first guess.
   System.out.println(""); //Add space between lines.
   attemptstaken++; //Increases the variable attempts taken by 1 which is used for the score.
   do //Creates a do while loop
    {
    

    if(hardmodeguess>hardmodenumber  && hardmodeguess<=500 && hardmodeguess>=1) //If the value the user entered is larger than the number the user has to guess and is inside the parameters the code below will print out.
     {
       System.out.print(username+" you guessed "+hardmodeguess+". That number was too large, guess a smaller number between 1 and 500: "); //Prints out following statement and instructions
       hardmodeguess=guessinggame.nextInt(); //Allows the user to enter another value for their guess.
       attemptstaken++; //Increases the variable attempts taken by 1 which is used for the score.
       System.out.println(username+" has taken "+attemptstaken+" attempts so far.");
       System.out.println(""); //Add space between lines.
     }


     if(hardmodeguess<hardmodenumber  && hardmodeguess<=500 && hardmodeguess>=1) //If the value the user entered is smaller than the number the user has to guess and is inside the parameters the code below will print out. 
      {
        System.out.print(username+" you guessed "+hardmodeguess+". That number was too small, guess a larger number between 1 and 500: "); //Prints out following statement and instructions
        hardmodeguess=guessinggame.nextInt(); //Allows the user to enter another value for their guess.
        attemptstaken++; //Increases the variable attempts taken by 1 which is used for the score.
        System.out.println(username+" has taken "+attemptstaken+" attempts so far."); //Prints out following statement
        System.out.println(""); //Add space between lines.
      }


      if(hardmodeguess>500 || hardmodeguess<1) //If either statement is true than following code below prints out. States that user went outside the range.
      {
        System.out.print(username+" you did not enter a number bewteen 1 and 50. Please enter a number between 1 and 500: "); //Prints out following statement and instructions
        hardmodeguess=guessinggame.nextInt(); //Allows the user to enter another value for their guess.
        System.out.println(""); //Add space between lines.
      }
  

    } while(hardmodeguess != hardmodenumber); //Contiunes to do the loop until the value the user entered is the same as the random number the user has to guess. This means that the user guessed the correct value and does not need to try again anymore.


   System.out.println("Congratulations "+username+" you guessed the correct number. The number was "+hardmodenumber+", Great Job!"); //Prints out following statement
   System.out.println(username+" you took "+attemptstaken+" attempts."); //Prints out following statement about user score
   System.out.println(""); //Add space between lines.
   System.out.print("Would you like to play again "+username+"? Yes(1) No(Any other number) "); //Prints out following statement and instructions.
   replaygame=guessinggame.nextInt(); //Allows the user to enter a value to determine if they want to replay the game.
   System.out.println(""); //Adds space between line.
  }
  } while (replaygame == 1); //Contiunes to run the program until the statement becomes false. This means that the user entered the number 2 which means that they do not want to continue playing.
 System.out.println("Thank you for playing!"); //Prints out following statement.

  }
}
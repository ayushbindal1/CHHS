import java.util.Scanner;
class Main {
 public static void main(String[] args) {

   System.out.println("While Loops Extra Credit");
   System.out.println("Ayush Bindal 5th Period PAP CS");
   Scanner whileloopextra= new Scanner(System.in);


   System.out.println("Write a program that generates 100 random numbers and prints out the sum and average of the numbers.");
    
   int randomamount=0;
   int sumvalue=0;
   int randomvalue;
   int randomaverage;

   while(randomamount<100)
    {
     randomvalue=(int)(Math.random()*101)+1000;
     System.out.println(randomvalue);
     sumvalue+=randomvalue;
     randomamount++;
     }
   randomaverage=sumvalue/100;
   System.out.println("The sum of all your numbers: "+sumvalue);
   System.out.println("The average of all your numbers: "+randomaverage);


   System.out.println("2. Write a program that reads in a string from the user. Print out the string with each letter on a separate line of output.");

   String uservalue;
   int lengthofstring;
   int postionatstring=0;

   System.out.print("Please enter a string value (Any word or phrase): ");
   uservalue=whileloopextra.nextLine();
   lengthofstring=(uservalue.length());

   while(lengthofstring!=postionatstring) 
    {
     System.out.println(uservalue.charAt(postionatstring));
     postionatstring++;
     }







     

  }
}
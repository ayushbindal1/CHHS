import java.util.Scanner;

class Main {
public static void main(String[] args) {
  Scanner whileloop=new Scanner(System.in); //Create a new scanner
  System.out.println("While Loops"); //Write title for code
  System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class

 
/* Power of 10 Psuedocode:
Get Information:
1.1 Have the user enter the variable basenumber. This is what the user wants to be raised to a certain exponetial value.
Do Calculations:
2.1 Raise 1.1 to the exponetial value 1
2.2 Change the value of the exponent by +1. This allows the value of the raisednumber to change.
2.3 Repeat 2.1 and 2.2 until the value of the exponent is greater than 10. 
Print Results:
3.1 Print the value of the raised number cacluated in 2.1
3.2 Print the value of the exponent that correlates for each raised number
3.3 Repeart 3.1 and 3.2 until the value of the exponent is greater than 10.
*/

 System.out.println("Power of 10"); //Write title for code

 double basenumber; //A double value that the user can enter a number. This is what is being raised to an exponent 10 times. This and the variable exponentvalue creates the raisednumber which shows the exponetial value.
 double raisednumber; // A double value that is calculated by raising the variable basenumber to the exponentvalue 10 times. This shows the number the user entered exponetial value.
 double exponentvalue; //A double value that starts a 1. This is what the basenumber variable is raised to in order to create the raisednumber. This number increases by 1 in order to show the first 10 powers of the basenumber. This is what is used in the loop to determine when to stop displaying new exponential values.

   System.out.println("Please enter a number: "); //Give instructions for what the user should enter
   basenumber=whileloop.nextDouble(); //Allow for the user to enter a double number which is the base for the exponent. This is what will be raised to a certain power.
   exponentvalue=1; //Sets the exponentvalue variable to 1 so that when the while loop starts it starts with raising the variable basenumber to the first power.

while(exponentvalue<11) //The program below will contiune to run until the statement becomes false. This occurs when the variable exponentvalue becomes greater than 10 meaning that the code has displayed over 10 exponent values.
 {
   raisednumber=Math.round(Math.pow(basenumber,exponentvalue)); //Calculates the value of the basenumber that the user entered raised to the  exponent value. 
   System.out.println("This is your number raised to the "+exponentvalue+" power: "+raisednumber); //Prints out what power the base has been raised to and what the total value is
   exponentvalue++; //Increases the value of the variable exponentvalue by 1. This allows the statement in line 21 and 20 to change as it has a new exponent value to calculate.
  }


/* Loan Calculator Psuedocode:
Get Information:
1.1 Have the user enter a variable for the amount they want as a loan.
1.2 Have the user enter a variable for the amount they want as a monthly payment
Do Calculations:
2.1 Take the value in 1.2 and subtract it from 1.1. This gives the total amount of the loan left to pay. Make this the new variable for the loan.
2.2 Change the monthly value by +1. This increaeses the amount of months that have passed.
2.3 Repeat 2.1 and 2.2 until the loan amount is less than zero or the loan has been paid off.
Print Results:
3.1 Print how many months have passed in 2.3 and how much of the loan is left in 2.1. 
3.2  Repeat 3.1 until the loan amount is less than zero or the loan has been paid off.
*/

 System.out.println("Loan Calculator"); //Write title for code

 double loanamount;// A double that the user enters. This is the amount that the user wants as a "loan". This is what the variable monthly payment is subtracting in order to "pay off the loan." This is what is used to determine when to stop the loop as once it reaches 0 the "loan" has been paid off.
 double monthlypayment; //A double that user enters. this is the amount that the user wants as a monthly payment. This is subtracted from the loan ammount in order to decrease it and "pay off the loan". This is a constant value that does not change.
 int monthspassed=1; //An integer value that tracks how many months have passed. This is used to show what month it is and how much of the loan has been payed back by a certain time. It starts at 1 to show how much has to be payed overall. This will change as the while loop progresses.

   System.out.println("Please enter an amount you would like for a loan."); //Give instructions for what the user should enter as a loan
   loanamount=whileloop.nextDouble();
    System.out.println("Please enter an amount you would like for a monthly payment."); //Give instructions for what the user should enter as a monthly payment
   monthlypayment=whileloop.nextDouble(); //Allows for the user to enter how much they will pay for their loan per month. 

while(loanamount>0) //The program below will contiune to run until the statement becomes false. This occurs when the variable loanamount becomes less than 0 meaning that the loan has been fully paid off based on the monthly payment.
{
   System.out.println("After "+monthspassed+" months have passed you still have to pay "+loanamount); //Prints out the number of months that have passed and how much of the loanamount variable is still left before it reaches 0.
   loanamount=(loanamount-monthlypayment); //This allows for the loanamount to be subtracted from the monthlypayment. This creates a new loanamount; This is what allows the loanamount variable to eventually reach 0. This loop will stop occuring once the while statement is true. 
   monthspassed++; //This increases the monthspassed variable by 1 to show how many months of payment have passed.
  }


/* Greater Than Zero Psuedocode:
Get Information:
1.1 Have the user enter a whole number.
Do Calculations:
2.1 Change the value of the whole number in 1.1 by -1.
2.2 Repeat 2.1 until the value of the whole number is less than zero.
Print Results:
3.1 Print out the value calcuated in 2.1 and the value the user entered in 1.1
3.2 Repeat 3.1 until the value of the whole number is less than zero.
*/

 System.out.println("Greater than Zero"); //Write title for code

 int greaterthanzero; //An integer value that the user enters. This is used to display all number less than itself but greater than zero. This is what is used to determine when the loop should stop. This is constantly being subtracted by one which is displaying all the numbers in the range.

   System.out.println("Please enter a whole number"); //Give instructions for what the user should enter
   greaterthanzero=whileloop.nextInt(); //Allows the user to enter an integer for the variable greaterthanzero. This will determine how many numbers till zero will be printed out.

while(greaterthanzero>0) //The program below will contiune to run until the statement becomes false. This occurs when the variable greaterthanzero becomes less than 0 meaning that the code has printed out all the numbers less than the integer "greaterthanzero" but larger than 0.
 {
   System.out.println(greaterthanzero); //Prints out the value for the variable greaterthanzero. This starts first in order to print ou the number the user entered.
   greaterthanzero=(greaterthanzero-1); //This changes the value of greaterthanzero by subtracting one from it to create a new value. This allows the variable greaterthanzero to get closer and closer to zero. This will stop running once greater than zero is less than zero.

  }
 }  
}
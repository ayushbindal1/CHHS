import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    
Scanner dowhileloop=new Scanner(System.in); //Create a new scanner
System.out.println("While Loops"); //Write title for code
System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class

/* Do While Loops Pseudocode
Get Information:
1.1 Ask the user for their name. It should be longer than two characters
1.2 Ask the user for their age. The range for this can be between 1 to 120.
1.3 Ask the user for their gender. This can either be male or female.
1.4 Ask the user for what state they are located in. This should be two letters long for the abbrevation.

Do Calculations:
2.1 Calculate the length of the user's name from 1.1 in order to determine whether or not the user entered a name longer than two charcters.
2.2 Calculate the length of the user's "state" from 1.4. This will be used to determine wheter or not the user entered a state correct state abbrevation.

Print Results:
3.1 If the user enters a name in 1.1 that is longer than or equal to 2 calculated in 2.1 ask the user for their age. If the name is not greater than 2 characters ask the user to enter their name in again.
3.2 If the user enters an age in 1.2 that between 1 and 120 than ask the user for their gender. If the age is not between 1 and 120 as the user to enter their age again.
3.3 If the user enters a gender in 1.3 that is either "Male" or "Female" than ask the user for the state they live in. If the gender is not "Male" or "Female" ask the user to enter their gender in again.
3.4 If the user enters a state in 1.4 that is equal to 2 characters calculated in 2.2 than do 3.5. If the state equal to 2 characters ask the user to enter their state in again.
3.5 Print out the name, age, gender, and state of the user in one single line once they enterd all the information and met the criteria.
*/

String username; //Create a variable to hold the user's name.
int usernamelength; //Create a variable to hold the length of the user's name.
double userage; //Create a variable to hold the user's age.
String usergender; //Create a variable to hold the user's gender.
String userstate; //Create a variable to hold the state the user lives in.
int userstatelength; //Create a variable to hold the length of the user's state.



do{ //Create a do while loop
  System.out.print("Please enter your name and make sure it is longer than two letters: "); //Print out instructions for what the user should enter.
  username=dowhileloop.nextLine(); //Allow the user to enter their name and store it.
  usernamelength= username.length();// Calculate the length of the user's name. 
  if(usernamelength<2) //If the username the user entered is less than two it will display the text below.
  {
   System.out.println("Please enter a name longer than two letters. Yours was only "+usernamelength+" character(s) long."); //Prints out if the if statement in 41 is true.
  }
}while(usernamelength<2); //Contiunes to do the do loop in brackets until the statement becomes false and the username is longer than two.


do{ //Create a do while loop
  System.out.print("Please enter your age. You should be from ages 1 to 120 to use this program: "); //Print out instructions for what the user should enter.
  userage=dowhileloop.nextDouble(); //Allow the user to enter their age and store it.
  dowhileloop.nextLine();
  if(userage<1||userage>120) //If the userage statement is true the text below will print out.
  {
    System.out.println("Please enter an age between 1 to 120. According to the information you provided you are "+Math.round(userage)+" years old.");// The text will print out if the if statement in 51 is true.
  }
}while(userage<1||userage>120); //Contiunes to do the do loop in brackets until the statment becomes false and the age is between 1-120.


do{ //Create a do while loop
  System.out.print("Please enter your gender. You should be either male or female.(Lets not get into any discussions about others because this is just for a school assignment). Use Male or Female to indicate which one. Make sure they are capital: ");  //Print out instructions for what the user should enter.
  usergender=dowhileloop.nextLine(); //Allow the user to enter their gender and store it.
  if((!usergender.equals("Male")) && (!usergender.equals("Female")))//If the statement is true the message will print out.
  {
    System.out.println( "According to the information you provided you are a "+usergender+". Please enter your gender using Male or Female"); //The statement will print out if the if statemnt in line 61 is true.
  
  }
}while((!usergender.equals("Male")) && (!usergender.equals("Female"))); //Contiunes to do the do loop until this becomes false. This will mean the user entered in "Male" or "Female" for their gender


do{ //Create a do while loop
  System.out.print("Please enter your state name. Use its two letter abbreviation to indicate what state it is: "); //Print out instructions for what the user should enter.
  userstate=dowhileloop.nextLine(); //Allow the user to enter their state and store it.
  userstatelength= userstate.length(); //Calculates the length of what the user entered for his state.
  if(userstatelength!=2) //If the statement is true the message will print out.
  {
    System.out.println("Please enter a state. According to the information you provided you live in "+userstate+". Use the two letter abbreivation.");// Prints out the following statement if the if statement in line 72 is true.
  }
}while(userstatelength!=2); //Contiunes the do loop in brackets until the statement is not true. Then the state's name is two letters long.


System.out.println("According to the information you provided us your name is: "+username+", your age is: "+(Math.round(userage))+", your gender is: "+usergender+", and the state you live in is: "+userstate+".");// Prints out the following statement.


  }
}
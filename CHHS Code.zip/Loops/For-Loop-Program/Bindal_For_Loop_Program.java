import java.util.Scanner;
class Main {
  public static void main(String[] args) {
  

  System.out.println("For Loops Program"); //Write title for code
  System.out.println("Ayush Bindal 5th Period PAP CS");//Write Name, Class Period, and Class
  Scanner forloop= new Scanner(System.in); //Create a new scanner


  System.out.println("1. Print out the message “For loops are fun!” 25 times."); //Print out the following instructions.
  for(int loopsarefun=0; loopsarefun<25; loopsarefun++) //Creates a for loop that runs command below. Sets value of loopsarefun to zero and for loops stop once loopsarefun is greater than or  25. Variable increases by 1.
  {
    System.out.println("For loops are fun!"); //Prints out following statement.
  }
  System.out.println(""); //Creates space between tasks.


  System.out.println("2. Add up the odd numbers from 33 to 66."); //Print out the following instructions.
  int oddvalue=0; //Declares new that is holds odd number values.
  for(int oddnumber=35; oddnumber<=66; oddnumber+=2) //Creates a for loop that runs command below. Sets value of oddnumber to 35 and for loops stop once oddnumber is greater than 66. Variable increases by 2.
  {
   oddvalue+=oddnumber; //Increases the value of oddvalue by oddnumber variable.
  }
  System.out.println("Odd numbers from 33 to 66 sum: "+oddvalue); //Prints out following statement.
  System.out.println(""); //Creates space between tasks.


  System.out.println("3. Print out the first 10 multiples of 9."); //Print out the following instructions.
  int ninemultiplevalue=9; //Declares new variable
  for(int ninemultiples=0; ninemultiples<=10; ninemultiples++) //Creates a for loop that runs command below. Sets value of ninemultiples to 0 and for loop stops once ninmultiple is greater than 10. Variable increases by 1.
  {
   System.out.println("First 10 multiples of 9: "+(ninemultiplevalue*ninemultiples)); //Prints out following statement including multiples of 9.
  }
  System.out.println(""); //Creates space between tasks.
 

  System.out.println("4. Using a loop, test whether the number 107 is prime. (Check all of the numbers less than the square root of 107 to see if they divide into 107)"); //Print out the following instructions.
  int squarerootnumber; //Declares new integer
  for(squarerootnumber=((int)Math.sqrt(107)); squarerootnumber<=1; squarerootnumber--) //Creates a for loop that runs command below. Sets value of squarerootnumber to  square root of 107 and for loop stops once squarerootnumber is greater less than 1. Variable decreases by 1.
 {
   if (107%squarerootnumber == 0) //If statement runs following command if statement is true.
   {
     System.out.println("*****107 Is Not A Prime Number."); //Prints out the following statement
     squarerootnumber=-1; //Sets value of squareroot number to -1 moving out of for loop to end command
   }
 }

  if (squarerootnumber != -1) //If statement runs following command if statement is true.
 {
   System.out.println("*****107 Is A Prime Number"); //Prints out the following statement
 }
  System.out.println(""); //Creates space between tasks.


  System.out.println("5. Print out the numbers from 25 to 5 inclusive (in that order)"); //Print out the following instructions.
  for(int numberfive=25; numberfive>=5; numberfive--) //Creates a for loop that runs command below. Sets value of number to 25 and for loop stops once numberfive is less than 5. Variable decreases by 1.
  {
    System.out.println("Numbers from 25 to 5: "+numberfive); //Prints out the following statement
  }
  System.out.println(""); //Creates space between tasks.
 

  System.out.println("6. Have the user input 10 Strings. Print out the length of each one (as they enter them)"); //Print out the following instructions.
  String userinput; //Creates new variable to hold information user enters.
  for(int numbersix=0; numbersix<10; numbersix++) //Creates a for loop that runs command below. Sets value of numbersix to 0 and for loop stops once numbersix is greater than 10. Variable increases by 1.
 {
   System.out.println("Please enter in a string value: "); //Prints out following instructions
   userinput=forloop.nextLine(); //Allows user to enter a string value.
   System.out.println("The length of the string you just entered: "+userinput.length()); //Prints out following statement including length of the word user entered.
 }
  System.out.println(""); //Creates space between tasks.


  System.out.println("7. Print out 15 random numbers between 10 and 20"); //Print out the following instructions.
  for(int numberseven=0; numberseven<15; numberseven++) //Creates a for loop that runs command below. Sets value of numberseven to 0 and for loop stops once numberseven is greater than 15. Variable increases by 1.
  {
    System.out.println("A random number between 10 and 20: "+((int)(Math.random()*11)+10)); //Prints out following statement with random values.
  }
  System.out.println(""); //Creates space between tasks.


  System.out.println("8. Print out the square roots of the numbers from 120 to 160."); //Print out the following instructions.
  double squarerootvalue; //Declares new variable
  for(int numbereight=120; numbereight<=160; numbereight++) //Creates a for loop that runs command below. Sets value of numbereight to 120 and for loop stops once numbereight is greater than 160. Variable increases by 1.
 {
   squarerootvalue=(Math.sqrt(numbereight)); //Takes square root of numberieght variable.
   System.out.println("The square root of "+numbereight+":  "+squarerootvalue); // Prints out following statement including squareroot
 }
  System.out.println(""); //Creates space between tasks.


  }
}
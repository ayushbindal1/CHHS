public class Book //Creates a new class
{

    
    private String title; //Title of book
    private String author; //Author of book
    private int pages; //Number of pages
    private int year; //Year book was released


    public Book() //Default constructor
    {
       title="Unknown"; //Sets title variable to empty or "Unknown"
       author="Unknown"; //Sets author variable to empty or "Unknown"
       pages=0; //Sets pages variable to empty or "0"
       year=1; //Sets year variable to empty or "1"   
    }


    public Book(String usertitle, String userauthor, int userpages, int useryears) //Creates new constructor with two String inputs and two integer inputs
    {
       title=usertitle; //Sets title variable to usertitle variable
       author=userauthor; //Sets author variable to userauthor variable
       pages=userpages; //Sets pages variable to userpages variable
       year=useryears;  //Sets years variable to useryears variable
    }
    
    
    public String getTitle() //Accesses the title
    {
       return title; //Returns the string value variable title
    }
    

    public void printBook() //Prints book information
    {
       System.out.println("Title of Book: "+title+"\nAuthor of Book: "+author+"\nNumber of Pages: "+pages+"\nYear Published: "+year); //Prints out following statement       
    }


    public String getAuthor() //Accesses the author
    {
       return author; //Returns the string value variable author
    }

  
    public void editAuthor(String newAuthor) //Creates a new method that allows the user to enter a value to change the author
    {
       author=newAuthor; //Sets the author variable to the newAuthor variable
    }


    public String toString() //Creates a toString method
    {
       return title+" By: "+author; //Retruns following statement with title and author
    }


    public boolean equals(Book other) //Creates equals method that compares to books
    {
       return pages==other.pages; //Returns boolean value if the statement is true
    } 


    public void editTitle(String t) //Allows user to modify the title
    { 
       title=t; //Sets the author variable to the t variable the user can enter
    } 
    
}

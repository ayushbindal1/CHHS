import java.util.Scanner;

/* Book Class Psuedocode


 1. Get Information:
   1.1 Have the user enter a title for the book
   1.2 Have the user enter an author for the book
   1.3 Have the user enter the amount of pages for the book
   1.4 Have the user enter the year the book was published

 2. Do Calculations:

 3. Print Results:
   3.1 Print the values the user entered between 1.1 and 1.4

*/


class Main {
  public static void main(String[] args) {

   System.out.println("Book Class Program: "); //Write title for code
   System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
   System.out.println(""); //Add a space between lines
   Scanner bookscanner=new Scanner(System.in); //Creates scanner


   System.out.print("Enter the title of your book: "); //Prints out following instructions
   String userentertitle=bookscanner.nextLine(); //Allows user to enter String value for the title of the book
   System.out.println(""); //Add a space between lines


   System.out.print("Enter the name of the author of your book: "); //Prints out following instructions
   String userenterauthor=bookscanner.nextLine(); //Allows user to enter String value for the author of the book
   System.out.println(""); //Add a space between lines


   System.out.print("Enter the amount of pages in your book: "); //Prints out following instructions
   int userenterpagecount=bookscanner.nextInt(); //Allows user to enter integer value for the pages in the book
   System.out.println(""); //Add a space between lines


   System.out.print("Enter the year your book was published: "); //Prints out following instructions
   int userenteryear=bookscanner.nextInt(); //Allows user to enter integer value for the year the book was published
   System.out.println(""); //Add a space between lines
   System.out.println(""); //Add a space between lines



   Book defaultbook=new Book(userentertitle,userenterauthor,userenterpagecount,userenteryear); //Defeaultbook that takes in values user enters to create a new "book"


   defaultbook.printBook(); //Runs printBook accessor in book class  
   
   
  }
}
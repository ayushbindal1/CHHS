import java.util.Scanner;

class Main {
  public static void main(String[] args) {
   System.out.println("Movie Class Program: "); //Write title for code
   System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
   System.out.println(""); //Add a space between lines
   Scanner moviescanner=new Scanner(System.in); //Creates scanner

   System.out.print("Enter the title of your movie: "); //Prints out following instructions
   String userentermovie=moviescanner.nextLine(); //Allows user to enter String value for the title of the book
   System.out.println(""); //Add a space between lines


   System.out.print("Enter the name of the director for your movie: "); //Prints out following instructions
   String userenterdirector=moviescanner.nextLine(); //Allows user to enter String value for the author of the book
   System.out.println(""); //Add a space between lines


   System.out.print("Enter the genre of your movie: "); //Prints out following instructions
   String userentergenre=moviescanner.nextLine(); //Allows user to enter integer value for the pages in the book
   System.out.println(""); //Add a space between lines


   System.out.print("Enter the run time of your movie in minutes: "); //Prints out following instructions
   int userenterruntime=moviescanner.nextInt(); //Allows user to enter integer value for the year the book was published
   System.out.println(""); //Add a space between lines
   System.out.println(""); //Add a space between lines


   Movie newMovie= new Movie(userentermovie,userenterdirector,userentergenre,userenterruntime);
   newMovie.printMovie();
   System.out.println("");
   System.out.println("Movie: "+newMovie);
   
  }
}
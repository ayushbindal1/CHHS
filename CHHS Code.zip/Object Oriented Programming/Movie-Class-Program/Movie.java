public class Movie
{ 
    private String movietitle;
    private String director;
    private String genre;
    private int runtime;

    public Movie()
    {
       movietitle="Empty";
       director="Unknown";
       genre="Unknown";
       runtime=0;
    }

    public Movie(String usertitle, String userdirector, String usergenre, int userruntime)
    {
        movietitle=usertitle;
        director=userdirector;
        genre=usergenre;
        runtime=userruntime;
    }

    public String getTitle()
    {
       return movietitle;
    }

    public String getDirector()
    {
       return director;
    }

    public String getGenre()
    {
       return genre;
    }

    public int getTime()
    {
       return runtime;
    }


   public void printMovie() //Prints book information
    {
       System.out.println("Title of movie: "+movietitle+"\nDirector of movie: "+director+"\nGenre of movie: "+genre+"\nRun time in minutes: "+runtime+" minute(s)"); //Prints out following statement 
    }

   public void editMovie(String newTitle, String newDirector, String newGenre, int newRuntime)
   {
        movietitle=newTitle;
        director=newDirector;
        genre=newGenre;
        runtime=newRuntime;
   }

   public String toString()
   {
       return movietitle+", Directed by: "+director+", Genre: "+genre+", Runtime: "+runtime+" minute(s)";
   }

}
public class Movie{ //Creates new class




   private String movietitle; //Creates variable to store title of the movie
   private String moviedirector; //Creates variable to store director of the movie
   private String moviegenre; //Creates variable to store genre of the movie
   private int movieruntime; //Creates variable to store the run time in minutes of the movie



   public Movie() //Creates constructor
   {
       movietitle=""; //Sets movietitle variable to empty or ""
       moviedirector=""; //Sets moviedirector variable to empty or ""
       moviegenre=""; //Sets moviedirector variable to empty or ""
       movieruntime=0; //Sets movieruntime variable to empty or 0
   }


   public Movie(String usermovietitle, String usermoviedirector, String usermoviegenre, int usermovieruntime) //Creates another constructor that allows assignment to variables
   {
       movietitle=usermovietitle; //Sets movietitle variable to usermovietitle variable
       moviedirector=usermoviedirector; //Sets moviedirector variable to usermoviediretor variable
       moviegenre=usermoviegenre; //Sets moviegenre variable to usermoviegenre variable
       movieruntime=usermovieruntime; //Sets movieruntime variable to usermovieruntime variable
   }



   public String getTitle() //Creates accessor to return an String value
   {
       return movietitle; //Returns variable
   }


   public String getDirector() //Creates accessor to return an String value
   {
       return moviedirector; //Returns variable
   }


   public String getGenre() //Creates accessor to return an String value
   {
       return moviegenre; //Returns variable
   }


   public int getRuntime() //Creates accessor to return an int value
   {
       return movieruntime; //Returns variable
   }


   
   public void editTitle(String newTitle) //Creates modifiers to take in String value 
   {
       movietitle=newTitle; //Sets movietitle variable to newTitle variable
   }


   public void editDirector(String newDirector) //Creates modifiers to take in String value 
   {
       moviedirector=newDirector; //Sets moviedirector variable to newDirector variable
   }


   public void editGenre(String newGenre) //Creates modifiers to take in String value 
   {
       moviegenre=newGenre; //Sets moviegenre variable to newGenre variable
   }


   public void editRuntime(int newRuntime) //Creates modifiers to take in an int value 
   {
       movieruntime=newRuntime; //Sets movieruntime variable to newRuntime variable
   }

   

   public String toString() //Creates toString
   {
       return "Title: "+movietitle+"\nDirected By: "+moviedirector+"\nGenre: "+moviegenre+"\nRuntime: "+movieruntime+" minute(s)"; //Returns following statement about all attributes about Movie
   }
   


   public boolean equals(Movie other) //Creates equals method that compares one object to other object that returns a boolean value
   {
       return movietitle.equals(other.movietitle) &&  moviedirector.equals(other.moviedirector); //Returns true or false if movietitle variable is equal to the movietitle of "other" object and if moviedirector varaiable is equal to the moviedirector of "other" object
   }




}
import java.util.Scanner;





/* RPG Project Pseudocode




1. Get Information:

    
     1.1 Have the user select what task they want to do. 1. Add Movie to Database 2. View Movies in Database 3. Remove Movie from Database 4. Quit Database Alteration. Continue to do 1.1 until the value in 1.1 is equal to 4.


     1.2 If the user selected 1 for 1.1 have the user enter the following attributes about their movie: Title, Director, Genre, and Runtime (Minutes)
     1.3 After 1.2 if the amount of items is equal to the length of the array run the addSpace method
     1.4 Create a new movie object for the attributes entered and add it to the array


     1.5 If the user chooses 2 in 1.1 have the user decide between 1. View all movies in the database or 2. View specfic movie in database.
     1.6 If the user chooses 1 after 3.2 runs and prints out five movies have the user choose between 1. Yes  or 2. No to keep viewing the database or not 
     1.7 If the user chooses 2 in 1.5 have the user enter the title and director of the movie they want to view


     1.8 If the user chose 3 in 1.1 have the user enter the following attributes about their movie: Title, Director, Genre, and Runtime (Minutes) to create a movie to be removed from the array
     1.9 If there is a value found in 2.6 have the user enter if they really want to remove the object. Enter 0 If No Or Enter 1 If Yes



2.Do Calculations:


     2.1 If the user runs 1.4 increase the amount of items in the list by 1


     2.2 In the addSpace method for 1.3 create a tempArray with 100 more elements than the original
     2.3 After 2.2 create a for loop for each element less than the itemamount that sets each element of the tempArray equal to the object at the original
     2.4  After 2.3 increase the length of the original by setting its length to the tempArray length
     2.5  After 2.4 create a for loop for each element less than the itemamount that sets each element of the original equal to the object at the tempArray


     2.6 Go through each object in the array to find if the object at the index is equal to the object the user created in 1.8

     2.7 If the user chose 1 in 1.9 set the object at the index of the variable equal to the object at the last variable and decrease the amount of items by 1 to remove the last object 



3. Print Results:


     3.1 If the user runs 1.2 print out at the end that the movie was added to the database
     

     3.2 If the user chooses 1 in 1.5 print out five of the objects
     3.3 If the user chooses 1 in 1.6 continue to print out each element of the array
     3.4 If the user chooses 2 in 1.6 end printint out each element of the list and tell the user this has occured

     3.5 If the user chooses 2 in 1.5 Go through each object in the array and if the values the user entered in 1.7 correspond to their respective attribute of an object print out the object
     3.6 If the values the user entered in 1.7 is not found anywhere in the array print out the object was not found in the array

     
     3.7 Once 2.6 and 2.7 are complete tell the user their movie has been removed
     3.8  If the user entered 0 in 1.9 tell the user they chose not to remove an item
     3.9 If the object created in 1.8 is not equal to any value in the array tell the user that their is no value to be removed

     
     3.10 Once the user finishes the loop in 1.1 by entering 4 tell the user "Thank you for using the movie database!"







*/





public class Database{ //Creates new class





   private int itemamount=0; //Sets itemamount variable to 0 to be used to keep track of position in newMovieArray
   private Movie[] newMovieArray=new Movie[500]; //Creates newMovieArray array with 500 different elements to store different Movie objects
   Scanner datascanner= new Scanner(System.in); //Creates scanner




   public void addSpace() //Creates void method called addSpace used to increase the space of the array if it runs out
   {


       Movie tempArray[] = new Movie[newMovieArray.length+100]; //Creates tempArray with 100 more elements than the newMovieArray to store more Movie objects. This is temporarily used to store the values of the newMovieArray while it's size is being increased to hold more objects.


       for(int i=0; i<itemamount; i++) //Creates a for loop
       {
           tempArray[i]=newMovieArray[i]; //Each element of the tempArray is set equal to each repsective element of the newMovieArray to store the values of the newMovieArray
       }


       newMovieArray = new Movie[tempArray.length]; //Increases the size of the newMovieArray by setting it's length to the length of the tempArray which should be 100 elements bigger

       for(int i=0; i<itemamount; i++) //Creates a for loop
       {
           newMovieArray[i]=tempArray[i]; //Each element of the newMovieArray is set equal to each respective element of the tempArray to regain all the values stored in the tempArray with an increased size
       }


   }

   public void addMovie() //Creats void method called addMovie
   {

       System.out.println("\n\nYou chose to add a movie!"); //Prints out following statement
       System.out.print("\nPlease enter the title of your movie: "); //Prints out instructions for what the user should enter
       String movietitle=datascanner.nextLine(); //Allows user to enter String value for movietitle variable
  

       System.out.print("\nPlease enter the director of your movie: "); //Prints out instructions for what the user should enter
       String moviedirector=datascanner.nextLine(); //Allows user to enter String value for moviedirector variable


       System.out.print("\nPlease enter the genre of your movie: "); //Prints out instructions for what the user should enter
       String moviegenre=datascanner.nextLine(); //Allows user to enter String value for moviegenre variable


       System.out.print("\nPlease enter the runtime of your movie in minutes: "); //Prints out instructions for what the user should enter
       int movieruntime=datascanner.nextInt(); //Allows user to enter int value for movieruntime variable
       datascanner.nextLine(); //Makes sure enter button is accounted for after .nextInt


       Movie newMovie=new Movie(movietitle,moviedirector,moviegenre,movieruntime); //Creates new object called newMovie with previous variables entered into constructor



       if(itemamount==newMovieArray.length) //If the if statement is true following code runs. This means that the amount of items is equal to the amount of items the newMovieArray can hold and needs to increase size
       {
           addSpace(); //Runs addSpace method
       }


       newMovieArray[itemamount]=newMovie; //Adds newMovie object to value of itemamount position in array
       itemamount++; //Increases the iteamount variable by 1 which esseitnaly goes up one element in the newMovieArray list


       System.out.println("\nYour movie has been added to the database! \n\n\n"); //Prints out following statement
   }
       
      



   public void viewMovie() //Creates void method called viewMovie
   {




        int findmovievalue=-1; //Creates int variable called findmovievariable used to keep track if a movie has been found in the list or not
        int viewMovieTask=0; //Creates int variable called viewMovieTask which keeps track how the user wants to see the database based on their preference
         //Creates int variable called secondhalfdatabase which keeps track of if the user wants to see the second half of the database after seeing the first




        System.out.println("\n\nYou chose to view a movie!\n "); //Prints out following statement
        System.out.print("1. View all movies in the database\n2. View specfic movie in database\nSelect the number that correpsonds to the task you would like to do: "); //Prints out following instructions
        viewMovieTask=datascanner.nextInt(); //Allows user to enter an int value to viewMovieTask
        datascanner.nextLine(); //Makes sure that the enter button has been accounted for after the .nextInt()




        if(viewMovieTask==1) //If if statement is true following code runs
        {


           System.out.println("\nYou chose to view all movies in the database: \n\n"); //Prints out following statement 


           for(int i=0; i<itemamount; i++) //Creates for loop that goes through first half of the newMovieArray 
           {
               if(i%5==0 && i>0) //If if statement is true that means that five movies have been printed out and asks the user if they want to keep viewing the list
               {
                   System.out.print("\nWould you like to keep looking at the database?\n1. Yes\n2. No\nEnter the number that correpsonds to the action you would like to do: "); //Prints out following instructions
                   int viewfulldatabase=datascanner.nextInt(); //Assigns input value to viewfulldatabase which allows the user to choose if they want to keep viewing the list
                   datascanner.nextLine(); //Makes sure enter button is accounted for after .nextInt
                   System.out.println("\n"); //Creates blank space between lines
                   if(viewfulldatabase==1) //If if statement is true following statement runs
                   {
                       System.out.println("You chose to keep viewing the list: \n\n"); //Prints out following statement
                   }
                   else if(viewfulldatabase==2) //If the statement in line 196 and the else if statement is true the following code runs
                   {
                       System.out.println("You chose to quit viewing the list!\n"); //Prints out following statement
                       break; //Ends the for loop meaning that they are done looking at the movies in the array
                   }
               }
               System.out.println(newMovieArray[i]+"\n"); //Prints out following statement
           }



           System.out.println("\n\n"); //Add a space between lines


        }




        if(viewMovieTask==2) //If following statement is true following code runs
        {


           System.out.print("\nPlease enter the title of the movie you would like to search for: "); //Prints out following instructions
           String userfindmovievalue=datascanner.nextLine(); //Allows user to enter the title of the movie to the String userfindmovie they are trying to find in their database

           System.out.print("\nPlease enter the director of the movie you would like to search for: "); //Prints out following instructions
           String userfinddirectorvalue=datascanner.nextLine(); //Allows user to enter the director of the movie to the String userfinddirector they are trying to find in their database
         
         
           for(int i=0; i<itemamount; i++) //Creates for loop that searches through all the values the user has entered in the list by using the itemamount variable to determine when to stop the loop
           {

             if(newMovieArray[i].getTitle().equals(userfindmovievalue) && newMovieArray[i].getDirector().equals(userfinddirectorvalue)) //If if statement is true the following code runs
             {
                 System.out.println("\nYour Movie:\n"+newMovieArray[i]); //Prints out the movie at index "i" in the newMovieArray 
                 System.out.println("\n\n\n"); //Add a space between lines

                 findmovievalue=1; //Sets the findmovievalue to 1 meaning that at least one object was found in the newMovieArray the user was looking for
                 break; //Ends the for loop meaning that the user found the movie they were looking for
             } 
          
           }
        

           if(findmovievalue==-1) //If statement is true the following code runs
           {
               System.out.println("\nSorry we were not able to find your movie in the database!\n\n\n"); //Prints out following statement
           }


        }




   }





   public void removeMovie() //Creates void method called removeMovie
   {




       int verifyremove=0; //Creates int variable called verifyremoe used to determine if the user actually wants to remove the movie from the database
       int findremovevalue=-1; //Creates int variable called findremovevariable used to keep track if the movie the user wants to remove is present in the newMovieArray
       System.out.println("\n\nYou chose to remove a movie!"); //Prints out following statement




       System.out.print("\nPlease enter the title of the movie you want to remove: "); //Prints out instructions for what the user should enter
       String removemovietitle=datascanner.nextLine(); //Allows user to enter String value for removemovietitle variable
  

       System.out.print("\nPlease enter the director of the movie you want to remove: "); //Prints out instructions for what the user should enter
       String removemoviedirector=datascanner.nextLine(); //Allows user to enter String value for removemoviedirector variable


       System.out.print("\nPlease enter the genre of the movie you want to remove: "); //Prints out instructions for what the user should enter
       String removemoviegenre=datascanner.nextLine(); //Allows user to enter String value for removemoviegenre variable


       System.out.print("\nPlease enter the runtime of the movie you want to remove: "); //Prints out instructions for what the user should enter
       int removemovieruntime=datascanner.nextInt(); //Allows user to enter int value for removemovieruntime variable
       datascanner.nextLine(); //Makes sure enter button is accounted for after .nextInt


       Movie removeMovie=new Movie(removemovietitle,removemoviedirector,removemoviegenre,removemovieruntime); //Creates new object called removeMovie with previous variables entered into constructor. This will be compared with movies in list




       for(int i=0; i<itemamount; i++) //Creates for loop
       {



           if(newMovieArray[i].equals(removeMovie)) //If if statement is true following code runs. Means that the object the user created is equal to the object at index "i" in the newMovieArray
           {


               System.out.print("\n\nAre you sure you want to remove this movie? Enter 0 If No Or Enter 1 If Yes: "); //Prints out following instructions
               verifyremove=datascanner.nextInt(); //Allows user to enter int value for verifyremove variable to determine if they actually want to remove the movie from the database
               datascanner.nextLine(); //Makes sure that the enter button has been accounted for after the .nextInt()

               findremovevalue=1; //Sets findremovevalue variable to 1


               if(verifyremove==1) //If if statement is true the following code runs
               {
                   newMovieArray[i]=newMovieArray[itemamount-1]; //Sets the object at index "i" of the newMovieArray equal to the last object of the newMovieArray
                   itemamount--; //Removes the last value of the newMovieArray

                   System.out.println("\nYour movie has been removed from the database!\n\n\n");  //Prints out following statement
                   break; //Ends the for loop meaning that they fully removed the movie from the database   
               }


               else if(verifyremove==0) //If if statement in line 224 and if if statement is true following code runs
               {
                   System.out.println("\nYou chose not to remove the movie from the database!\n\n\n"); //Prints out following statement
                   break; //Ends the for loop meaning that they are done looking for a movie in the database to remove
               }


           } 



       }




       if(findremovevalue==-1) //If if statement is true following code runs
       {
           System.out.println("\nSorry we could not find your movie in the database!\n\n\n");  //Prints out following statement
       }




   }





   public void run() //Creates run method to run all other methods
   {




       int databasetask=0; //Sets databastask to 0 for the menu



       do //Creates do while loop
       {


           System.out.print("1. Add Movie to Database\n2. View Movies in Database\n3. Remove Movie from Database\n4. Quit Database Alteration\nPlease select a number that corresponds with the task you want to do: "); //Creates a menu of tasks that can be chosen from
           databasetask=datascanner.nextInt(); //Allows the user to enter a number that corresponds with a task
           datascanner.nextLine(); //Makes sure that the enter button has been accounted for after the .nextInt()


           if(databasetask==1) //If statement is true following code runs
           {
               addMovie(); //Runs addMovie method
           }


           if(databasetask==2) //If statement is true following code runs
           {
               viewMovie(); //Runs viewMovie method
           }
           

           if(databasetask==3) //If statement is true following code runs
           {
               removeMovie(); //Runs removeMovie method
           }



       }while(databasetask!=4); //Runs code until statement becomes false



       System.out.println("\n\nThank you for using the movie database!"); //Prints out following statement




   }





}
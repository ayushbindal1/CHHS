class Main {




  public static void main(String[] args) {



     System.out.println("Database Project: "); //Write title for code
     System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
     System.out.println(""); //Add a space between lines


      Database newdatabase= new Database(); //Creates new object for Database class
      newdatabase.run(); //Runs run method in Database class



  }




}
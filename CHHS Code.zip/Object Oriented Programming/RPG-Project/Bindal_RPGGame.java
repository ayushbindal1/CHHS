import java.util.Scanner;





/* RPG Project Pseudocode




1. Get Information:


   1.1 Have player1 enter their playername
   1.2 Have player2 enter their playername


   1.3 Have user enter number that cooresponds with actions 1.Attack Army 2.Shop for Goods 3.Capture Land 4.Attack Emporer 5.View Player Attributes 6.How to Play 7.Quit Game


   1.4 If the user enters 2 in 1.3 have the user choose from different items they can buy; 1.Army Strength Buff 2.Troop Increase 3. Emporer Health Increase 4.Stop Shopping


2.Do Calculations:


   2.1 If the user chooses 1 in 1.3 increase current player's money by oppennent's money/50; decrease current player's money by opponent's armysize/500; decrease the current opponent's money by 1/50 of the original; and decrease the current opponent's armysize by opponent armysize/100


   2.2 If the user chooses 1 and playermoney>=700 in 1.4 playermoney-700 and playerarmystrength*2
   2.3 If the user chooses 2 and playermoney>=800 in 1.4 playermoney-800 and playerarmysize+500
   2.4 If the user chooses 3 and playermoney>=650 in 1.4 playermoney-650 and playerrulerhealth+100


   2.5 If the user chooses 3 in 1.3 generate a random number between 1 and 10
       2.5A If the random number in 2.5 is greater than 5 playermoney+200, playerarmysize+200, playerlandsize+100, opponentmoney-200, opponentarmysize-200, and opponentlandsize-100
       2.5B If the random number in 2.5 is less than 5 playermoney-100, playerarmysize-100, playerlandsize-50, opponentmoney+100, opponentarmysize+100, and opponentlandsize+50


   2.6 If the user chooses 4 in 1.3 generate a random number between 1 and 10
       2.6A If the random number in 2.6 is greater than 7 playermoney+300, opponentmoney-300, and opponentrulerhealth-30
       2.6B  If the random number in 2.6 is less than 7 playerarmysize-100, playermoney-200, and opponentmoney+200




3. Print Results:


     3.1 If the user chooses 1 in 1.3 print out both the current player and opponent object


     3.2 If 2.2, 2.3, or 2.4 is run print new values for player object
     3.3 If the user chooses 1,2,3 and playermoney<700,800,650 in 1.4 respectively tell the user they do not have enough money.


     3.4 If the user chooses 4 in in 1.4 tell the user they quit shopping
     3.5 If the user chooses 3 in 1.3 print current player object and current opponent object based on what was calculated in 2.5
     3.6 If the user chooses 4 in 1.3 print current player object and current opponent object based on what was calculated in 2.6
     3.7 If the user chooses 5 in 1.3 print current player object and current opponent object
     3.8 If the user chooses 6 in 1.3 print instructions for how the game work


     3.9 Repeat 1.3 to 3.8 if the user chooses 5 or 6 in 1.3 as these are not actual actions that affect the opponent


     3.10 Return value chosen in 1.3 as if it is equal to seven it will end the loop alternating between player1 and player2


     3.11 while player1rulerhealth>0 and player1landsize>0 and player1armysize>0 and player2rulerhealth>0 and player2landsize>0 and player2armysize>0 and 1.3  does not equal 7 run 1.3 to 3.8 setting player1 as the player and player2 as the opponent then setting player2 as the player and player 1 as the opponent to alternate between who gets to perform an action


     3.12 If 3.11 while statement becomes false print final messages
         If player1rulerhealth<0 or player1landsize<0 or player1armysizeles print that player1 lost and player2 won
         If player2rulerhealth<0 or player2landsize<0 or player2armysizeles print that player2 lost and player1 won
         If 1.3 equals 7 print that the users quit the game and it is a draw 







*/





public class RPGGame{ //Creates RPGGame class





   private Empire player1; //Creates private object from Empire class called player1
   private Empire player2; //Creates private object from Empire class called player2





   public RPGGame() //Creates constructor to set player1 and player 2 variable
   {



       Scanner RPGscanner= new Scanner(System.in); //Creates Scanner
       System.out.print("Player one please enter your name: "); //Prints Instructions
       String player1name=RPGscanner.nextLine(); //Runs .nextLine to be sure enter value is added to input //Allows user to enter name of player one


       System.out.print("Player two please enter your name: "); //Prints Instructions
       String player2name=RPGscanner.nextLine(); //Runs .nextLine to be sure enter value is added to input //Allows user to enter name of player two 
       System.out.println(""); //Creates blank line
       System.out.println(""); //Creates blank line 


       player1= new Empire(1500,500,1000,5,100,player1name); //Empire class constructor for player1 object
       player2= new Empire(1500,500,1000,5,100,player2name); //Empire class constructor for player2 object



   }
 





   public int PlayerRun(Empire player, Empire opponent) //Creates PlayerRun method that returns an integer value. Takes in two objects depending on which player it is which is determined in the run method
   {




       Scanner RPGscanner=new Scanner(System.in); //Creates new scanner
       int playerRPGaction=0; //Creates new integer variable called playerRPGaction. Used to determine which action user wants to perform



       do //Creates do while loop
       {


            System.out.print("1. Attack Army \n2. Shop for Goods \n3. Capture Land \n4. Attack Emporer\n5. View Player Attributes \n6. How to Play \n7. Quit Game\n"+player.getPlayername()+" choose what action you want to do by entering the corresponding number: "); //Prints following instructions
           playerRPGaction=RPGscanner.nextInt(); //Allows user to enter integer value to playerRPGaction variable to determine which action the user wants to do
           RPGscanner.nextLine(); //Runs .nextLine to be sure enter value is added to input
           System.out.println(""); //Creates blank line
           System.out.println(""); //Creates blank line
  


           if (playerRPGaction==1) //If statement is true following code runs used to attack the opponent army
           {


               System.out.println("You chose to attack "+opponent.getPlayername()+"'s army!"); //Prints following statement
               System.out.println("Your money increased and "+opponent.getPlayername()+"'s army and money decreased! However, you also had some casualties..."); //Prints following statement
               System.out.println(""); //Creates blank line

               player.editMoney(player.getMoney()+(opponent.getMoney()/50)); //Increases the current player's money
               player.editArmysize(player.getArmysize()-((opponent.getArmysize()*opponent.getArmystrength())/500)); //Decrease current player's army size by a small amount
               opponent.editArmysize(opponent.getArmysize()-((player.getArmysize()*player.getArmystrength())/100)); //Decrease current opponent's army size
               opponent.editMoney(opponent.getMoney()-(opponent.getMoney()/50)); //Decrease current opponent's money


             System.out.println(player); //Prints player object toString
             System.out.println(""); //Creates blank line

             System.out.println(opponent); //Prints opponent object toString
             System.out.println(""); //Creates blank line
             System.out.println(""); //Creates blank line


         }


      
         if (playerRPGaction==2) //If following statement is true following code runs allowing player to use shop
           {


               System.out.println("You chose to shop for goods!"); //Prints following statement
               System.out.print("1. Army Strength Buff (700 coins)\n2. Troop Increase (800 coins)\n3. Emporer Health Increase (650 coins)\n4. Stop Shopping\n5. Choose what you would like to buy based on the number that corresponds to the product: "); //Prints following instructions
               int shopitem=RPGscanner.nextInt(); //Allows user to choose an integer value that allows them to buy a certain item depending on the number
               RPGscanner.nextLine(); //Runs .nextLine to be sure enter value is added to input
               System.out.println(""); //Creates blank line
               System.out.println(""); //Creates blank line



               if (shopitem==1 && player.getMoney()<700) //If following statement is true code below runs
               {
                   System.out.println("You do not have enough coins to buy this item."); //Prints following statement
               }


               if (shopitem==1 && player.getMoney()>=700) //If following statement is true code below runs
               {
                   System.out.println("You chose to buy the Army Strength Buff! Your army will now do much more damage!"); //Prints following statement
                   
                   player.editMoney(player.getMoney()-700); //Decreases current player's money
                   player.editArmystrength(player.getArmystrength()*2); //Increases current player's armystrength

                   System.out.println(player); //Prints player object toString
                   System.out.println(""); //Creates blank line
               }



               if (shopitem==2 && player.getMoney()<800) //If following statement is true code below runs
               {
                   System.out.println("You do not have enough coins to buy this item."); //Prints following statement
               }


             if (shopitem==2 && player.getMoney()>=800) //If following statement is true code below runs
             {
                 System.out.println("You chose to buy the Troop Increase! You have a much larger army!"); //Prints following statement

                 player.editMoney(player.getMoney()-800); //Decreases current player's money
                 player.editArmysize(player.getArmysize()+500); //Increases current player's army size

                 System.out.println(player); //Prints player object toString
                 System.out.println(""); //Creates blank line
             }



               if (shopitem==3 && player.getMoney()<650) //If following statement is true code below runs
               {
                   System.out.println("You do not have enough coins to buy this item."); //Prints following statement
               }
             

               if (shopitem==3 && player.getMoney()>=650) //If following statement is true code below runs
               {
                   System.out.println("You chose to buy the Emporer Health Increase! You emporer has more health!"); //Prints following statement

                   player.editMoney(player.getMoney()-650); //Decreases current player's money
                   player.editRulerhealth(player.getRulerhealth()+100); //Increases current player's emporerhealth

                   System.out.println(player); //Prints player object toString
                   System.out.println(""); //Creates blank line
               }



               if (shopitem==4) //If following statement is true code below runs
               {

                   System.out.println("You chose to quit shopping!"); //Prints following statement

               }
               


           }




         if (playerRPGaction==3) //If following statement is true following code runs to try and capture opponent land
           {



               System.out.println("You chose to try to capture "+opponent.getPlayername()+"'s land!"); //Prints following statement
               int randomlandnum=(int)((Math.random()*(10))+1); //Creates a random number between 1 and 10. If the number is greater than 5 than the attempt to capture land succedes and if it is less than 5 it fails



               if (randomlandnum>5) //If following statement is true code below runs
               {


                   System.out.println("Your attempt to capture "+opponent.getPlayername()+"'s land succeded!"); //Prints following statement
                   System.out.println(player.getPlayername()+"'s Money, Army, and Land increased! "+opponent.getPlayername()+"'s Money, Army, and Land decreased!"); //Prints following statement
                   System.out.println(""); //Creates blank line


                   player.editMoney(player.getMoney()+200); //Increases current player's money
                   player.editArmysize(player.getArmysize()+200); //Increases current player's armysize
                   player.editLandsize(player.getLandsize()+100); //Increases current player's landsize

                   opponent.editMoney(opponent.getMoney()-200); //Decreases current opponent's money
                   opponent.editArmysize(opponent.getArmysize()-200); //Decreases current opponent's armysize
                   opponent.editLandsize(opponent.getLandsize()-100); //Decreases current opponent's landsize


                   System.out.println(player); //Prints player object toString
                   System.out.println(""); //Creates blank line
                   System.out.println(opponent); //Prints opponent object toString
                   System.out.println(""); //Creates blank line
                   System.out.println(""); //Creates blank line


               }


               else //If statement in line 199 is not true following code runs meaning the attempt to capture land failed
               {


                   System.out.println("Your attempt to capture "+opponent.getPlayername()+"'s land failed!"); //Prints following statement
                   System.out.println(player.getPlayername()+"'s Money, Army, and Land decreased! "+opponent.getPlayername()+"'s Money, Army, and Land increased!"); //Prints following statement
                   System.out.println(""); //Creates blank line


                   player.editMoney(player.getMoney()-100); //Decreases current player's money
                   player.editArmysize(player.getArmysize()-100); //Decreases current player's armysize
                   player.editLandsize(player.getLandsize()-50); //Decreases current player's landsize

                   opponent.editMoney(opponent.getMoney()+100); //Increases current opponent's money
                   opponent.editArmysize(opponent.getArmysize()+100); //Increases current opponent's armysize
                   opponent.editLandsize(opponent.getLandsize()+50); //Increases current opponent's landsize


                   System.out.println(player); //Prints player object toString
                   System.out.println(""); //Creates blank line
                   System.out.println(opponent); //Prints opponent object toString
                   System.out.println(""); //Creates blank line
                   System.out.println(""); //Creates blank line


               }



           }




         if (playerRPGaction==4) //If following statement is true the following code runs to try and attack emporer
           {

               System.out.println("You chose to try to attack "+opponent.getPlayername()+"'s emporer!"); //Prints following statement
               int randomemporernum=(int)((Math.random()*(10))+1); //Creates random number between 1 and 10. If the number is greater than 7 the attack on the emporer succededs however if it is less than 7 it fails



               if (randomemporernum>7) //If statement is true following code runs
               {

                   System.out.println("Your attempt to attack "+opponent.getPlayername()+"'s emporer succeded!"); //Prints following statement
                   System.out.println(player.getPlayername()+"'s money increased! "+opponent.getPlayername()+"'s money and emporer's health decreased!"); //Prints following statement

                   player.editMoney(player.getMoney()+300); //Increases current player's money

                   opponent.editMoney(opponent.getMoney()-300); //Decreases current oponent's money
                   opponent.editRulerhealth(opponent.getRulerhealth()-30); //Decreases current oponent's rulerhealth


                   System.out.println(player); //Prints player object toString
                   System.out.println(""); //Creates blank line
                   System.out.println(opponent); //Prints opponent object toString
                   System.out.println(""); //Creates blank line
                   System.out.println(""); //Creates blank line


               }


               else //If statement in line 269 is not true following statement runs, means attempt to hurt emporer failed
               {


                   System.out.println("Your attempt to attack "+opponent.getPlayername()+"'s emporer failed!"); //Prints following statement
                   System.out.println(player.getPlayername()+"'s army and money decreased! "+opponent.getPlayername()+"'s money increased, however they had some minor casualties"); //Prints following statement

                   player.editArmysize(player.getArmysize()-100); //Decreases current player's armysize
                   player.editMoney(player.getMoney()-200); //Decreases current player's money

                   opponent.editArmysize(opponent.getArmysize()-opponent.getArmysize()/10); //Increases current opponent's armysize
                   opponent.editMoney(opponent.getMoney()+200); //Increases current opponent's money


                   System.out.println(player); //Prints player object toString
                   System.out.println(""); //Creates blank line
                   System.out.println(opponent); //Prints opponent object toString
                   System.out.println(""); //Creates blank line
                   System.out.println(""); //Creates blank line
               }



           }




         if (playerRPGaction==5) //If the statement is true following code runs showing player attributes
         {

             System.out.println("You chose to view both player's attributes!"); //Prints statement
             System.out.println(player); //Prints player object toString
             System.out.println(""); //Creates blank line


             System.out.println(opponent); //Prints opponent object toString
             System.out.println(""); //Creates blank line
             System.out.println(""); //Creates blank line

         }




         if (playerRPGaction==6) //If the statment is true following code runs and prints out instructions
         {

             System.out.println("Instructions: "); //Prints statement


             System.out.println("1. Two players will control two different empires with the goal of destroying the other. They way that an empire is destroyed is if the Emporer's Health, Land Size, or Army Size ever reaches zero and the game ends. Each player starts with 1,500 coins, 500KM of Land, 1000 Troops, 5 Army Strength, and 100 Emporer HP.\n2.There are multiple different actions that each player gets to alternate between.\nThey can attack the other army which increases money while the opposing side loses money and troops.\nThey can shop for goods to increases stats like army strength for coins.\nThey can try and capture land. If they succeed the player's money, army, and land increase while the other's decrease. If it fails the player loses money army and land while the other side gains these items.\nThey can try and attack the emporer which is risky. If you succede you gain money while the opposite side loses mony and emporer health. If you fail you lose coins and troops while the opposite side gains money.\nThere are other options you can do such as view the instructions; view the attributes of both players; or quit the game.  "); //Prints instructions for game
             System.out.println(""); //Creates blank line
             System.out.println(""); //Creates blank line


          }



       }while(playerRPGaction==5 || playerRPGaction==6); //Continues to run loop until the following statement is not true as playerRPGaction values at 5 and 6 are not actual moves similar to a pause screen instead



       return playerRPGaction; //Returns playerRPGaction integer value to be used in run method to see if user wanted to quit playing



   }
  





   public void run() //Creates public void method that alternates between character doing an action and having an action done. It also prints out the final statements
   {



     do{ //Creates do while loop


         PlayerRun(player1, player2); //Sets player1 object as player variable in PlayerRun method and player2 object as opponent variable which is alternated between each turn to allow other ability to edit both objects without rewriting same code for player2
         PlayerRun(player2, player1); //Sets player1 object as player variable in PlayerRun method and player2 object as opponent variable which is alternated between each turn to allow other ability to edit both objects without rewriting same code for player1


     }while(PlayerRun(player1, player2)!=7 && PlayerRun(player2, player1)!=7 && player1.getRulerhealth()>0 && player1.getLandsize()>0 && player1.getArmysize()>0 && player2.getRulerhealth()>0 && player2.getLandsize()>0 && player2.getArmysize()>0); //Continues to alternate between player1 and player 2 being player and opponent in PlayerRun command until the statement is true




       if(player1.getRulerhealth()<0 || player1.getLandsize()<0 || player1.getArmysize()<0) //If statement is true than the following occurs
       {
           System.out.println(player1.getPlayername()+" lost! Congratulations "+player2.getPlayername()+" you won!"); //Prints statement
       }
  


       if( player2.getRulerhealth()<0 || player2.getLandsize()<0 || player2.getArmysize()<0) //If statement is true than the following occurs
       {
           System.out.println(player2.getPlayername()+" lost! Congratulations "+player1.getPlayername()+" you won!"); //Prints statement
       }
       


       if(PlayerRun(player1, player2)==7 || PlayerRun(player2, player1)==7) //If statement is true then the following occurs
       {
           System.out.println("You quit the game, it is a draw!"); //Prints statement
       }



       System.out.println("Thanks for playing!"); //Prints statement



   }




}





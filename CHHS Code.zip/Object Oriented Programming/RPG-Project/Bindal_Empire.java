public class Empire{ //Creates new class




 private int money; //Creates variable to store money of empire
 private int landsize; //Creates variable to store the amount of land
 private int armysize; //Creates variable to store the size of the army
 private int armystrength; //Creates variable to store strength of army
 private int rulerhealth; //Creates variable to store health of the ruler
 private String playername; //Creates variable to store username




 public Empire() //Creates constructor 
 {
     money=0; //Sets money variable to empty or zero
     landsize=0; //Sets landsize variable to empty or zero
     armysize=0; //Sets armysize variable to empty or zero
     armystrength=0; //Sets armystrength variable to empty or zero
     rulerhealth=0; //Sets rulerhealth variable to empty or zero
     playername=""; //Sets playername variable to empty or double quotes
 }


 public Empire(int usermoney, int userland, int userarmysize, int userarmystrength, int userrulerhealth, String userplayername) //Creates another constructor that allows assignment to variables
 {
     money=usermoney; //Sets money variable to usermoney variable
     landsize=userland; //Sets landsize variable to userland variable
     armysize=userarmysize; //Sets armysize variable to userarmysize variable
     armystrength=userarmystrength; //Sets armystrength variable to userarmystrength variable
     rulerhealth=userrulerhealth; //Sets rulerhealth variable to userrulerhealth variable
     playername=userplayername; //Sets playername variable to userplayername variable
 }




 public int getMoney() //Creates accessor to return an int value
 {
      return money; //Returns variable
 }


  public int getLandsize() //Creates accessor to return an int value
 {
      return landsize; //Returns variable
 }


 public int getArmysize() //Creates accessor to return an int value
 {
      return armysize; //Returns variable
 }


 public int getArmystrength() //Creates accessor to return an int value
 {
      return armystrength; //Returns variable
 }


 public int getRulerhealth() //Creates accessor to return an int value
 {
      return rulerhealth; //Returns variable
 }


 public String getPlayername() //Creates accessor to return a String value
 {
      return playername; //Returns variable
 }




 public void editMoney(int newMoney) //Creates modifiers to take in int value 
 {
     money=newMoney; //Sets money variable to newMoney variable
 }


  public void editLandsize(int newLand) //Creates modifiers to take in int value 
 {
     landsize=newLand;  //Sets landsize variable to newLand variable
 }


  public void editArmysize(int newArmysize) //Creates modifiers to take in int value
 {
     armysize=newArmysize; //Sets armysize variable to newArmysize variable
 }


  public void editArmystrength(int newArmystrength) //Creates modifiers to take in int value
 {
     armystrength=newArmystrength; //Sets armystrength variable to newArmystrength variable
 }


  public void editRulerhealth(int newRulerhealth) //Creates modifiers to take in int value
 {
     rulerhealth=newRulerhealth; //Sets ruler variable to newRulerhealth variable
 }


 public void editPlayername(String newPlayer) //Creates modifiers to take in String value 
 {
     playername=newPlayer; //Sets playername variable to newPlayer variable
 }




 public String toString() //Creates toString
 {
      return playername+"'s Attributes: \nMoney Left: "+money+"\nLand Size: "+landsize+"\nArmy Size: "+armysize+"\nArmy Strength: "+armystrength+"\nEmporer Health: "+rulerhealth; //Returns following statement about all attributes of empire
 }




}
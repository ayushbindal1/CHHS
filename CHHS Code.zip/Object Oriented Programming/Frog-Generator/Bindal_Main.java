import java.util.Scanner;


/* Frog Generator Psuedocode


 1. Get Information:
   1.1 Have the user enter a name for the frog
   1.2 Have the user enter 1 to rename the frog or any other number to keep the same name
   1.3 If the user entered 1 in 1.2 allow the user to enter a new name for the frog
   1.4 Have the user enter 1 to increase the size of the frog or any other number to keep it the same size
   1.5 Have the user enter 1 to change the location of the frog or any other number to keep it in the same location

 2. Do Calculations:
   2.1 If the user entered 1 in 1.4 increase both the age and weight of the frog by one.

 3. Print Results:
   3.1 Print out the name (1.1 and 1.3), age (1.4 and 2.1), weight (1.4 and 2.1), and location (1.5) of the frog based on what the user entered


*/


class Main {
  public static void main(String[] args) {

 System.out.println("Frog Generator: "); //Write title for code
 System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
 System.out.println(""); //Add a space between lines


 Frog userfrog= new Frog(); //Creates object for Frog class
 Scanner frogscan= new Scanner(System.in); //Creates a new scanner


 System.out.print("Please enter the name of your frog: "); //Gives the user instructions on what to enter
 String newfrogname=frogscan.nextLine(); //Allows user to enter a new name for the frog
 userfrog.rename(newfrogname); //Runs the rename method in the Frog class
 System.out.println(""); //Adds space between lines


 System.out.print("Do you want to rename your frog (1) or keep the same name (Any other number): "); //Gives the user instructions on what to enter
 int frogrename=frogscan.nextInt(); //Allows the user to choose to keep the same name or change it
 frogscan.nextLine(); //Prevents lines from merging

 if (frogrename==1)
 {
   System.out.print("Please enter the name of your frog: ");
   String newfrogname2=frogscan.nextLine();
   userfrog.rename(newfrogname2);
   System.out.println(""); //Adds space between lines
 }
 else 
 {
   System.out.println("You would like to keep the name of the frog!");
   System.out.println(""); //Adds space between lines
 }

 System.out.print("Would you like to grow your frog (1) or not grow your frog (Any other number): ");
 int frogincrease=frogscan.nextInt(); //ALlows user to choose to grow the frog or keep it the same size
  frogscan.nextLine(); //Prevents lines from merging
 if (frogincrease==1) //If the statement is true based on what the user enters the code below runs
 {
   System.out.print("You would like to grow the frog!"); //Prints out following statement
   System.out.println(""); //Adds space between lines
   userfrog.grow(); //Runs the grow method in the Frog class
   System.out.println(""); //Adds space between lines
 }
 else //If the statement in line 62 is not true it runs the code below
 {
   System.out.println("You would like to keep the frog the same size!"); //Prints out the following statement
   System.out.println(""); //Adds space between lines
 }


 System.out.print("Would you like to move your frog (1) or keep him in the same location (Any other number): "); //Gives the user instructions on what to enter
 int newlocation=frogscan.nextInt(); //Allows the user to decide if the frog stays in the same location or moves
 frogscan.nextLine(); //Prevents lines from merging
 if (newlocation==1) //If the following statement is true the code below with occur
 {
   System.out.print("You would like to move the frog!"); //Prints out the following statement
   System.out.println(""); //Adds space between lines
   userfrog.move(); //Runs the move method in the Frog class
 }
 else //If the statement in 79 is not true the following code will run
 {
   System.out.println("You would like to keep the frog in the same location!"); //Prints out the following statement
   System.out.println(""); //Adds space between lines
 }

 System.out.println(""); //Adds space between lines
 System.out.println("Your New Frog: "); //Prints out title
 userfrog.printFrog(); //Runs the printFrog method in the Frog class which prints out all the features of the frog


  }
}
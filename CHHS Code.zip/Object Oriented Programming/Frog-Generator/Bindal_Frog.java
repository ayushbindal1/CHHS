/* 

 Three main features of O.O.P.

   1. Encapsulation

     Example: String is a class

     String contains the information, but also contains methods.

     Information Hiding- 

   2. Polymorphism 

      Same name, but different functions.

   3. Inheritance

     -Object 

     -toString, equals

*/
//This class has attributes and methods to represent a frog 


public class Frog {   


//ATTRIBUTES (Class variables)    
  private String name; //Name of Frog
  private int age; //Age of Frog
  private double weight; //Weight of Frog
  private String location; //Location: Pond or Shore


//METHODS:

//CONSTRUCTORS- initialize the class
 public Frog() //default constructor
  {   
   name="Bob";
   age=1;
   weight=1;
   location="Pond";
  }
  
  public Frog(String n)    //second constructor
  {      
   name=n;
   age=1;
   weight=1;
   location="Pond";
  }


//ACCESSORS: Allow access to information without changing it
 public void printFrog() //print frog information
  {
    System.out.println(name + " the Frog\nAge: " + age + "\nWeight: " + weight + "\nLocation: "+ location);                
  } 
          
 public int getAge() //returns the age of the frog
  { 
   return age;
  }
      
 
 //MODIFIERS: Allow user to change information in the class
 public void rename(String newname) //changes name
 {  
   name=newname;
 }
     
 public void move() //changes location
 {
 if (location.equals("Pond"))
   location="Shore";
  else
   location="Pond";
 }
     
 public void grow() //changes age and weight
 {    
   age++;
   weight++;
 } 

}

     
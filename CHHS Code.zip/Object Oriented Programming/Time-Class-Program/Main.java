class Main { 
public static void main(String [] args)



    {         


        Time thetime= new Time(11,58,true);
        System.out.println("Current time: " + thetime);
        System.out.println("The hour is "+thetime.getHours());
        System.out.println("The minute is "+thetime.getMinutes());


        if(thetime.getAM())
           System.out.println("It is morning.");
        else  
           System.out.println("It is evening.");


        thetime.advanceHour();
        thetime.advanceMinute();
        thetime.advanceMinute();
        thetime.advanceMinute();
        thetime.advanceMinute();


        System.out.println("The new time is "+ thetime);  //Should print 1:02 PM      
        System.out.println("Have a nice day!");        
        

    }
    
    


}
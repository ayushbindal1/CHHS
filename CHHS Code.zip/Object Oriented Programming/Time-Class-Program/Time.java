



public class Time //This class represents information representing a time of day
{




    //Attributes 
    private int hour; //The hour
    private int minute; //Number of minutes
    private boolean AM; //If true, AM if false PM



    //Constructors
    public Time() //Default constructor
    {
        hour=12;
        minute=0;
        AM=true;
    }    
    

    public Time(int h, int m, boolean am) //Allows user to set the three values
    {
       hour=h;
       minute=m;
       AM=am;
    }    
    


    public int getHours() //Accesses the hours
    {
       return hour;
    }
    

    public int getMinutes() //Accesses the minutes
    {
       return minute;
    }  
    

   public boolean getAM()
   {
       return AM;
   }
    


    public String toString() // returns the time in the form: 12:00 PM or 11:30 AM etc.
    // You will need an if statement to print the AM or PM
    {       


       if(AM==true)
       {
         if(minute<10)
         {
             return hour+":0"+minute+" AM";
         }
         else
         {
             return hour+":"+minute+" AM";
         }

       }
       else
       {
           if(minute<10)
           {
               return hour+":0"+minute+" PM";
           }
           else
           {
               return hour+":"+minute+" PM";
           }

       }



    } 
    


    public void advanceHour() //adds one to the hour.  If the hour becomes 13, sets the hour to 1 
    //If the hour becomes 12, change AM to its opposite (true or false)    
    {   


        hour++;

        if (hour==13)
        {
           hour=1;
        }

        if (hour==12)
        {
           if(AM==true)
           {
               AM=false;
           }

           else
           {
               AM=true;
           }
        }



    }
    


    public void advanceMinute()  //adds one to the minute.  
    //If the minute becomes 60, sets the minute to 0 and then advances the hour
    {
       minute++;

       if(minute==60)
       {
           minute=0;
           advanceHour();
       }
    } 





} 
import java.util.Scanner; //Imports scanner class



/* Dice Class Psuedocode:


1. Get Information:
   1.1 Have the user enter how many dice both the user and the computer will use
   1.2 Have the user enter how many sides are on each dice both the user and the computer will use
   1.3 Allow the user to enter a number (1) to continue playing the game

2. Do Calculations:
   2.1 Assign values in 1.1 and 1.2 to a new object for the user
   2.2 Assign values in 1.1 and 1.2 to a new object for the computer
   2.3 Run rollDice() method for user object and store the value in a seperate variable
   2.4 Run rollDice() method for computer object and store the value in a seperate variable

3. Print results:
   3.1 If the value in 2.3>2.4 print out that the user beat the computer
   3.2 If the boolean in 3.1 is not true print out that the computer beat the user
   3.3 Repeat 1.1 to 3.2 if the value in 1.3==1 if not end the game

*/



class Main {


  public static void main(String[] args) {

    
     System.out.println("Dice Class: "); //Write title for code
     System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
     System.out.println(""); //Add a space between lines


     Scanner dicescanner= new Scanner(System.in); //Creates new scanner
     int replaygame=1; //Initializes replaygame variable used to create loop to run program again if the user wants

     do{ //Creates a do while loop


         final Dice humanuser; //Creates object for Dice class called humanuser
         final Dice computeruser; //Creates object for Dice class called computeruser

         System.out.print("Please enter how many dice you have: "); //Prints instructions
         int numdice=dicescanner.nextInt(); //Allows user to enter how dice both the computer and user are using in numdice variable
         dicescanner.nextLine(); //Makes sure enter button is accounted for after nextInt()


         System.out.print("Please enter how many sides are on your dice: "); //Prints instructions
         int dicesides=dicescanner.nextInt(); //Allows user to enter how many sides are on the dice using the dicesides variable
         dicescanner.nextLine(); //Makes sure enter button is accounted for after nextInt()
         humanuser= new Dice(numdice,dicesides); //Creates new values for humanuser object assigning numdice and dicesides to its attributes
         computeruser= new Dice(numdice,dicesides); //Creates new values for humanuser object assigning numdice and dicesides to its attributes
         System.out.println(""); //Prints blank line
     

         System.out.println("Rolling your dice..."); //Prints out statement
         int usertotal=humanuser.rollDice(); //Does rollDice method for humanuser object and assigns it to usertotal variable used to compare with the computertotal variable who had the highest roll
         int computertotal=computeruser.rollDice(); //Does rollDice method for computeruser object and assigns it to computertotal variable used to compare with the usertotal variable who had the highest roll
         System.out.println(""); //Prints blank line


         if(usertotal>computertotal) //If statement is true the following code runs. Means the total value the user rolled is greater than the total value the computer rolled
          {
             System.out.println("The user won the roll! The user rolled a total of "+usertotal+" while the computer rolled a total of "+computertotal+"!\n"); //Prints out statement
          }
         else if(computertotal>usertotal) //If statement in line 42 is not true and if boolean expression is true following code runs
         {
             System.out.println("The computer won the roll! The computer rolled a total of "+computertotal+" while the user rolled a total of "+usertotal+"!\n"); //Prints out statement
         }
         else if(usertotal==computertotal) //If statement in line 42 and 71 are not true and if boolean expression is true following code runs
         {
             System.out.println("You both tied! Both of you rolled a total of "+usertotal+"!\n"); //Prints out statement         
         }

         System.out.print("Would you like to play again? Enter 1 to replay enter any other number to quit: "); //Prints out instructions
         replaygame=dicescanner.nextInt(); //Allows user to enter a value for replaygame which decides if the user wants to play again
         dicescanner.nextLine(); //Makes sure enter button is accounted for after nextInt()
         System.out.println("\n\n\n"); //Prints three blank line


     }while(replaygame==1); //Repeats do while loop until the statement becomes false


     System.out.println("Thanks for playing!"); //Prints out statement




  }


}
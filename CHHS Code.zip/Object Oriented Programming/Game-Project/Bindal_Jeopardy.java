import java.util.Scanner; //Imports Scanner class





/* Game Project Pseudocode




1. Get Information:


   1.1 Have player1 enter their playername
   1.2 Have player2 enter their playername

   1.3 After 3.2 have the user enter Yes or No to determine if they want a hint to help answer the question

   1.4 After 3.3 have the user decide beteween the answer choices choosing between A,B,C, or D
   1.5 After 3.4 have the user reenter the answer choice to continue to guess

   1.6 Contiune to repeat 1.5 and its parts asking the player to enter an answer choice until the select the correct one

   1.7 After 3.8 ask the user if they want to repeat the game by entering "Yes" or "No" and repeat the game code until the user says "No"






2.Do Calculations:


   2.1 If the player chooses "Yes" in 1.3 decrease the totalpoints for the player and increase the hintsused variable

   2.2 Once the player has guessed in 1.4 increase the guessesstaken and guessesused variable by 1
   2.3 If the use guesses the wrong answer in 1.4 after 1.5 increase the guessestaken and gussesused variable by 1 and decrease the total points for the player

   2.4 Once the user has guesses the right answer and exits the loop in 1.6 calculate the total points the player gets for the round based on the question number a set constant and the number in guessesused. Also edit the total points of the player object. Increase the questions correct variable also

   2.5 After both players have had a chance to answer the question it updates the indexvalue by 1 which is used to move the players to the next question and later the next country. 




3. Print Results:


     3.1 Print out the instructions for how to play the game and how many questions to answer after 1.1 and 1.2

     3.2 Print out whose turn it is, the question number, the actual question, and the answer choices to the question.


     3.3 
         A. If the user chose "Yes" print out the hint variable for the question and print out the answer choices to the question again
         B. If the user chose "no" print out the answer chocies to the questions again


     3.4 If the user chooses the wrong answer in 1.4 print out the answer choices to the quesiton again

     3.5 Print out how many points the user won and the toString for it
     3.6 After 3.5 print out the user has moved onto the next country and set the countrylocation variable to the next element in the array containing countries

     3.7 Has a loop that sends in one player the question from the array and the country from a seperate array which are utlized by the PlayerRun method to perform the actual game. This is then swapped out with the other player while keeping the same question and country so that the players can alternate between themselves. This contiunes using a loop until all the quesitons in the array have been answered

     
     3.8 
         A. Once the loop in 3.7 has ended if the total points for player 1> than total points for player 2 print out that player 1 wins. Then print out the toString for each player.
         B. Once the loop in 3.7 has ended if the total points for player 2> than total points for player 1 print out that player 2 wins. Then print out the toString for each player.
         C. Once the loop in 3.7 has ended if the total points for player 1== than total points for player 2 print out that both players tied. Then print out the toString for each player.









*/







public class Jeopardy{ //Creates new class called Jeopardy used to run the actual game






   private Player player1; //Creates private object from Player class called player1
   private Player player2; //Creates private object from Player class called player2

 
  



   public void PlayerRun(Player player, Question question, String country) //Creates a void method that takes in three parameters a player object, a question object, and a String for the country. This is used to run the majority of the game.
   {





       String useranswerchoice=""; // Creates String value called useranswerchoice which is used by the user to guess answer choices
       Scanner Jeopardyscanner= new Scanner(System.in); //Creates new scanner
       String recievehint=""; //Creates a String value called recivehint which is used to see if the user wants to have a hint
       double guessesused=0; //Creates double value called guessesused which is used to record how many guesses the user has used on a question





       System.out.println(player.getPlayername()+"'s Turn\n"+question.getQuestionnumber()+". "+question.getQuestionname()+" Good Luck!"); //Prints out statement


       System.out.print("\nAnswer Choices: \n"+question.getAnswerchoices()); //Prints out statement




       System.out.print("\n\nThere is a hint available. Would you like a hint? (You will lose points if you use a hint) Yes or No\nEnter the word that cooresponds with what you want to do: "); //Prints out instructions
       recievehint=Jeopardyscanner.nextLine(); //Allows the user to enter a String value to recivehint used
       System.out.println("\n"); //Adds blank space



       if(recievehint.equalsIgnoreCase("Yes")) //If if statement is true following code runs
       {


           System.out.println("You chose to take a hint! You lost points!"); //Prints out following statement
           player.editHintsused(player.getHintsused()+1); //Increases hintsused variable by 1
           player.editTotalpoints(player.getTotalpoints()-75); //Decreaes totalpoints variable by 1

           System.out.println("\nYour hint: "+question.getQuestionhint()+"\n\n");

           System.out.print("Answer Choices: \n"+question.getAnswerchoices()+"\nChoose the letter that cooresponds to the answer you want: "); //Prints out instructions
           useranswerchoice=Jeopardyscanner.nextLine(); //Allows user to enter a String value to useranswerchoice variable

           player.editGuessestaken(player.getGuessestaken()+1); //Increases guessesstaken variable by 1
           guessesused++; //Increases guesses used by 1


       }


       else if(recievehint.equalsIgnoreCase("No")) //If if statement in line 86 is false and this if statement is true following code runs
       {


           System.out.println("You chose to not take a hint!\n\n"); //Prints out statement

           System.out.print("Answer Choices: \n"+question.getAnswerchoices()+"\nChoose the letter that cooresponds to the answer you want: "); //Prints out instructions
           useranswerchoice=Jeopardyscanner.nextLine(); //Allows user to enter a String value to useranswerchoice variable
           
           player.editGuessestaken(player.getGuessestaken()+1); //Increases guessesstaken variable by 1
           guessesused++; //Increases guesses used by 1


       }





       while(!(useranswerchoice.equalsIgnoreCase(question.getQuestionanswer()))) //Runs following code until while loop becomes false
       {


           player.editTotalpoints(player.getTotalpoints()-50); //Decrease the totalpoints of the player by 50 for getting the question wrong

           System.out.print("\n\nSorry that was the wrong answer, you have lost points! Try again: \n"+question.getAnswerchoices()+"\nChoose the letter that cooresponds to the answer you want: "); //Prints out insturctions
           useranswerchoice=Jeopardyscanner.nextLine(); //Allows user to enter a String value to useranswerchoice variable

           player.editGuessestaken(player.getGuessestaken()+1);  //Increases guessesstaken variable by 1
           guessesused++; //Increases guesses used by 1


       }





       if(useranswerchoice.equalsIgnoreCase(question.getQuestionanswer())) //If if statement is true following code runs
       {


           double guessbonus=(300*question.getQuestionnumber())/(guessesused/3); //Does calculation to determine how many points the player should get based on the number of guesses they used
           player.editTotalpoints((750*question.getQuestionnumber())/(guessesused/3)); //Changes totalpoints variable based on the number of guesses the player used in this round

           player.editQuestionscorrect(player.getQuestionscorrect()+1); //Increases questionscorrect variable by 1

           System.out.println("\n\nCongratulations you answered correct!\n\n"+question+"\n\nGuess Bonus: "+guessbonus+"\n\n"+player); //Prints out statement


       }
       
       



       System.out.println("\nCongratulations you have moved on to the next country! You were in: "+player.getCountrylocation()+", you have now moved onto: "+country+".\n\n\n"); //Prints out statement
       player.editCountrylocation(country); //Changes countrylocation variable for the player





   }






   public void run() //Creates public void method that alternates between characters who answer the question. It also prints out the final statement for the winner
   {
    




   Scanner Jeopardyscanner= new Scanner(System.in); //Creates new scanner
   String repeatgame="Yes"; //Creates String variable used to repeat the game once it is over





   Question[] questionArray=new Question[4]; //Creates an array of Question objects storing four question objects that have the questions that the players are being asked


   questionArray[0]=new Question(1,"Whose DNA sequence is stored on the ISS to have their DNA immortalized?","A. Martin Luther King Jr. \nB. Franklin Delano Roosevelt\nC. Stephen Hawking \nD. Albert Einstien","C","This person was considered one of the greatest in their field of science."); //Assigns the first position of the questionArray to a new Question object


   questionArray[1]=new Question(2,"What part of the body did ancient Egyptians used to shave to mourn the death of a cat?","A. Eyebrows\nB. Head\nC. Face (Beard) \nD. Chest", "A","Due to how hot Egypt was many men lacked tradtional hair features to stay cool and used fakes instead."); //Assigns the second position of the questionArray to a new Question object


   questionArray[2]=new Question(3, "How old is the oldest shark in the world?","A. ~462 Years\nB. ~220  Years\nC. ~885 Years \nD. ~393 Years", "D","The shark is older than the United States of America formed in 1776." ); //Assigns the third position of the questionArray to a new Question object


   questionArray[3]=new Question(4,"Who was the first person on the USA one dollar bill?","A. Christopher Columbus \nB. George Washington\nC. Abraham Lincoln \nD. Salmon Chase","D","The first one dollar note was formed in 1862 during the American Civil War"); //Assigns the fourth position of the questionArray to a new Question object




   String[] countryArray= new String[4]; //Creates an array of Strings called countryArray used to store the differnet countries or stages the players go through


   countryArray[0]="Brazil"; //Sets the first element of the countryArray to "Brazil"
   
   countryArray[1]="South Africa"; //Sets the second element of the countryArray to "South Africa"

   countryArray[2]="Mongolia"; //Sets the third element of the countryArray to "Mongolia"

   countryArray[3]="Japan"; //Sets the fourth element of the countryArray to "Japan"





   do{ //Creates do while loop




         System.out.print("Player one please enter your name: "); //Prints out instructions
         String player1name=Jeopardyscanner.nextLine(); //Runs .nextLine to be sure enter value is added to input //Allows user to enter name of player one



         System.out.print("Player two please enter your name: "); //Prints out Instructions
         String player2name=Jeopardyscanner.nextLine(); //Runs .nextLine to be sure enter value is added to input //Allows user to enter name of player two 

         System.out.println("\n\n"); //Creates blank line



         player1= new Player(1000,0,0,0,"United States of America",player1name); //Player class constructor for player1 object
         player2= new Player(1000,0,0,0,"United States of America",player2name); //Player class constructor for player2 object

         int indexvalue=0; //Creates integer value called indexvalue which is used to update what question the players are on in the questionArray 



         
         System.out.println("How to play: This game is a form of trivia where the two player will be competing against each other. You will be presented with a trivia question and the player has to answer correctly to move onto the next stage designated by country. Once one player has guessed a trivia question or has failed to the other player has the chance to guess the same question. As the game goes on the questions become more difficult. The goal of the game is to be the player with the highest point which is done by guessing the answer using the fewest guesses, answering harder questions, and using the fewest hints. Both players start with 1000 points. ***You have "+(questionArray.length-1)+" questions to answer!***\n\n\n"); //Prints out statement about game instructions
         



         do{ //Creates do while loop



              PlayerRun(player1,questionArray[indexvalue],countryArray[indexvalue]); //Sets player1 object as player variable in PlayerRun method and questionArray[indexvalue] as the question variable in the PlayerRun method


              PlayerRun(player2,questionArray[indexvalue],countryArray[indexvalue]); //Sets player2 object as player variable in PlayerRun method and questionArray[indexvalue] as the question variable in the PlayerRun method


              indexvalue++; //Increases the value of indexvalue by 1 to move to the next question



         }while(indexvalue<questionArray.length); //Continues to run





         if(player1.getTotalpoints()>player2.getTotalpoints()) //If if statement is true following code will run
         {


             System.out.println(player2.getPlayername()+" lost! Congratulations "+player1.getPlayername()+" you won!\n"); //Prints out statement

             System.out.println(player1); //Prints out toString for player1

             System.out.println("\n\n"+player2); //Prints out toString for player2


         }



         else if(player2.getTotalpoints()>player1.getTotalpoints()) //If if statement is true following code will run
         {
           

             System.out.println(player1.getPlayername()+" lost! Congratulations "+player2.getPlayername()+" you won!\n"); //Prints out statement

             System.out.println(player2); //Prints out toString for player2

             System.out.println("\n\n"+player1); //Prints out toString for player1


         }



         else if(player1.getTotalpoints()==player2.getTotalpoints()) //If if statement is true following code will run
         {


             System.out.println(player1.getPlayername()+" and "+player2.getPlayername()+" tied with the exact same points!\n"); //Prints out statement

             System.out.println(player1); //Prints out toString for player1

             System.out.println("\n\n"+player2); //Prints out toString for player2


         }
         




         System.out.print("\n\n\nWould you like to play again? Yes or No\nEnter the word that cooresponds with what you want to do: "); //Prints out statement
         repeatgame=Jeopardyscanner.nextLine(); //Allows user to enter an String value to repeatgame to decide if they want to continue to play the game.

         System.out.println("\n\n"); //Adds blank space




   }while(repeatgame.equalsIgnoreCase("Yes")); //Continues to run loop until following statement becomes false. This means that the players does not want to continue playing the game.





   System.out.println("Thanks for playing!"); //Prints out statement





   }




  

}
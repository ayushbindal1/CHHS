class Main { //Creates new class




  public static void main(String[] args) {



     System.out.println("Jeopardy Game: "); //Write title for code
     System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
     System.out.println(""); //Add a space between lines


      Jeopardy newgame= new Jeopardy(); //Creates new object for Jeopardy class
      newgame.run(); //Runs run method in Jeopardy class



  }




}
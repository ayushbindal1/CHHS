public class Question{ //Creates new class




    private int questionnumber; //Creates variable to store the question number
    private String questionname; //Creates variable to store the actual question the user is being asked
    private String answerchoices; //Creates variable to store the answer choices for a question
    private String questionanswer; //Creates variable to store answer to the question
    private String questionhint; //Creates variable to store a hint to help answer the question





    public Question() //Creates constructor
    {
       questionnumber=0; //Sets questionnumber variable to zero or empty
       questionname=""; //Sets questionname variable to empty 
       answerchoices=""; //Sets answerchoices variable to empty
       questionanswer=""; //Sets questionanswer variable to empty 
       questionhint="";  //Sets questionhint variable to empty
    }


 public Question(int userquestionnumber, String userquestionname,String useranswerchoices, String userquestionanswer, String userquestionhint) //Creates another constructor that allows assignment to variables
 {
     questionnumber=userquestionnumber; //Sets questionnumber variable to userquestionnumber variable
     questionname=userquestionname; //Sets questionname variable to userquestionname variable
     answerchoices=useranswerchoices; //Sets answerchoices variable to useranswerchoices variable;
     questionanswer=userquestionanswer; //Sets questionanswer variable to userquestionanswer variable
     questionhint=userquestionhint; //Sets questionhint variable to userquestionhint variable

 }




 public int getQuestionnumber() //Creates accessor to return an int value
 {
      return questionnumber; //Returns variable
 }


  public String getQuestionname() //Creates accessor to return an String value
 {
      return questionname; //Returns variable
 }


 public String getAnswerchoices() //Creates accessor to return an String value
 {
     return answerchoices; //Returns variable
 }


 public String getQuestionanswer() //Creates accessor to return an String value
 {
      return questionanswer; //Returns variable
 }


 public String getQuestionhint() //Creates accessor to return an String value
 {
      return questionhint; //Returns variable
 }




  public void editQuestionnumber(int newQuestionnumber) //Creates modifiers to take in int value 
 {
     questionnumber=newQuestionnumber; //Sets totalpoints variable to newTotalpoints variable
 }


 public void editQuestionname(String newQuestionname) //Creates modifiers to take in String value 
 {
     questionname=newQuestionname;  //Sets guessestaken variable to newGuessestaken variable
 }


 public void editAnswerchoices(String newAnswerchoices) //Creates modifiers to take in String value 
 {
     answerchoices=newAnswerchoices;  //Sets answerchoices variable to newAnswerchoices variable
 }


  public void editQuestionanswer(String newQuestionanswer) //Creates modifiers to take in String value
 {
     questionanswer=newQuestionanswer; //Sets hintsused variable to newHintsused variable
 }


  public void editQuestionhint(String newQuestionhint) //Creates modifiers to take in String value
 {
     questionhint=newQuestionhint; //Sets questionscorrect variable to newQuestionscorrect variable
 }




 public String toString() //Creates toString
 {
      return "Question "+questionnumber+".\n"+questionname+"\nAnswer: "+questionanswer; //Returns following statement about all attributes of the question
 }




}
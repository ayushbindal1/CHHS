public class Player{ //Creates new class




    private double totalpoints; //Creates variable to store the total points of a player
    private int guessestaken; //Creates variable to store the total number of guesses a player takes
    private int hintsused; //Creates variable to store the total hints a player has used
    private int questionscorrect; //Creates variable to store the total questions the player has got correct
    private String countrylocation; //Creates variable to store the current country for the player
    private String playername; //Creates variable to store the name of the player





    public Player() //Creates constructor
    {
       totalpoints=0.0; //Sets totalpoints variable to zero or empty
       guessestaken=0; //Sets guessestaken variable to zero or empty
       hintsused=0; //Sets hintsused variable to zero or empty
       questionscorrect=0; //Sets questionscorrect variable to zero or empty
       countrylocation=""; //Sets countrylocation variable to empty 
       playername=""; //Sets playername variable to empty 
    }


 public Player(double userpoints, int userguesses, int userhints, int userquestionscorrect, String usercountrylocation, String userplayername) //Creates another constructor that allows assignment to variables
 {
     totalpoints=userpoints; //Sets totalpoints variable to userpoints variable
     guessestaken=userguesses; //Sets guessestaken variable to usergusses variable
     hintsused=userhints; //Sets hintsused variable to userhints variable
     questionscorrect=userquestionscorrect; //Sets questionscorrect variable to userquestionscorrect variable
     countrylocation=usercountrylocation; //Sets countrylocation variable to usercountrylocation variable
     playername=userplayername; //Sets playername variable to userplayername variable
 }




 public double getTotalpoints() //Creates accessor to return an double value
 {
      return totalpoints; //Returns variable
 }


  public int getGuessestaken() //Creates accessor to return an int value
 {
      return guessestaken; //Returns variable
 }


 public int getHintsused() //Creates accessor to return an int value
 {
      return hintsused; //Returns variable
 }


 public int getQuestionscorrect() //Creates accessor to return an int value
 {
      return questionscorrect; //Returns variable
 }


 public String getCountrylocation() //Creates accessor to return a String value
 {
      return countrylocation; //Returns variable
 }


 public String getPlayername() //Creates accessor to return a String value
 {
      return playername; //Returns variable
 }




 public void editTotalpoints(double newTotalpoints) //Creates modifiers to take in a double value 
 {
     totalpoints=newTotalpoints; //Sets totalpoints variable to newTotalpoints variable
 }


  public void editGuessestaken(int newGuessestaken) //Creates modifiers to take in int value 
 {
     guessestaken=newGuessestaken;  //Sets guessestaken variable to newGuessestaken variable
 }


  public void editHintsused(int newHintsused) //Creates modifiers to take in int value
 {
     hintsused=newHintsused; //Sets hintsused variable to newHintsused variable
 }


  public void editQuestionscorrect(int newQuestionscorrect) //Creates modifiers to take in int value
 {
     questionscorrect=newQuestionscorrect; //Sets questionscorrect variable to newQuestionscorrect variable
 }


  public void editCountrylocation(String newCountrylocation) //Creates modifiers to take in int value
 {
     countrylocation=newCountrylocation; //Sets countrylocation variable to newCountrylocation variable
 }


 public void editPlayername(String newPlayer) //Creates modifiers to take in String value 
 {
     playername=newPlayer; //Sets playername variable to newPlayer variable
 }




 public String toString() //Creates toString
 {
      return playername+"'s Stats: \nCountry Location: "+countrylocation+"\nTotal Points: "+totalpoints+"\nGuesses Taken: "+guessestaken+"\nHints Used: "+hintsused+"\nQuestions Correct: "+questionscorrect; //Returns following statement about the attributes of the player object
 }




}
import java.util.Scanner;

/* Array Menu Program Psuedocode



1. Get Information:
   1.1 Have user enter a value for each element of the array to be set to
   1.2 Have user enter a value to mulitply each elemnt in the array by
   1.3 have the user eneter a value to raise each element in the array by


2. Do Calculations:
   2.1 Assign random values from 1-100 for each element of the array
   2.2 Multiply each element of the array by the number in 1.2
   2.3 Raise each element of the array by the number in 1.3
   2.4 Set the max value variable to the first element of the array.
   2.5 If an element of the array is greater than the value in 2.4 set it as the new max value. Do this for reach element.


3. Prints Results:
   3.1 Print out the new array values after the random numbers in 2.1
   3.2 Print out the new array values after the user value in 1.1
   3.3 Print out the new array values after the user multiply value in 2.2
   3.4 Print out the new array values after the user raise value in 2.3
   3.5 Print out the max value for the array calculated in 2.4 and 2.5





*/



class Main { 




   public void Menu() //Creates void Menu method that takes in no parameters
     {



       double[] arraymenulist=new double[50]; //Creates array with double value
       int repeatmenu=1; //Creates repeatmenu variable to hold value


       
       do{ //Creates do while loop
       Scanner arrayscanner= new Scanner(System.in); //Creates scanner



       System.out.println("1. Assign random values to the array (Use the Math.random method): \n"); //Prints out following statement
       for(int i=0; i<arraymenulist.length; i++)
         {
             arraymenulist[i]=((100*Math.random())+1); 
             System.out.print(Math.round(arraymenulist[i])+" ");
         }
        System.out.println("\n\n"); //Prints blank lines for space



         System.out.println("2. Set all values in the array to a user-inputted value: "); //Prints out following statement
         System.out.print("Please enter a value for the array: "); //Prints out following instructions
         double uservalue=arrayscanner.nextDouble(); //Allows user to enter a double value for the uservalue variable
         arrayscanner.nextLine(); //Makes sure enter button is accounted for after .nextDouble()
         for(int i=0; i<arraymenulist.length; i++) //Creates for loop
         {
             arraymenulist[i]=uservalue; //Sets each element of the arraymenulist to uservalue that user entered
         }
         System.out.println("\n"); //Prints blank lines for space



         System.out.println("3. Print out the array-keep the values on the same line: ");
         System.out.println("\n"); //Prints out following statement
         for(int i=0; i<arraymenulist.length; i++)
         {
             System.out.print(arraymenulist[i]+" ");
         }
         System.out.println("\n\n"); //Prints blank lines for space

      

         System.out.println("4. Multiply all of the values in the array by a user-inputted scale factor (Every element of the array will be multiplied by the same number entered by the user): "); //Prints out following statement
         System.out.print("Please enter a value to multiply the array by: "); //Prints out following instructions
         double usermultiplyvalue=arrayscanner.nextDouble(); //Allows user to enter double value for usermultiplyvalue
         arrayscanner.nextLine(); //Makes sure enter button is accounted for  after .nextDouble()
         System.out.println("\n"); //Prints out blank line
         for(int i=0; i<arraymenulist.length; i++) //Creates for loop
         {
             arraymenulist[i]*=usermultiplyvalue; // Multiples each element of arraymenulist by usermultiplyvalue
             System.out.print(arraymenulist[i]+" "); //Prints out each element of arraymenulist
         }
         System.out.println("\n\n"); //Prints blank lines for space



         System.out.println("5. Ask the user for a number. Raise all of the values to that power: "); //Prints out following statement
         System.out.print("Please enter a value to raise the array by: "); //Prints out folloiwng statement 
         double userraisevalue=arrayscanner.nextDouble(); //Allows user to enter double value for userraisevalue
         arrayscanner.nextLine(); //Makes sure enter button is accounted for  after .nextDouble()
         System.out.println("\n"); //Prints out blank line
         for(int i=0; i<arraymenulist.length; i++) //Creates for loop
         {
             arraymenulist[i]=Math.pow(arraymenulist[i], userraisevalue); //Raises each element of arraymenulist to userraisevalue which user entered
             System.out.print(arraymenulist[i]+" "); //Prints out each element of the array
         }
         System.out.println("\n\n"); //Prints blank lines for space



         System.out.println("6. (5 Points Extra Credit): Print out the largest value in the array: "); //Prints out following statement
         double maxvalue=arraymenulist[0]; //Sets maxvalue variable to first element of arraymenulist
         for(int i=0; i<arraymenulist.length; i++) //Creates for loop
         {
             if(arraymenulist[i]>maxvalue) //If the element of the arraymenulist is greater than the current max value the following occurs
             {
                 maxvalue=arraymenulist[i]; //Sets maxvalue variable to current element value for arraymenulist
             }
         }
         System.out.println("Max Value Of The Array: "+maxvalue); //Prints out following statement
         System.out.println("\n\n"); //Prints blank lines for space



         System.out.print("1. Repeat Menu\nAny Other Number. Quit Menu\nEnter the number that correlates to what you would like to do: "); //Prints out following instructions
         repeatmenu=arrayscanner.nextInt(); //Allows user to enter in integer value for repeatmenu variable
         arrayscanner.nextLine(); //Makes sure enter button is accounted for after .nextInt()
         System.out.println("\n\n"); //Prints blank lines for space



         }while(repeatmenu==1); //Will continue to run Menu() method until the statement becomes false which the user will enter
       System.out.println("Good Bye!"); //Prints out following statement
     }


  public static void main(String[] args) {



     System.out.println("Array Menu Program: "); //Write title for code
     System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
     System.out.println(""); //Add a space between 

     
     Main run= new Main(); //Creates object to run Main class
     run.Menu(); //Calls Menu Method to run program



    
     







  }



}
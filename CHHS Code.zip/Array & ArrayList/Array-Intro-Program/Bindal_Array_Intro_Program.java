import java.util.Scanner;

/* Array Intro Program Psuedocode


1. Get Information:
   1.1 Allow the user to enter a integer value for the first element of the list
   1.2 Allow the user to enter a integer value for the second element of the list


2. Do Calculations:
   2.1 Create a random number for each of the five elements of the array from 1-100
   2.2 Calculate the sum of the array element value from 2.1
   2.3 Calculate the average of the array element values from 2.1 by 2.2/5
   2.4 Set the last element in the list equal to the first element in the list
   2.5 Set the second to last element in the list equal to the second element in the list


3. Print Result:

   3.1 Print out each value for each element created in 2.1
   3.2 Print out the sum calculated in 2.2
   3.3 Print out the average calculated in 2.3
   3.4 Print out the five elements using the new values in 1.1 and 1.2
   3.5 Print out the five elements using the new values in 2.4 and 2.5 



*/



class Main {
  public static void main(String[] args) {



     System.out.println("Array Intro Program: "); //Write title for code
     System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
     System.out.println(""); //Add a space between lines
     Scanner arrayscanner= new Scanner(System.in); //Creates scanner


     int[] intronumlist= new int[5]; //Creates new array called intronumlist with 5 int values
     intronumlist[0]=((int)(100*Math.random())+1); //Assigns a random number from 1 to 100 to the first element of intronumlist
     intronumlist[1]=((int)(100*Math.random())+1); //Assigns a random number from 1 to 100 to the second element of intronumlist
     intronumlist[2]=((int)(100*Math.random())+1); //Assigns a random number from 1 to 100 to the third element of intronumlist
     intronumlist[3]=((int)(100*Math.random())+1); //Assigns a random number from 1 to 100 to the fourth element of intronumlist
     intronumlist[4]=((int)(100*Math.random())+1); //Assigns a random number from 1 to 100 to the fifth element of intronumlist
     

     System.out.println("Random Value Array: \nFirst Value: "+intronumlist[0]+"\nSecond Value: "+intronumlist[1]+"\nThird Value: "+intronumlist[2]+"\nFourth Value: "+intronumlist[3]+"\nFifth Value: "+intronumlist[4]); //Prints out following statement
     System.out.println(""); //Add a space between lines

    
     int sumvalue=intronumlist[0]+intronumlist[1]+intronumlist[2]+intronumlist[3]+intronumlist[4]; //Assigns sum of elements in list to sumvalue
     System.out.println("Sum of Five Numbers in List: "+sumvalue); //Prints out following statement
     System.out.println(""); //Add a space between lines


     int averagevalue=(sumvalue/(intronumlist.length)); //Assigns average of elements of list to averagevalue
     System.out.println("Average of Five Numbers in List: "+averagevalue); //Prints out following statement 
     System.out.println(""); //Add a space between lines
     

     System.out.print("Enter a value for the first element of the list: "); //Prints out instructions
     intronumlist[0]=arrayscanner.nextInt(); //Allows the user to enter an integer value for the first element of the intronumlist
     arrayscanner.nextLine(); //Makes sure the enter button is accounted for after doing a .nextInt();
     System.out.println(""); //Add a space between lines

     System.out.print("Enter a value for the second element of the list: "); //Prints out instructions
     intronumlist[1]=arrayscanner.nextInt(); //Allows the user to enter an integer value for the second element of the intronumlist
     arrayscanner.nextLine(); //Makes sure the enter button is accounted for after doing a .nextInt();
     System.out.println(""); //Add a space between lines


     System.out.println("User-entered Array: \nFirst Value: "+intronumlist[0]+"\nSecond Value: "+intronumlist[1]+"\nThird Value: "+intronumlist[2]+"\nFourth Value: "+intronumlist[3]+"\nFifth Value: "+intronumlist[4]); //Prints out following statement
     System.out.println(""); //Add a space between lines


     intronumlist[intronumlist.length-1]=intronumlist[0]; //Assigns first value of the intronum list to the last or 5th value of the intronumlist
     intronumlist[intronumlist.length-2]=intronumlist[1]; //Assigns second value of the intronum list to the second to last or 4th value of the intronumlist


     System.out.println("First/Last and Second/Second-to-Last Values Equal Array: \nFirst Value: "+intronumlist[0]+"\nSecond Value: "+intronumlist[1]+"\nThird Value: "+intronumlist[2]+"\nFourth Value: "+intronumlist[3]+"\nFifth Value: "+intronumlist[4]); //Prints out following statement



  }



}
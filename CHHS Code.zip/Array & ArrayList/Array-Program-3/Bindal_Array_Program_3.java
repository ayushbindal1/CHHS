import java.util.Scanner;

/* Array Menu Program Psuedocode



1. Get Information:
   1.1 Have the user enter a test grade between 1-100 for each of the 10 elements of the array



2. Do Calculations:
   2.1 Assign random value from 1-100 for each of the 20 elements of an array
   2.2 Add each random value of the array from 2.1 then divide by the length of the array in 2.1 to get the average
   2.3 Using the test grades from 1.1 calculate the GPA sum value
       2.3A If Test Grade>=90 and Test Grade<=100 set the GPA value to 4.0
       2.3A If Test Grade>=80 and Test Grade<=89 set the GPA value to 3.0
       2.3A If Test Grade>=70 and Test Grade<=79 set the GPA value to 2.0
       2.3A If Test Grade>=60 and Test Grade<=69 set the GPA value to 1.0
       2.3A If Test Grade<60 set the GPA value to 0.0
   2.4 Divide the GPA sum value from 2.3 by the length of the array in 1.1 to get the GPA



3. Prints Results:
   3.1 Print out the array from 2.1
   3.2 Print out the average calculated in 2.2
   3.3 If an element of the array in 2.1 is greater than the average in 2.2 print out the element of the array
   3.4 Print out the GPA calculated in 2.4




*/




class Main {




  public static void main(String[] args) {



     System.out.println("Array Extra Credit: "); //Write title for code
     System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
     System.out.println(""); //Add a space between
     Scanner arrayScanner=new Scanner(System.in); //Creates Scanner



     System.out.println("1. Assign random values to an array of 20 real numbers. Calculate the average.  Print the array, and then print all of the numbers that are greater than the average: \n"); //Prints out following statement


     double[] randomArray=new double[20]; //Creates new Array with double value
     double averagesum=0; //Creates new double variable used for average


     for(int i=0; i<randomArray.length; i++) //Creates for loop
     {
         randomArray[i]=((100*Math.random())+1); //Assigns random number from 1-100 to each element of randomArray

         averagesum+=randomArray[i]; //Adds each element of randomArray to averagesum

         System.out.print(randomArray[i]+"  "); //Prints out following statement
     }


     double average=averagesum/randomArray.length; //Calculates average by dividing averagesum with length of randomArray
     System.out.println("\n\nAverage value of array: "+average); //Prints out folloiwng statement


     System.out.print("\nValues greater than average: "); //Prints out folloiwng statement
     for(int i=0; i<randomArray.length; i++) //Creates for loop
     {

         if(randomArray[i]>average) //If if statement is true following code runs
         {
             System.out.print(randomArray[i]+"  "); //Prints out folloiwng statement
         }

     }

   

   System.out.println("\n\n\n\n2. Create an array of 10 integers representing test grades. Have the user type in values for the ten elements of the array (Use a loop). Calculate the GPA of the student using the following key: 90-100= 4.0, 80-89=3.0, 70-79=2.0, 60-69=1.0, under 60=0. (The answer should be a real number, I.E. 3.5.): \n"); // //Prints out folloiwng statement
  


   int[] GPAArray=new int[10]; //Creates new Array with 10 int values
   double GPAsum=0; //Sets GPAsum to zero to calculate sum


     for(int i=0; i<GPAArray.length; i++) //Creates for loop
     {
         System.out.print("Please enter one test grade: "); //Prints out folloiwng statement
          GPAArray[i]=arrayScanner.nextInt(); //Allows user to enter an integer value for each element of the GPAArray
          arrayScanner.nextLine(); //Makes sure enter button is accounted for when using .nextInt()

          if(GPAArray[i]>=90 && GPAArray[i]<=100) //If if statement is true following code runs
          {
              GPAsum+=4.0; //Adds 4.0 to GPAsum
          }

          if(GPAArray[i]>=80 && GPAArray[i]<=89) //If if statement is true following code runs
          {
              GPAsum+=3.0; //Adds 3.0 to GPAsum
          }

          if(GPAArray[i]>=70 && GPAArray[i]<=79) //If if statement is true following code runs
          {
              GPAsum+=2.0; //Adds 2.0 to GPAsum
          }

          if(GPAArray[i]>=60 && GPAArray[i]<=69) //If if statement is true following code runs
          {
              GPAsum+=1.0; //Adds 1.0 to GPAsum
          }

          if(GPAArray[i]<60) //If if statement is true following code runs
          {
              GPAsum+=0.0; //Adds 0.0 to GPAsum
          }

     }  


     double GPA=GPAsum/GPAArray.length; //Calculates GPA by dividing GPAsum by the length of the GPAArray
     System.out.println("\nThe GPA with the test numbers entered: "+GPA); //Prints out folloiwng statement



  }




}
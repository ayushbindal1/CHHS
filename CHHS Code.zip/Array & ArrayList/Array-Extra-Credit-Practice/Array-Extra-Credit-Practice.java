import java.util.Scanner;

class Main {
  public static void main(String[] args) {




     System.out.println("Array Extra Credit: "); //Write title for code
     System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
     System.out.println(""); //Add a space between
     Scanner arrayScanner=new Scanner(System.in);



     System.out.println("2. Create an array of 20 Strings.  Allow the user to enter values for the Strings.  Print out each String along with the number of characters in the String.\n");
     String[] stringArray=new String[20];


     for(int i=0; i<stringArray.length; i++)
     {
         System.out.print("Please enter a string: ");
         stringArray[i]=arrayScanner.nextLine();
     }


     System.out.println("");


     for( int i=0; i<stringArray.length; i++)
     {
         System.out.println("String Entered: "+stringArray[i]+"      Number of Characters: "+stringArray[i].length());
     }



     System.out.println("\n\n3. Create an array of 25 test scores.  Read the 25 values into the array from the user (use a loop).  Calculate the average of the numbers.\n");
      int[] scoreArray= new int[25];
      int averagesum=0;


     for(int i=0; i<scoreArray.length; i++)
     {
         System.out.print("Please enter a test score: ");
         scoreArray[i]=arrayScanner.nextInt();
         arrayScanner.nextLine();
         averagesum+=scoreArray[i];
     } 


     System.out.println("\nThe average of the test scores: "+averagesum/scoreArray.length);




  }




}
import java.util.*; //imports library for Scanner
import java.io.File; //imports File class
import java.io.FileWriter; //imports FileWriter class
import java.io.IOException; //imports IOException class
class Main {




  
  public static void main(String[] args) throws IOException {


    

     System.out.print("\033[H\033[2J"); //Clears console command
     System.out.flush(); //Starts cursor at the top of the screen
     System.out.println("\u001b[34m"+"S"+"\u001b[31m"+"P"+"\u001b[33m"+"A"+"\u001b[34m"+"N"+"\u001b[32m"+"I"+"\u001b[31m"+"S"+"\u001b[34m"+"H"+"\u001b[0m"+" Translator: "); //Write title for code. It's got the Google colors.
     System.out.println("Ayush Bindal 4th Period CS III\n\n"); //Write Name, Class Period, and Class



    
     Scanner inputs = new Scanner(System.in); //Creates scanner for user input
     Map<String,String> translator = new HashMap<String,String>(); //Creates HashMap with both the key and value being Strings for the translation
     int option = 0; //An integer that represents what the user wants to do
     String original_term = ""; //A string that represents the user's original term
     String translated_term = ""; //A string that represents the user's translated term
     String addString = ""; //A string that represents the information going to be added to the Dictionary file. Used to see if the translation already exists
     boolean didBreak; //A boolean that determines if a while loop stopped determining if a translation already is in the Dictionary file
    Scanner fileScanner; //Initalizes the fileScanner



    
    //Used to see if the Dictionary text file already exists or if one needs to be created
    File tempFile = new File("Dictionary.txt"); 
    boolean exists = tempFile.exists(); //Used to determine if the Dictionary.txt file path exists
    if(exists==true) { //Creates a new Scanner if the file already exists
           fileScanner = new Scanner(new File("Dictionary.txt")); //Creates Scanner to read values from the Dictionary file  
    } else { //Creates a new File if one does not exist
           File file = new File("Dictionary.txt"); 
           file.createNewFile();
           fileScanner = new Scanner(new File("Dictionary.txt")); //Creates Scanner to read values from the Dictionary file 
    }
    
    //Copies values from the Dictionary.txt back to the translator HashMap if the program is closed
    while(fileScanner.hasNextLine()) { 
          String line=fileScanner.nextLine(); 
          String key_copy=line.substring(0,line.indexOf("=")-1); //Creates a String ("key_copy") which copies the substring containing the key
          String value_copy=line.substring(line.lastIndexOf("=")+2,line.length());
          translator.put(key_copy,value_copy); //Creates a String ("value_copy") which copies the substring containing the value
    }
    fileScanner.close(); //closes the fileScanner 



    
     do{ //Creates do-while loop

       
           
           try{ //try statement
                 //Takes user input for what option they want to do based on the number they enter
                 System.out.print("\u001b[34;1m"+"\n\n1.Create New Entry\n2.View One Entry\n3.View All Entries\n4.Instructions\n5.Exit"+"\u001b[0m"+"\nChoose the option you want to do: ");
                 option = inputs.nextInt();
                 inputs.nextLine();
                 System.out.println("\n\n");
                 if(option > 5 || option < 1) { //Forces user to reenter option if they choose a number that does not exist
                       System.out.println("NOT AN OPTION!");
                 }
           } catch (InputMismatchException e) { //catches exception if user enters something other than a number
                 inputs.next(); //Clears scanner so a infinite loop does not occur
                 System.out.println("\u001b[31m"+"\nNOT AN OPTION! ENTER A NUMBER:"+"\u001b[0m");
           }


       
          if(option == 1) { //Create New Entry Option
                 System.out.println("\u001b[34;1m"+"Create New Entry: "+"\u001b[0m");
                 Scanner reader = new Scanner(new File("Dictionary.txt"));  //Creates new Scanner to read through the Dictionary file to see if the entry the user is trying to add already exists   
                 original_term = ""; //sets original_term to empty so that it can go into the while loop
                 translated_term = ""; //sets translated_term to empty so that it can go into the while loop
                 didBreak = false; //sets didBreak to false as the default
                 
                 while(original_term.equals("")) { //Has the user enter the original term. If they enter nothing it continually asks them until they enter something.
                       System.out.print("\nPlease enter the original term: ");
                       original_term = inputs.nextLine().toUpperCase();
                       if(original_term.equals("")) {
                             System.out.println("ENTER A TERM!");
                       }
                 }
            
                 while(translated_term.equals("")) { //Has the user enter the translated term. If they enter nothing it continually asks them until they enter something.
                       System.out.print("Please enter the translation: ");
                       translated_term = inputs.nextLine().toUpperCase();
                       if(original_term.equals("")) {
                             System.out.println("ENTER A TRANSLATION!");
                       }
                 }  

            
                 translator.put(original_term,translated_term); //adds the original term as the key and the translated term as the value to the HashMap

            
                 addString = original_term+" == "+translated_term; //Creates String/line to add to the dictionary file
                 try { //try statement
                        //Goes through the dictionary text file using a Scanner checking to see if it already contains the translation the user has entered
                        while(reader.hasNextLine()) { 
                               if(reader.nextLine().equals(addString)) {
                                     didBreak = true; //sets the didBreak variable to true to make sure the value is or is not added to the text file
                                     break; //breaks out of the while loop if it finds the translation the user wants already exists
                               }
                        }
                   
                        if(!didBreak) { //If the while loop never stopped that means the translation is not in the file and is added
                             FileWriter writer = new FileWriter(new File("Dictionary.txt"), true); //Creates a new FileWriter that appends values to the "Dictionary.txt" 
                             writer.write("\n");
                             writer.write(addString);
                             
                             writer.close(); //clears the FileWriter to add more translations later on
                             System.out.println("\nYour translation has been added to our translator!");
                        } else { //translation already exists
                             System.out.println("\nYour translation is already in our translator!");
                        }
                         reader.close(); //Closes scanner once it has read through the file
                   
                 } catch (Exception e) { //catches any exceptions the Scanner creates
                        e.printStackTrace(); //handles exception
                 }     
          }

       

          if(option == 2) { //View One Entry Option
                 System.out.println("\u001b[34;1m"+"View One Entry: "+"\u001b[0m");
                 original_term = ""; //Sets the variable to empty so it can go through the while loop
            
                 while(original_term.equals("")) { //Has the user enter the original term they want translated. If they enter nothing it continually asks them until they enter something
                     System.out.print("\nPlease enter the original term you are looking for: ");
                     original_term = inputs.nextLine().toUpperCase();
                     if(original_term.equals("")) {
                            System.out.println("ENTER A TERM!");
                     }
                 }
            
                 if(translator.containsKey(original_term)) { //If the HashMap contains the origional_term (key) then it will print the translated version. If not then it prints the original term
                          System.out.println("Original Term: "+original_term+"\nTranslation: "+translator.get(original_term));
                 } else {
                       System.out.println("\nSorry your term ("+original_term+") does not have a translation!");
                 }
          }



          if(option == 3) { //View All Entries Option
                 System.out.println("\u001b[34;1m"+"View All Entries: "+"\u001b[0m");
            
                 try { //try statement
                       //Uses a scanner to print all lines from the Dictionary text file containing the translations
                       Scanner reader = new Scanner(new File("Dictionary.txt"));
                       while(reader.hasNextLine()) {
                             System.out.println(reader.nextLine()); 
                      }
                      reader.close(); //Closes the scanner once it prints all the lines
                 } catch (Exception e) { //catches any exceptions the Scanner creates
                       e.printStackTrace(); //handles exception
                 }
          }

       

          if(option == 4) { //Instructions Option
                 System.out.println("\u001b[34;1m"+"Instructions: "+"\u001b[0m");
                  System.out.println("You have five options to choose from:\n1.Add an Entry to the Dictionary by providing the original term and the translation\n2.View an Entry in the Dictionary by looking up the original term\n3.View ALL Entries in the Dictionary\n4.View Instructions\n5.Quit Using the Dictionary");
          }
       
          
        
     }while(option != 5); //Continues the do while loop until the user enters "5" meaning they want to quit


    

     System.out.println("\u001b[34;1m"+"GOODBYE!"+"\u001b[0m");
    


    
  }




  
}
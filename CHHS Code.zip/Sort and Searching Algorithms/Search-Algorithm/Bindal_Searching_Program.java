import java.util.Scanner;

class Main {




     public int binarySearch(int usersearchvalue, int sortingArray[]) //Creates a method that returns an integer value which is the position of the value the user entered. The parameters are the value the user wants to find in the array and the array itself.
     {



         int lastindex=(sortingArray.length)-1; //Creates lastindex variable which acts as the last position of the array by taking the length of the array and subtracting 1. This value will alwasy be at the end of the array and will change when the array is divided into two.

         int firstindex=0; //Creates firstindex variable which acts as the first value of the array by starting at 0. This array will always be at the beginnign of the array and will change positions when array is divided by two.


         while(firstindex<=lastindex) //Creates a while loop which contiunes to run until the firstindex value is greater than the lastindex value. The binary search works by creating a subarrarys based that either move the lastindex variable or the firstindex variable to shorten the values that are being looked at. At a certain point if they keep shrinking they will eventually meet and if they go past that point they start to check information that has already been checked making it redundant.This means that throughout the whole array their was no presence of the usersearchvalue.
         {


             int middleindex=(int)Math.floor((firstindex+lastindex)/2); //Finds the middleindex variable which is the middle index based on the firstindex and lastindex. This is what is being compared to the usersearchvalue to see if the value is present in the array.


             if(sortingArray[middleindex]==usersearchvalue) //If the value at the middlex index of the sortingArray is equal to the usersearchvalue that means that the usersearchvalue was found and runs the code segement.
             {
                 return middleindex; //Returns the middleindex variable which is the position at which the usersearchvalue was found. 
             }


             else if(sortingArray[middleindex]>usersearchvalue) //If the value at the middleindex is greater than the usersearchvalue the lastindex shifts so that it only looks at the values before the old middleindex. The array is sorted meaning that all the values before the old middleindex should be less than the middleindex value which should eventually contain the usersearchvalue. The usersearchvalue should be contained in the left subarray.
             {
                 lastindex=middleindex-1; //Shifts the value of the lastindex variable to right before the middleindex. This decreases the amount of seraching required by half by only looking at the left subarray.
             }


             else if(sortingArray[middleindex]<usersearchvalue) //If the value at the middle index is less than the usersearchvalue the first index shifts so that it only looks at the values after the old middleindex. The array is sorted meanign that all the values after the old middleindex should be greater than the middleindex value which should eventually contain the usersearchvalue. The usersearch value should be contained in the right subarray.
             {
                 firstindex=middleindex+1; //Shifts the value of the firstindex variable to right after the middleindex. This decreases the amount of searching required by half by only looking at the right subarray.
             }



         }


         return -1; //Returns the value -1 to indicate that the usersearchvalue was not found in the array



     }



  public static void main(String[] args) {



     System.out.println("Searching Program: "); //Write title for code
     System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
     System.out.println(""); //Add a space between lines

     Scanner binaryscanner=new Scanner(System.in); //Creates a new scanner
     Main run=new Main(); //Creates new object called run for the Main class



     int[] sortingarray=new int[100]; //Creates an array of 100 int values called "sortingarray"
     int tempvalue=0; //Creates a int value called "tempvalue." This is used to store the first of two elements being compared if the first element is larger than the second. If the first value is larger than the second than the first value replaces the second value to be compared again. The tempvalue variable acts as a middle man for the two elements two swap places.




     System.out.println("Unsorted Array: \n"); //Prints out following statement
     for(int i=0; i<sortingarray.length; i++) //Creates for loop
     {
         sortingarray[i]=(int)((1000*Math.random())+1); //Assigns a random integer value to each element of the sortingarray from 1-1000 
     }
     


     for(int i=0; i<sortingarray.length; i++) //Creates for loop
     {
         System.out.print(sortingarray[i]+" "); //Prints out each element of the unsorted sortingarray on the same line
     }
     System.out.println("\n\n"); //Adds space between lines
     

   
     for(int i=0; i<sortingarray.length; i++) //Creates a for loop that scans through each element of the sortingarray which is currently unsorted. The elements in this are being compared to the rest of the array.
     {


         for(int j=i+1; j<sortingarray.length; j++) //For each element at "i" the for loop starts at the next element after "i" in the "sortingarray" and goes to the end of the array also called "j". Once a value at "j" is less than the value currently being compared at "i" the two values swap places having j become the new i. Then it continues to the end of the array repeating this process to find the smallest value after "i" sorting the array. Then it moves onto the next element of "i" repeating the process to sort the array.
         {
  
             if(sortingarray[i]>sortingarray[j]) //If a value at "j" is less than "i" this means that "i" which comes earlier in the array is not the smallest value and swaps places with a smaller value.
             {  
               
                 tempvalue=sortingarray[i]; //Stores the value at "i" into a tempvalue variable later used to replace the value at "j" 
                 sortingarray[i]=sortingarray[j]; //Stores the value at "j" as the new value at "i" to compare to the rest of the array  
                 sortingarray[j]=tempvalue; //Stores the value in the tempvalue variable which is the old value at "i" as the new value of "j" which is later used to be compared to the rest of the array.  

             } 
              
         }  
         

     }  



     System.out.println("Sorted Array: \n"); //Prints out following statement 
     for(int i=0; i<sortingarray.length; i++) //Creates for loop
     {
         System.out.print(sortingarray[i]+" "); //Prints out each element of the sorted sortingarray on the same line
     }
    



     System.out.print("\n\nPlease enter a number you want to search for in the sorted array: "); //Prints out instructions
     int usersearchvalue=binaryscanner.nextInt(); //Allows the user to enter an int value that they want to look for in the array
     binaryscanner.nextLine(); //Makes sure the enter button is accounted for after using the .nextInt()
     System.out.println("\n"); //Adds space between lines


     int binarysearchvalue=run.binarySearch(usersearchvalue,sortingarray); //Runs binarySearch method sending in the usersearch value which is the value the user wants to look for in the other parameter the sorting array and returns the position which it found the userserachvalue. This value is stored in the binarysearchvalue variable to be used later.


     if(binarysearchvalue!=-1) //If the statement is true this means that the binarySearch method was able to find the usersearchvalue in the sortingarray
     {
         System.out.println("The value you entered ("+usersearchvalue+") is located at the "+binarysearchvalue+" position in array."); //Prints out following statement
     }


     else //If the statement is true this means that the binarySearch method did not find the usersearchvalue any where in the sortingarray
     {
         System.out.println("The value you entered ("+usersearchvalue+") is not found in the array."); //Prints out following statement
     }
 


  }




}
class Main {




  public static void main(String[] args) {



     System.out.println("Sorting Program: "); //Write title for code
     System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
     System.out.println(""); //Add a space between lines



     double[] sortingarray=new double[100]; //Creates an array of 100 double values called "sortingarray"
     double tempvalue=0; //Creates a double value called "tempvalue." This is used to store the first of two elements being compared if the first element is larger than the second. If the first value is larger than the second than the first value replaces the second value to be compared again. The tempvalue variable acts as a middle man for the two elements two swap places.



     System.out.println("Unsorted List: \n"); //Prints out following statement
     for(int i=0; i<sortingarray.length; i++) //Creates for loop
     {
         sortingarray[i]=((1000*Math.random())+1); //Assigns a random value to each element of the sortingarray from 1-1000 
     }
     


     for(int i=0; i<sortingarray.length; i++) //Creates for loop
     {
         System.out.print(sortingarray[i]+"    "); //Prints out each element of the unsorted sortingarray on the same line
     }
     System.out.println("\n\n"); //Adds space between lines
     

   
     for(int i=0; i<sortingarray.length; i++) //Creates a for loop that scans through each element of the sortingarray which is currently unsorted. The elements in this are being compared to the rest of the list.
     {

         for(int j=i+1; j<sortingarray.length; j++) //For each element at "i" the for loop starts at the next element after "i" in the "sortingarray" and goes to the end of the list also called "j". Once a value at "j" is less than the value currently being compared at "i" the two values swap places having j become the new i. Then it continues to the end of the list repeating this process to find the smallest value after "i" sorting the list. Then it moves onto the next element of "i" repeating the process to sort the list.
         {
  
             if(sortingarray[i]>sortingarray[j]) //If a value at "j" is less than "i" this means that "i" which comes earlier in the list is not the smallest value and swaps places with a smaller value.
             {  
               
                 tempvalue=sortingarray[i]; //Stores the value at "i" into a tempvalue variable later used to replace the value at "j" 
                 sortingarray[i]=sortingarray[j]; //Stores the value at "j" as the new value at "i" to compare to the rest of the list  
                 sortingarray[j]=tempvalue; //Stores the value in the tempvalue variable which is the old value at "i" as the new value of "j" which is later used to be compared to the rest of the list.  

             } 
              
         }  
         
     }  


     System.out.println("Sorted List: \n"); //Prints out following statement 
     for(int i=0; i<sortingarray.length; i++) //Creates for loop
     {
         System.out.print(sortingarray[i]+"    "); //Prints out each element of the sorted sortingarray on the same line
     }



  }




}
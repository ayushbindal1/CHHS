import java.util.Scanner;
/*
Psuedocode of Hypotenuse Calculator:
1. Get Information
1.1 Get length of the first leg.
1.2 Get length of the second leg.
2.Do Calculations
2.1=1.1^2
2.2= 1.2^2
2.3 Hypotenuse^2=2.1+2.2
2.4 Hypotenuse=Square root(Hypotenuse^2)
3. Print Results
3.1 Print Hypotenuse
*/
class Main {
  public static void main(String[] args) {
  System.out.println("Hypotenuse Calculator:"); // Title for Hypotenuse Calculator
  Scanner leg=new Scanner(System.in); //Declare new scanner
 double leg1; //Declare first leg variable
 double leg2; //Declare second leg variable
 System.out.println("Please enter the length of the two legs: "); //Print out what I want the user to enter
 leg1=leg.nextDouble(); //Scan for first double value
 leg2=leg.nextDouble(); //Scan for second double value
 System.out.println("Leg 1: "+leg1); //Print out the first leg value
 System.out.println("Leg 2: "+leg2); //Print out the second leg value
 System.out.println("Hypotenuse: "+(Math.sqrt((Math.pow(leg1, 2.00)+(Math.pow(leg2, 2)))))); //First take length of each leg and raise it to the power of two. Those values should be added together to get c^2. From there take the square root of that value to get the hypotenuse. Print out the hypotenuse value
  }
}
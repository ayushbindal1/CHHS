import java.util.Scanner;
/* If Statement Extra Credit Psuedocode
Get Information
1.1 Have the user enter their test grade
1.2 Repeat 1.1 3 more times
Do Calculations
2.1 Add four test grades from 1.1 and 1.2 and divide by four to get the average of their test grades
2.3 Compare 2.1 with 90
Print Results:
3.1 If 2.1>90 print out their average and that they have made the honor roll. If 2.1<90 print out their average and that they had not made the honor roll.
*/
class Main {
  public static void main(String[] args) {
    Scanner Honorroll= new Scanner(System.in); //Create a new scanner
    System.out.println("Honor Roll Calculator: "); //Write title for code
    System.out.println("By: Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
    int testgrade1; //Integer value for first test grade of user. This is used to find their average and see if they meet the threshold for achieving the honor roll.
    int testgrade2; //Integer value for second test grade of user. This is used to find their average and see if they meet the threhshold for achieving the honor roll.
    int testgrade3; //Integer value for third test grade of user. This is used to find their average and see if they meet the threhshold for achieving the honor roll.
    int testgrade4; //Integer value for fourth test grade of user. This is used to find their average and see if they meet the threhshold for achieving the honor roll.
    int averagetest;// Integer value for the average of all their tests which is directly compared to the threhshold to find out if they achieved the honor roll.
   System.out.println("Please enter your first test grade."); //Give instructions on what to enter
   testgrade1=Honorroll.nextInt(); //Input for a number the user creates
   System.out.println("Please enter your second test grade."); //Give instructions on what to enter
   testgrade2=Honorroll.nextInt(); //Input for a number the user creates
   System.out.println("Please enter your third test grade."); //Give instructions on what to enter
   testgrade3=Honorroll.nextInt(); //Input for a number the user creates
   System.out.println("Please enter your fourth test grade."); //Give instructions on what to enter
   testgrade4=Honorroll.nextInt(); //Input for a number the user creates
   averagetest=(testgrade1+testgrade2+testgrade3+testgrade4)/4; //Calcuates the average of their test grades which is calcuated by adding the test grade and dividing by the amount of tests taken.
  
   if (averagetest>90) //if the average is greater than 90 the statment below will be printed out.
     System.out.println("You made the honor roll. Congratulations! You had an average of "+averagetest+". You needed an average above 90."); //The statment will be printed out if their average is above 90.
   else //if the statment above is not true than it will run the program below.
     System.out.println("Sorry, you did not make the honor roll. You had an average of "+averagetest+". You needed an average above 90."); //This statment will be printed out if their average is below 90.

  }
}
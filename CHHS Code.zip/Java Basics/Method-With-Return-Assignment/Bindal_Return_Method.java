
/* Return Method Psuedocode


 1. Get Information:
   1.1 Have the user enter three double values to calculate the average
   1.2 Have the user enter two double values to calculate which number is closer to 20
   1.3 Have the user enter a string value to create a new string with the first an last two characters
   1.4 Have the user enter a string value to calculate the character in the middle of the string

 2. Do Calculations: 
   2.1 Create a random number between 1 and 10 for the first method.
   2.2 Add the three values in 1.1 and divide by 3 in order to calculate the average of those numbers
   2.3 Subtract the two numbers entered in 1.2 seperatly from 20 to see which is closest to 20. The smaller number is closer to 20 and vise versa.
   2.4 Calculate the length of the string value in 1.3 to find the last two characters of the string
   2.5 Calculate the length of the string value in 1.4 and divde by 2 to find the middle index of the string.

 3. Print Results:
   3.1 Prints out a different message based on the random number calculated in 2.1. If it is outside the random number values it prints out a seperate message
   3.2 If the average calcuated in 2.2 is above 50 it says that it is and returns true. If this is false it says that it is and returns false.
   3.3 Based on which number calculated in 2.3 is smaller it returns that number.
   3.4 Returns a new string with the first two and last two characters calculated in 2.4.
   3.5 Returns the chracter based on the index value calculated in 2.5


*/


class Main {
 

 public String methodone() //Creates a new method that returns a string value.
 {
   int randomnum=(int)((10*Math.random())+1); //Calculates random number between 1 and 10
   switch (randomnum) //Creates switch statement using the random number variable.
   {
     case 1: return "The random number is 1!"; //Returns following statement if randomnum=1.
     case 2: return "The random number is 2!"; //Returns following statement if randomnum=2.
     case 3: return "The random number is 3!"; //Returns following statement if randomnum=3.
     case 4: return "The random number is 4!"; //Returns following statement if randomnum=4.
     case 5: return "The random number is 5!"; //Returns following statement if randomnum=5.
     case 6: return "The random number is 6!"; //Returns following statement if randomnum=6.
     case 7: return "The random number is 7!"; //Returns following statement if randomnum=7.
     case 8: return "The random number is 8!"; //Returns following statement if randomnum=8.
     case 9: return "The random number is 9!"; //Returns following statement if randomnum=9.
     case 10: return "The random number is 10!"; //Returns following statement if randomnum=10.
     default: return "This is not between 1 and 10!"; //Returns following statement if randomnum is equal to anything other than 10 values
   }
 }
 

 public boolean methodtwo(double numaverage1, double numaverage2, double numaverage3) //Creates a method that takes in three double variables and returns a boolean variable
 {
   double averagenum=(numaverage1+numaverage2+numaverage3)/3; //Finds average of double variables
    if (averagenum>50) //If the statement is true it returns the following information
    {
      System.out.println("The average was above 50!"); //Prints out following statement
      return (averagenum>50); //Returns a boolean value if average is above 50.
    }
    else //If the if statement is false it retuns the following information
    {
      System.out.println("The average was below 50!"); //Prints out following statement
      return (averagenum>50); //Returns a boolean value if average is above 50.
    }
 }


 public double methodthree(double num1, double num2) //Creates a method that takes in two double variables and returns a double variable
 {
   double num1to20=20-num1; //Calculates how close num1 is to 20
   double num2to20=20-num2; //Calculates how close num2 is to 20
   if (num2to20>num1to20) //If the following statement is true than it prints out the following code. If a number is smaller than it is closer to 20 and vise versa.
   { 
     return num1; //Returns the num1 double value
   }
   else
   {
     return num2;  //Returns the num2 double value
   }
 }


 public String methodfour(String stringvalue1) //Creates a method that takes in one String variable and returns another string variable
 {
   int stringlength1=stringvalue1.length(); //Calculates the length of the String stringvalue1
   String newstring=(stringvalue1.substring(0,2)+stringvalue1.substring((stringlength1-2), (stringlength1))); //Calculates first and last two characters of the String stringvalue1
   return newstring; //Returns the String newstring which has the first and last two characters of the original String
 }


 public char methodfive(String stringvalue2) //Creates a method that takes in one String variable and returns a character variable
 {
   int stringlengthmiddle=(int)(stringvalue2.length()/2); //Calculates middle index of the stringvalue2
   char middlechar= stringvalue2.charAt(stringlengthmiddle); //Calculates the character at the stringlengthmiddle
   return middlechar; //Returns the middle character of the stringvalue2
 }


 public void driver() //Creates a method that runs all the other methods.
 {
   System.out.println("Random Statement: "); //Prints out following statement
   System.out.println(methodone()); //Calls methodone Method
   System.out.println(""); //Adds space between lines

   System.out.println("Average Calculator: "); //Prints out following statement
   System.out.println(methodtwo(numaverage1, numaverage2, numaverage3)); //Calls methodtwo Method with three double parameters
   System.out.println(""); //Adds space between lines

   System.out.println("Closest to 20: "); //Prints out following statement
   System.out.println(methodthree(num1, num2)); //Calls methodthree Method with two double variables
   System.out.println(""); //Adds space between lines

   System.out.println("First and last two characters: "); //Prints out following statement
   System.out.println(methodfour(stringvalue1)); //Calls methodfour Method with one string variable.
   System.out.println(""); //Adds space between lines

   System.out.println("Middle character: "); //Prints out following statement
   System.out.println(methodfive(stringvalue)); //Calls methodfive Method with one string variable.
 }


  public static void main(String[] args) {
   System.out.println("Return Methods: "); //Write title for code
   System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
   System.out.println(""); //Add a space between lines
   Main run = new Main(); //Creating an object of this class
   run.driver(); //Calls the driver method which stores all the information about the other methods
  }
}
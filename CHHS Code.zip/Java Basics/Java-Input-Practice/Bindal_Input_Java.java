import java.util.*;
class Main {
  public static void main(String[] args) {
    Scanner input=new Scanner(System.in); //1.
    String name; //1.
    System.out.println("Enter your name: "); //1.
    name=input.nextLine(); //1.
    System.out.println("Hi "+name+", nice to see you.");
   
   String name2; //2.
   String name3; //2.
   String name4; //2.
   System.out.println("Enter Three Names: "); //2.
   name2=input.nextLine(); //2.
   name3=input.nextLine(); //2.
   name4=input.nextLine(); //2.
   System.out.println(name4+" "+name3+" "+name2); //2.

   String name5; //3.
   String name6; //3.
   System.out.println("Hello there, what is your name?"); //3.
   name5=input.nextLine(); //3.
   System.out.println("What adjective describes you?"); //3.
   name6=input.nextLine(); //3.
   System.out.println("My name is "+name5+", I am "+name6+"."); //3.
  }
}
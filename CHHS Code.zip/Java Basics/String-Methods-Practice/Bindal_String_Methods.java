import java.util.Scanner;

class Main {
  /*
 String Method Psuedocode:
 Get Information:
 1.1 Have the user enter a sentence
 1.2 Have the user enter a word 
 1.3 Have the user enter an integer in order to find the character at that location for both the sentence and the phrase.
 1.4 Have the user enter one integers to find the  substring or the phrase between those two integer     locations
 Do Calculations:
 2.1 Repeat 1.4 2x
 2.2 Subtract 1 1.3 in order to get the actual character found in the sentence or word. Repeat 2x.
 Print Results:
 3.1 Print character length for sentence
 3.2 Print character length for word
 3.3 Print intger number for location of word in sentence. If it is not there then print -1.
 3.4 Print character for sentence found at the number caluclated in 2.2
 3.5 Print character for word found at the number caluclated in 2.2
 3.6 Print the string or phrase found between the two numbers found entered in 1.4
  */
  public static void main(String[] args) {
    Scanner stringmethod= new Scanner(System.in); // Create a new scanner

    System.out.println("String Methods: "); //Write title for code
    System.out.println("By: Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class

    String sentence; //Sentence that the user enters
    String word; //Word that the user enters
    int indexvalue; //Integer that user enters in order to find the location of a charcter at that number in both the word and sentence.
    int substring1; //Integer that the user enters in order to create parameter. This will create a phrase from the sentence.
    int substring2; //Integer that the user enters in order to create parameter. This will create a phrase from the sentence.

    System.out.println("Please enter a sentence: "); //Give instructions on what to enter
    sentence=stringmethod.nextLine(); //Input for a sentence the user creates
    System.out.println("Please enter a word: "); //Give instructions on what to enter
    word=stringmethod.next(); //Input for a word the user uses

    System.out.println("Character length of sentence entered: "+ sentence.length()); //Print out the character length of the sentence the user entered
    System.out.println("Character length of word entered: "+ word.length()); //Print out the character length of the word the user entered
    System.out.println("Location of your word in sentence: "+sentence.indexOf(word)); //Print the amount of characters in the sentence the user created that come before the word that the user created. If the word is not found in the sentence display -1.

    System.out.println("Please enter an integer: "); //Give instructions on what to enter
    indexvalue=stringmethod.nextInt(); //Input a integer value in order to get the index or location of a character
    System.out.println("Character found at integer value in sentence: "+ sentence.charAt(indexvalue-1)); //Print the character in the sentence found at the index value. Subtract 1 as the values start counting from zero.
    System.out.println("Character found at integer value in word: "+ word.charAt(indexvalue-1)); //Print the character in the word found at the index value. Subtract 1 as the values start counting from zero.

    System.out.println("Please enter two integers: "); //Give instructions on what to enter
    substring1=stringmethod.nextInt(); //Input an integer value in order to create parameter for a phrase
    substring2=stringmethod.nextInt(); //Input an integer value in order to create parameter for a phrase
    System.out.println("Phrase for the two values you have entered: "+sentence.substring(substring1, substring2)); //Print the phrase found in the sentence that was created using the two integers entered as parameters.
  }
}
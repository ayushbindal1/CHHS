import java.util.Scanner;

class Main {
 Scanner extracredit=new Scanner(System.in);
 public void smallestnumber()
 {
   System.out.println("Smallest Number Calculator: ");
   System.out.print("Please enter your first number: ");
   double num1=extracredit.nextDouble();
    System.out.print("Please enter your second number: ");
   double num2=extracredit.nextDouble();
   System.out.print("Please enter your third number: ");
   double num3=extracredit.nextDouble();
   if(num3>num1 && num2>num1)
   {
     System.out.println("The smallest number is: "+num1);
   }
   if(num1>num2 && num3>num2)
   {
     System.out.println("The smallest number is: "+num2);
   }
   if(num1>num3 && num2>num3)
   {
     System.out.println("The smallest number is: "+num3);
   } 
 }


 public void averagenumber()
 {
   System.out.println("Average Number Calculator: ");
   System.out.print("Please enter your first number: ");
   double number1=extracredit.nextDouble();
    System.out.print("Please enter your second number: ");
   double number2=extracredit.nextDouble();
   System.out.print("Please enter your third number: ");
   double number3=extracredit.nextDouble();
   double averagenumber=(number1+number2+number3)/3;
   System.out.println("The average of the numbers entered is: "+averagenumber);
 }


 public void leapyear()
 {
   System.out.println("Leap Year Clculator: ");
   System.out.println("Please enter a year: ");
   int year=extracredit.nextInt();
   double leapyearfinder= year%4;
   if(leapyearfinder==0)
   {
     System.out.println(year+" is a leap year!");
   }
   else
   {
     System.out.println(year+" is not a leap year!");
   }
 }
 


  public static void main(String[] args) {
    System.out.println("Void Methods");
   System.out.println("Ayush Bindal 5th Period PAP CS");
    System.out.println("");
   Main run = new Main();
   run.smallestnumber();
   System.out.println("");
   run.averagenumber();
   System.out.println("");
   run.leapyear();
  }
}
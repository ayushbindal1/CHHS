import java.util.Scanner;

class Main {
  /* If Statement Psuedocode:
Get Inforamation:
1.1 Have the user enter a side length of a triangle they have made up
1.2 Repeat 1.1 two more times in order to get all sides of a triangle
Do Calculations:
2.1 Compare the values from 1.1 and 1.2 to see largest side length
2.2 Compared the values from 1.1 and 1.2 to see if triangle has any equal side length values
2.3 Take two of the entered side lengths and square each one and add them together. This is compared to the other side length squared to see if they are equal.
2.4 Repeat 2.3 two more times
Print Results:
3.1 Print the longest side length that the user entered after being compared in 2.1.
3.2 Print if the triangle is or is not an isosceles, equailateral, or scalene triangle based on 2.2
3.3 Print if the triangle is or is not a right triangle after calculating it in 2.3 using pythagorean theorem.
  */

  public static void main(String[] args) {
   Scanner triangle= new Scanner(System.in); //Create a new scanner
    System.out.println("Triangle Identifier"); //Write title for code
    System.out.println("By: Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class

    int sideA; //Integer value for one side of the user's triangle. This will be compared with the other sides to determine if it is the longest, what type of triangle it is, and if it is a right triangle.
    int sideB; //Integer value for another side of the user's triangle. This will be compared with the other sides to determine if it is the longest, what type of triangle it is, and if it is a right triangle.
    int sideC; //Integer value for the final side of the user's triangle. This will be compared with the other sides to determine if it is the longest, what type of triangle it is, and if it is a right triangle.

    System.out.println("Please enter a integer value for side A of a triangle."); //Give instructions on what to enter
   sideA=triangle.nextInt(); //Input for a number the user creates
    System.out.println("Please enter a integer value for Side B of a triangle."); //Give instructions on what to enter
    sideB=triangle.nextInt(); //Input for a number the user creates
    System.out.println("Please enter a integer value for Side C of a triangle."); //Give instructions on what to enter
    sideC=triangle.nextInt(); //Input for a number the user creates
     if(sideA>sideB && sideA>sideC) //if Side A is greater than the two sides it will print out the statment below
       System.out.println("Side A is the longest side in your triangle, with a length of "+sideA+".");  //The statment that will be printed out if Side A is the largest side
     if(sideB>sideA && sideB>sideC) //if Side B is greater than the two sides it will print out the statment below
       System.out.println("Side B is the longest side in your triangle, with a length of "+sideB+".");//The statment that will be printed out if Side B is the largest side
     if(sideC>sideA && sideC>sideB) //if Side C is greater than the two sides it will print out the statment below
       System.out.println("Side C is the longest side in your triangle, with a length of "+sideC+".");//The statment that will be printed out if Side C is the largest side

      if(sideA==sideB && sideB==sideC) //if all the sides are equal than it will print out the statment below
         System.out.println("Your triangle is an equailateral triangle."); //The statment that will be printed out if all the sides are equal 
      if(sideA==sideB || sideA==sideC || sideB==sideC )  //if two of the sides are equal than it will print out the statment below
         System.out.println("Your triangle is an  isosceles triangle."); //The statment that will be printed out if two of the sides are equal
      if(sideA!=sideB && sideB!=sideC) //if none of the sides are equal than it will print out the statment below
         System.out.println("Your triangle is a scalene triangle."); //The statment that will be printed out if none of the sides are equal

      if((Math.pow(sideA,2))+(Math.pow(sideB,2))==Math.pow(sideC, 2) || (Math.pow(sideA,2))+(Math.pow(sideC,2))==Math.pow(sideB, 2) || (Math.pow(sideB,2))+(Math.pow(sideC,2))==Math.pow(sideA,2)) //This takes two sides of the triangle and square each side. Once they are squared they are added together. This is compared with the other side that has also been squared to see if they are equal forming a right triangle. This is repeated three times as we do not know which side is greater than another so this covers all side options.
       System.out.println("Your triangle is a right triangle."); //If the statement above is true than it will tell the user that the triangle they created is a right triangle
      else //if the statment above is not true than it will run the program below.
      System.out.println("Your triangle is not a right triangle."); //if the statement above is false than it will tell the user that the triangle they created is not a right triangle
  }
}
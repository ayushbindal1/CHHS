class Main {
  public static void main(String[] args) {
  /*  Pseudocode
  Input:
   Enter two integers and two real numbers.
  Calculations:
  Add two integers and two real numbers together.
  Output:
  Print four indivdual numbers and sum of four numbers and label of four numbers.
  */
    // The program is going to print and assign four values and print the sum of those 4 values.
   int number1=7; //Declare first integer
   int number2=9; //Declare second integer
   double number3=3.3; //Declare first real number
   double number4= 6.6; //Declare second real number
   double number5=0.0; // Declare third real number
   number5=number1+number2+number3+number4; //Add together the first two integers and first two real numbers to get sum of numbers
    System.out.println("Integer1: "+number1 +" Integer2: "+number2); //Print out the first two integers
   System.out.println("Realnumber1: "+number3            +" Realnumber2: "+number4); //Print out the first two real numbers
    System.out.println("Sum of Numbers: "+number5); //Print out the sum real number
  }
}
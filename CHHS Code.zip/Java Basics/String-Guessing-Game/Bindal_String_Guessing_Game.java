import java.util.Scanner;
class Main {

/* String Guessing Game Pseudocode
 Get Information:
 1.1 Have the user enter in a string in order to guess what object the program is thinking of.
 1.2 If 1.1 is not the exact same as the string the program is thinking of, let the user input another string in order to guess one more time.

 Do Calculations:
 2.1 Compare the string the user entered the first time to the string the program is thinking of in order to get a postive or negative value. This will determine if the user gets a second chance at guessing. If the strings value is 0 that means the string are the same.
 2.2 Compare the string the user entered the second time to the string the program is thinking of to see if they are equal.

 Print Results:
 3.1 If the string entered in 1.1 is equal to the string the program is thinking of than print out that the user guessed correctly.
 3.2 If the string entered in 1.1 in not equal to the string the program is thinking of than print out that the user guessed incorrectly and give the user a second chance at guessing. If the string is greater than 0 which is found in 2.1 tell the user that their string comes first in the alphabet.
 3.3 If the string entered in 1.1 in not equal to the string the program is thinking of than print out that the user guessed incorrectly and give the user a second chance at guessing. If the string is less than 0 which is found in 2.1 tell the user that their string comes second in the alphabet.
 3.4 If 1.2 occurs and 2.2 is true print out that the user guessed correctly.
 3.5 If 1.2 occurs and 2.2 is false print out the user guessed incorrectly. Tell the user what the correct answer is. 
  */

public static void main(String[] args) {
 Scanner animal = new Scanner(System.in); //Create a new scanner

String myanimal="Tiger"; //A string value which is what the user is trying to guess. This is being compared to the string animalguess1 and animalguess2. If myanimal is equal to those strings the user is correct and the program ends. If the animalguess1 and myanimal variable are not the same the user is allowed a second chance. This is also used to calcuate if the animalcompare value is postive or negative.
String animalguess1; //A string value which the user inputs. This is the first guess that the user is making. This is being compared to the string myanimal. If animalguess1 is equal to myanimal the user is correct and the program ends. If the animalguess1 and myanimal variable are not the same the user is allowed a second chance. This is also used to calcuate if the animalcompare value is postive or negative.
String animalguess2; //A string value which the user inputs. This is the second guess that the user is making. This is being compared to the string myanimal. If animalguess1 is equal to myanimal the user is correct and the program ends. If the animalguess2 and myanimal variable are not the same the user is incorrect and the program ends.
int animalcompare; //An integer value which is calculated from the variables animalguess1 and myanimal. This compares the values of the two variable in order to create a postive or negative number. This is used to calculate the place each variable falls in the alphabet. THis is also used to determine if the user gets a second chance at guessing.

System.out.println("Animal Guessing Game"); //Write title for code
System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
System.out.println("I am thinking of a certain animal. Try and guess what I am thinking of below! Good Luck!(Start with a capital letter)"); //Give instructions on how to play the guessing game.
animalguess1 = animal.nextLine(); //Input for the first guess the user makes. This will be used to determine if the user answered correctly or answered incorrectly and give a second attempt.
animalcompare=myanimal.compareTo(animalguess1); //Compares the variable animalguess1 to the variable myanimal to create a new variable, animalcompare. This will be used to determine which animal comes first in the alphabet, and if the user gets a second chance at guessing. 

 if (myanimal.equals(animalguess1)) //If the user enters a string with the exact same string as the myanimal variable the statement below will be printed out.
 {
   System.out.println("Great Guess! You got the animal name right! I was thinking of a Tiger!"); //This statement will be printed out if the variable animalguess1 which is entered by the user is equal to the variable myanimal.
 }

 if (animalcompare>0) //If the variable animalcompare is greater than zero than the statement below will be printed out.
 {
   System.out.println("Sorry, that was not correct."); //This will tell the user that their choice animalguess1 was not equal to myanimal. This will be printed if the variable animal compare is greater than 0.
   System.out.println("Your animal name comes first in the alphabet."); //This will tell the user that the variable animalguess1 comes first in the alphabet compared to myanimal. This will be printed if the variable animal compare is greater than 0.
    System.out.println("Try and guess the animal name one more time!(Start with a capital letter)"); //Give instructions on how to make a second guess. This will be printed if the variable animal compare is greater than 0.
 }

 if (animalcompare<0) //If the variable animalcompare is less than zero than the statement below will be printed out.
 {
   System.out.println("Sorry, that was not correct.");//This will tell the user that their choice animalguess1 was not equal to myanimal. This will be printed if the variable animal compare is less than 0.
   System.out.println("My animal name comes first in the alphabet."); //This will tell the user that the variable myanimal comes first in the alphabet compared to animalguess1. This will be printed if the variable animal compare is less than 0.
   System.out.println("Try and guess the animal name one more time!(Start with a capital letter)"); //Give instructions on how to make a second guess. This will be printed if the variable animal compare is less than 0.
 }

 animalguess2 = animal.nextLine(); //Input for the second guess the user makes. This will be used to determine if the user answered correctly or answered incorrectly for the final time.

 if (myanimal.equals(animalguess2)) //If the user enters a string with the exact same string as the myanimal variable the statement below will be printed out.
 {
   System.out.println("Great Guess! You got the animal name right! I was thinking of a Tiger!"); //This statement will be printed out if the variable animalguess2 which is entered by the user is equal to the variable myanimal.
 }

 else //If the variable myanimal is not exactly equal to the second guess of the user under the variable animalguess2 the statement below will be printed out.
 {
   System.out.println("Sorry that was not correct. You guessed "+ animalguess1+" and "+animalguess2+". The correct answer was a Tiger."); //This statement will be printed out if the variable animalguess2 which is entered by the user is not equal to the variable myanimal.
  }
  
 }
}
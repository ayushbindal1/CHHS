import java.util.Scanner;

class Main {
  /* Random Dice Roller Pseudocode:
   Get Information:
   1.1 Get number of sides on first dice
   1.2 Get number of sides on second dice
   Do Calculations:
   2.1 Multiply side of dice with random number and then add one as the minimum amount
   2.2 Repeat 2.1 2x
   2.3 Add 2.1 and 2.2 in order to get the sum of the dice rolled
   Print Results:
   3.1 Print amount of sides found in 1.1
   3.2 Print amount of sides found in 1.2
   3.3 Print random number found in 2.1
   3.4 Print random number found in 2.2
   3.5 print sum of random numbers found in 2.3
   */
   public static void main(String[] args) {
    Scanner dice= new Scanner(System.in); //Create new scanner
    System.out.println("Random Dice Roller:"); //Write Title for code
    System.out.println("By: Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
    int dice1sides; //Sides for the first dice
    int dice2sides; //Sides for the second dice
    int randomnumber1; //Random number generated in first dice
    int randomnumber2; //Random number generated in second dice
    int sumofrandom; //Sum of the two random numbers generated from the dice
   System.out.println("Please enter the amount of sides on your first die."); //Give instructions on what to enter
   dice1sides= dice.nextInt(); //Gather response for amount of sides on first dice
   System.out.println("Please enter the amount of sides on your second die."); //Give instructions on what to enter
   dice2sides= dice.nextInt(); //Gather response for amount of sides on second dice
   randomnumber1=((int)(dice1sides*Math.random())+1); //Calculate random number by taking the sides found on the dice as the range and multipying it to the random number method. Then add one for the minimum amount that can be rolled. This should be an integer.
   randomnumber2=((int)(dice2sides*Math.random())+1); // Calculate random number by taking the sides found on the dice as the range and multipying it to the random number method. Then add one for the minimum amount that can be rolled. This should be an integer.
   sumofrandom=randomnumber1+randomnumber2; //Add the two random numbers in order to get the sum of the dice rolled
   System.out.println("Sides on first dice: "+dice1sides); //Print out amount of sides on first dice
   System.out.println("Sides on second dice: "+dice2sides); //Print out amount of sides on second dice
   System.out.println("Number rolled for first dice: " +randomnumber1); //Print out the random number found on the first dice
   System.out.println("Number rolled for second dice: " +randomnumber2); //Print out the random number found on the second dice
   System.out.println("Sum of two dice: "+sumofrandom); //Print out the sum of the random numbers found from the two dices.

  }
}
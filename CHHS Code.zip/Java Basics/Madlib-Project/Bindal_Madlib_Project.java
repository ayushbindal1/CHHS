import java.util.Scanner; //Make scanner class available
class Main {
  public static void main(String[] args) {
    
    /* Pseudocode for Madlib
   1. Gather information
   1.1 Have user type information about part of speech  that correlates with what is asked in 2.2
   1.2 Repeat 1.1 16 times
   2. Print
   2.1  Print out description of Madlib with title
   2.2 Print out a command telling what the user should enter
   2.3 Repeat 2.2 16 times
   2.4 Print out story with variables containing input
*/

  Scanner madlib= new Scanner(System.in); //Create a new scanner
 String adjective1; //First adjective in story
 String adjective2; //Second adjective in story
 String noun1; //First thing in story
 String pasttenseverb; //A verb in the past tense (Ends in ed)
 String verb1; //First present tense verb
 String thirdworldcountry; //A Third World Country
 String pluralnoun1; //First plural thing
 String place; //Any location
 String food; //Any type of food
 String pluralnoun2; //Second plural thing
 String vegetable1; //A vegetable
 String fruit1; //A fruit
 String noun2; //First noun
 String animal1; //Any animal
 String singluarcandy; //Any candy bar
 String noun3;//Second noun

  System.out.println("Madlib American Solider Diary: ");//Write title for story
  System.out.println("Ayush Bindal 3rd Period PAP Computer Science: "); //Write Name, Class Period, and Class
  System.out.println("Answer the questions in order to create a story about an American solider (Please write in lower case unless it is a proper noun): "); //Give intructions on what to do
  System.out.println("Please enter an adjective: "); // Ask user to enter an adjective
  adjective1=madlib.nextLine(); //Gather a response from the user
  System.out.println("Please enter an adjective: "); // Ask user to enter an adjective
  adjective2=madlib.nextLine(); //Gather a response from the user
  System.out.println("Please enter a noun: "); //Ask user to enter a noun
  noun1=madlib.nextLine(); //Gather a response from the user
  System.out.println("Please enter a Verb (Past Tense):"); //Ask user to enter a past tense verb
   pasttenseverb=madlib.nextLine(); //Gather a response from the user
   System.out.println("Please enter a verb: "); //Ask user to enter a verb
   verb1=madlib.nextLine(); //Gather a response from the user
   System.out.println("Please enter a Third World Country: "); //Ask user to enter a Third World Country
   thirdworldcountry=madlib.nextLine(); //Gather a response from the user
   System.out.println("Please enter a noun (Plural): ");//Ask user to enter a plural noun
   pluralnoun1=madlib.nextLine(); //Gather a response from the user
   System.out.println("Please enter a place: "); //Ask user to enter a location
   place=madlib.nextLine(); //Gather a response from the user
   System.out.println("Please enter a food: "); //Ask user to enter any food
   food=madlib.nextLine(); //Gather a response from the user
   System.out.println("Please enter a noun (Plural): "); //Ask user to enter a plural noun
   pluralnoun2=madlib.nextLine(); //Gather a response from the user
     System.out.println("Please enter a vegetable: ");//Ask user to enter a vegetable
     vegetable1=madlib.nextLine(); //Gather a response from the user
     System.out.println("Please enter a fruit: "); // Ask user to enter a fruit
     fruit1=madlib.nextLine(); //Gather a response from the user
     System.out.println("Please enter a noun: "); // Ask user to enter in a noun
     noun2=madlib.nextLine(); //Gather a response from the user
     System.out.println("Please enter a animal: "); // Ask user to enter in any animal
     animal1=madlib.nextLine(); //Gather a response from the user
     System.out.println("Please enter a candy (Singular):"); //Ask user to enter in a candy
     singluarcandy=madlib.nextLine(); //Gather a response from the user
     System.out.println("Please enter a noun: "); // Ask user to enter a noun
     noun3=madlib.nextLine(); //Gather a response from the user
     System.out.println("It was a "+adjective1+" and "+adjective2+" afternoon in the jungle. I could feel the "+noun1+" fall of my face as I "+pasttenseverb+" beside my other soliders. We were on a top-secret mission, to "+verb1+" the leader of "+thirdworldcountry+",and rescue all of the "+ pluralnoun1+"."+" We slowly inched closer and closer each day to "+ place+" where the leader of "+thirdworldcountry+" was located. We arrived at night when it was pitch black and set up a "+food+" truck in case of and ambush. The "+ pluralnoun1+" and the leader of "+thirdworldcountry+" were heavily guarded by "+pluralnoun2+" that had a "+ vegetable1+" in one hand and "+fruit1+" in the other. This would be the most diffcult thing we would have to do. When the sun started to rise slightly, we went in. We busted in through the "+noun1+" with our "+animal1+" gun and stormed the area. We quickly defeated the "+pluralnoun2+" who were no match for our "+animal1+" gun. We found the leader of "+thirdworldcountry+" but he was already gone. "+ "He looked like he consumed a "+singluarcandy+", native to the area allowing him to escape. We had taken down his reigme though and freed everyone. When we returned each solider including myself was bestowed the Medal of "+noun3+" the highest award a solider could achieve. We were heroes."); //Gather all the information that the user has entered and print that our as well as the rest of the story in order to create a madlib.
  }
}
import java.util.Scanner;

class Main {




  public static void main(String[] args) {



     System.out.println("Circle Calculator: "); 
     System.out.println("Ayush Bindal 3rd Period AP CSP\n");
     Scanner circlescanner= new Scanner(System.in);
     

     System.out.print("Please enter the radius of the circle: ");
     double radius=circlescanner.nextInt();
     circlescanner.nextLine();
    

     double circumference=2*radius*Math.PI;
     double areavalue=Math.pow(radius,2)*Math.PI;


     System.out.println("\nCircumference: "+circumference+"\nArea: "+areavalue);
     System.out.println("\n\nGoodbye!");

  

  }




}
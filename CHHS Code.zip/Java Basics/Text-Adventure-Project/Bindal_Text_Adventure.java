import java.util.Scanner;
class Main {

/* Text Adventure Pseudocode
 Get Information:
 1.1 Have user enter a number (1 or 2) that corresponds to the choice the user can make based on the story. This correlates to what to tent purchase.
 1.2 Have user enter a number (1,2, or 3) that corresponds to the choice the user can  make based on the story. This correlates to what path to take.
 1.3 Have user enter a number (1 or 2) that corresponds to the choice the user can make based on the story. This correlates to what food to eat.
 1.4 Have user enter a number (1,2, or 3) that corresponds to the choice the user can make based on the story. This correlates to what first aid should be provided.
 1.5 Have user enter a number (1 or 2) that corresponds to the choice the user can make based on the story. This correlates to what water to drink.
 1.6 Have user enter a number (1 or 2) that corresponds to the choice the user can make based on the story. This correlates to if the user should stay or go.
Print Results:
 2.1 If the user selects 1 in 1.1 print out that they have survived the decision and print out next choice to make. If the user selects 2 print out that they have died and the story ended.
 2.2 If the user selects 1 in 1.2 print out that they have survived the decision and print out next choice to make. If the user selects 2 or 3 print out that they have died and the story ended.
 2.3 If the user selects 1 in 1.3 print out that they have survived the decision and print out next choice to make. If the user selects 2 print out that they have died and the story ended.
 2.4 If the user selects 2 in 1.4 print out that they have survived the decision and print out next choice to make. If the user selects 1 or 3 print out that they have died and the story ended.
 2.5 If the user selects 2 in 1.5 print out that they have survived the decision and print out next choice to make. If the user selects 1 print out that they have died and the story ended.
 2.6 If the user selects 2 in 1.6 print out that they have survived the decision and print out next choice to make. If the user selects 1 print out that they have died and the story ended.
*/

  public static void main(String[] args) {
    Scanner Hiking = new Scanner(System.in); //Create a new scanner
    System.out.println("Hiking Text Adventure"); //Write title for code
    System.out.println("By: Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
    System.out.println("Instructions: After reading each scenario that has been presented it is your goal to decide which choice is the best and safest for the hiker. After reading enter one of the numbers that correlates to a choice you think is best for the hiker. The number follows the choice. If you survive you will face another choice. Good Luck!"); // Give instructions on how to complete the story.

    int choicetent; //Integer value for the first choice of the text adventure. This is based on what type of tent can be bought. If this variable is equal to 1 than the user will move forward otherwise the command will end.
    int choiceleftright; //Integer value for the second choice of the text adventure. This is based on what path can be taken on the trail. If this variable is equal to 1 than the user will move forward otherwise the command will end.
    int choicefood; //Integer value for the third choice of the text adventure. This is based on what food can be eaten. If this variable is equal to 1 than the user will move forward otherwise the command will end.
    int choicefirstaid; //Integer value for the fourth choice of the text adventure. This is based on what type of first aid can be performed. If this variable is equal to 2 than the user will move forward otherwise the command will end.
    int choicewater; //Integer value for the fifth choice of the text adventure. This is based on where should the user filter water from. If this variable is equal to 2 than the user will move forward otherwise the command will end.
    int choicestayorgo; //Integer value for the sixth choice of the text adventure. This is based on if the user should stay or leave. If this variable is equal to 2 than the user will finish sucessfully otherwise the command will end.

    System.out.println("You have been planning on going hiking/camping in Colorado with your friends for a while now. You are carpooling with your friend Landon until you realize that you forgot to bring a tent. You stop at the local REI along the way to pick up a tent. You and your friend have different opinions on which one you think is the safest and the best for this adventure. Do you choose to buy the Trail Hut 2 Tent for $200.00 (1) or the Ultra-Safe Secure Canvas for $75.00 (2)?"); //Tells the first part of the story and gives the first choice that the user can make based on tents.

   choicetent = Hiking.nextInt(); //Input for the number that correlates to a choice that can be made for the statement above. This number will be used below to determine if the user's character dies or moves on.
    if (choicetent == 2) //If the user enters the number 2 for the previous choice than it will print out the statement below.
    {
     System.out.println("You chose the Ultra-Safe Secure Canvas. The tent works well for a while, until a heavy wind at night pushes you into a nearby stream, giving you hypothermia until you die. The End!"); //The statement that will be printed out if the variable choicetent is equal to 2. This will end the story.
     System.exit(0); //This will prevent the user from entering more numbers which can contiune the story even if the story was supposed to end.
    }
    if (choicetent == 1) //If the user enters the number 1 for the previous choice than it will print out the statement below and give another choice the user can make.
    {
      System.out.println("You chose the Trait Hut 2 Tent. You have an amazing sleep in the tent and has been structurally sound for the past few days. You are on the trail finally and all is going well until you come across a fork in the road. Your friend Andrew says to go left but you think you should be going right. Do you go left (1), or do you go right (2), or do you go straight (3)?"); //The statement that will be printed out if the variable choicetent is equal to 1. This will give the second choice that can be made based on which path to take.
    }
     choiceleftright = Hiking.nextInt(); //Input for the number that correlates to a choice that can be made for the statement above. This number will be used below to determine if the user's character dies or moves on.
    if (choiceleftright == 2) //If the user enters the number 2 for the previous choice than it will print out the statement below.
    {
     System.out.println("You decide to go right. You continue to walk for another half a mile until you come across a very fast moving creek. You try and cross it without getting wet, only to slip and go downstream to a waterfall where you die. The End!"); //The statement that will be printed out if the variable choiceleftright is equal to 2. This will end the story.
     System.exit(0); //This will prevent the user from entering more numbers which can contiune the story even if the story was supposed to end.
    }
    if (choiceleftright == 3) //If the user enters the number 3 for the previous choice than it will print out the statement below.
    {
      System.out.println("You decide to go straight. Almost immediately after going that way you are ambushed by a pack of brown bears. You try and run away but fail and you die. The End!"); //The statement that will be printed out if the variable choice leftright is equal to 3. This will end the story.
      System.exit(0); //This will prevent the user from entering more numbers which can contiune the story even if the story was supposed to end.
    }
    if (choiceleftright == 1) //If the user enters the number 1 for the previous choice than it will print out the statement below and give another choice the user can make.
    {
     System.out.println("You decide to go left. You walk for another 3 miles with no issues and make it to camp all intact and start to set up camp. After a while you start to make dinner. Do you eat the Mystery Meat Sauce(1) or the Certified Fresh MRE Beef Stroganoff(2)?"); //The statement that will be printed out if the variable choiceleftright is equal to 1. This will give the third choice that can be made based on which food to eat.
    }
    choicefood = Hiking.nextInt(); //Input for the number that correlates to a choice that can be made for the statement above. This number will be used below to determine if the user's character dies or moves on.
    if (choicefood == 2) //If the user enters the number 2 for the previous choice than it will print out the statement below.
    {
      System.out.println("You decided to eat the MRE Beef Stroganoff. Later that night after you have started to fall asleep you feel a rumble in your stomach but think nothing of it. However, by 2:00 AM you are in so much pain until your stomach bursts and you die. The End!"); //The statement that will be printed out if the variable choicefood is equal to 2. This will end the story.
      System.exit(0); //This will prevent the user from entering more numbers which can contiune the story even if the story was supposed to end.
    }
    if (choicefood == 1) //If the user enters the number 1 for the previous choice than it will print out the statement below and give another choice the user can make.
    {
      System.out.println("You decided to eat the Mystery Meat Sauce. You found the taste to be slightly off, but didn't mind that much as you are in the woods. You go to bed and enjoy a good sleep after a hot meal. After a few hours of walking you stop to have a lunch break; however, while in the middle of your lunch break a snake appears right next to you. The snake bites and you are now in extreme pain. Do you try and suck the venom out and then apply ice (1), or should you lay down remaining calm and taking an Advil when necessary and calling for 911 (2), or should you be left behind as the others continue (Survival of The Fittest!) (3)?"); //The statement that will be printed out if the variable choicefood is equal to 1. This will give the fourth choice that can be made based on what first aid to provide.
    }
    choicefirstaid = Hiking.nextInt(); //Input for the number that correlates to a choice that can be made for the statement above. This number will be used below to determine if the user's character dies or moves on.
    if (choicefirstaid==1) //If the user enters the number 1 for the previous choice than it will print out the statement below.
    {
      System.out.println("You choose to suck out the venom and apply ice. You and your friends try to suck out the venom and are able to get some amount out before you start applying ice. This seems to cool you down but in reality, you are slowly dying. After an hour of this you eventually die. The End!"); //The statement that will be printed out if the variable choicefirstaid is equal to 1. This will end the story.
      System.exit(0); //This will prevent the user from entering more numbers which can contiune the story even if the story was supposed to end.
    }
   if (choicefirstaid==3) //If the user enters the number 3 for the previous choice than it will print out the statement below.
   {
     System.out.println("You choose to leave yourself behind as the others continue and you are following survival of the fittest. However, without any help or any first aid supplies on you, you eventually die. The End!"); //The statement that will be printed out if the variable choicefirstaid is equal to 3. This will end the story.
     System.exit(0); //This will prevent the user from entering more numbers which can contiune the story even if the story was supposed to end.
    }
   if (choicefirstaid==2) //If the user enters the number 1 for the previous choice than it will print out the statement below and give another choice the user can make.
     {
     System.out.println("You choose to try and lay down remaining as calm as possible taking an Advil once in a while until help comes. You lay down for one hour before help arrives and you are quickly and safely able to get to a hospital. There they remove the venom and after a night at the hospital you are in perfect condition. After a couple of days, you are back on the trail with the rest of the group, but need some water to drink. Do you purify the water from a clear body of water (1) or a fast-moving murky green water (2)?"); //The statement that will be printed out if the variable choicefirstaid is equal to 2. This will give the fifth that can be made based on which water to drink.
     }
    choicewater=Hiking.nextInt(); //Input for the number that correlates to a choice that can be made for the statement above. This number will be used below to determine if the user's character dies or moves on.
   if (choicewater==1) //If the user enters the number 1 for the previous choice than it will print out the statement below.
   {
     System.out.println("You chose to drink from the clear body of water. You filter the water and everything looks clear. What you don't know however is that the water is filled with viruses including Covid-19. You drink the water and a few hours later you die. The End!"); //The statement that will be printed out if the variable choicewater is equal to 1. This will end the story.
     System.exit(0); //This will prevent the user from entering more numbers which can contiune the story even if the story was supposed to end.
    }
   if (choicewater==2) //If the user enters the number 1 for the previous choice than it will print out the statement below and give another choice the user can make.
   {
      System.out.println("You chose to drink the fast-moving murky water. The water looks slightly strange after you filter it, but when you drink it nothing happens. You continue throughout the day sipping on water remaining perfectly fine. You arrive at the end of your trek; all you have to do is make it back to the small city where you started in. You were going to wait for a car to pick you up, but they have not arrived yet. Do you try and head back to the town yourself (1) or should you wait for the car to pick you up (2)?"); //The statement that will be printed out if the variable choicewater is equal to 2. This will give the sixth and final choice that can be made based on if the user should stay or go.
   }
    choicestayorgo=Hiking.nextInt(); //Input for the number that correlates to a choice that can be made for the statement above. This number will be used below to determine if the user's character dies or moves on.
    if (choicestayorgo==1) //If the user enters the number 1 for the previous choice than it will print out the statement below.
    {
     System.out.println("You chose to try and walk back to town yourself. You are doing well for a while but it seems there is no end in sight. You look at the map again and realize that you are back on the trail, but this time you are lost and stranded out in the woods forever where you will eventually die. The End!"); //The statement that will be printed out if the variable choicestayorgo is equal to 1. This will end the story.
     System.exit(0); //This will prevent the user from entering more numbers which can contiune the story even if the story was supposed to end.
    }
   if (choicestayorgo==2) //If the user enters the number 2 for the previous choice than it will print out the statement below.
   {
     System.out.println("You chose to wait for a car to pick you up. A half hour passes and you are worried that no one is going to pick you up. After waiting for another 5 mintues though a car arrives and you make safely back to the town and then home."); //The statement that will be printed out if the variable choicestayorgo is equal to 2. This will end the story with a successful ending.
     System.out.println("Congratulations you made it through your trek safely with only a few issues. You enjoyed your time there and hope to do it again later. The End!"); //The statement that will be printed out if the variable choicestayorgo is equal to 2. This will end the story with a successful ending.
    }
  }
}
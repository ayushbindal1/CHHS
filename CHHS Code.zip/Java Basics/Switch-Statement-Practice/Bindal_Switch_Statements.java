import java.util.Scanner;

class Main {

 /* Switch Statement Psuedocode:
 Get Information:
 1.1 Have the user enter in the first test grade
 1.2 Repeat 1.1 two more times in order to get all three test grades
 Do Calculations:
 2.1 Take the three test scores found in 1.2 and add them together and divide by three to get the average of the scores. This is under the variable scoreaverage.
 2.2 Take the number from 2.1 and use the int to round the value to the nearest integer value.
 2.3 Take the value found in 2.2 and divide it by 10 in order to get the integer tenthscoreaverage used in a switch statement.
 Print Results:
 3.1 Based on the value calcuated from 2.3 a certain message will show up. If the value is from 1-5 the letter grade is a F. 6 is a D, 7 is a C, 8 is a B. 9 and 10 are an A letter grade. 
 3.2 Print the average the user gained on the test using the value calculated in 2.2.
  */

 public static void main(String[] args) {
 Scanner testaverage= new Scanner(System.in); //Create a new scanner

double testgrade1; //A double value. The user inputs this number and serves as the first test grade for the user. This will be used to calculate the average which can be used to find the letter grade.
double testgrade2; //A double value. The user inputs this number and serves as the second test grade for the user. This will be used to calculate the average which can be used to find the letter grade.
double testgrade3; //A double value. The user inputs this number and serves as the third test grade for the user. This will be used to calculate the average which can be used to find the letter grade.
int scoreaverage; //An integer value. This is calculated by taking the average of the variables: testgrade1, testgrade2, and testgrade3. This creates an average number the user will see at the end. This will also be used to find the letter value.
int tenthscoreaverage; //An integer value. This is calcuated by taking the variable scoreaverage and dividing it by 10. This allows for a switch statement that is much more condensed. This prevents 100 cases for a single switch. This is because if it falls between the range of a certain value they act as a regular range just scaled down.

 System.out.println("Test Average Switch Statement"); //Write title for code
  System.out.println("Ayush Bindal 5th Period PAP CS");
  //Write Name, Class Period, and Class

  System.out.println("Please enter your first test grade."); //Give instructions for what the user should enter
 testgrade1=testaverage.nextDouble(); //Allows the user to enter in a double number for the first test grade. This will be used to calculate the average which can find the letter grade.
  System.out.println("Please enter your second test grade."); //Give instructions for what the user should enter
 testgrade2=testaverage.nextDouble(); //Allows the user to enter in a double number for the first second grade. This will be used to calculate the average which can find the letter grade.
 System.out.println("Please enter your third test grade."); //Give instructions for what the user should enter
 testgrade3=testaverage.nextDouble(); //Allows the user to enter in a double number for the third test grade. This will be used to calculate the average which can find the letter grade.

 scoreaverage=(int)((testgrade1+testgrade2+testgrade3)/3);// This calculates the average for the three test grades by adding each score of the tests and dividing by how many tests were taken. Then it is rounded to closest integer as switch commands as shown in line 29 can use int values rather than double values.
 tenthscoreaverage=(scoreaverage/10); //Divides the test average by 10 in order to create a smaller range for the switch statement. This prevents creating 100 seperate cases. This integer tenthscoreaverage is what is being used to find the letter grade.

 switch(tenthscoreaverage) //Creates a switch statement that will print out the statment that corresponds to the value of the variable tenthscoreaverage. Ex: tenthscoreaverage=5 will print out case 5
 {
   case 1:System.out.println("You have a letter grade of F. Your average was: "+scoreaverage); //The statement will print out if the variable tenthsscoreaverage is equal to 1. This is equal to a average of 10. 
     break; //Prevents all of the cases below this from occuring. This prevents a user from getting two responses that contradict each other

   case 2:System.out.println("You have a letter grade of F. Your average was: "+scoreaverage); //The statement will print out if the variable tenthsscoreaverage is equal to 2. This is equal to a average of 20. 
     break; //Prevents all of the cases below this from occuring. This prevents a user from getting two responses that contradict each other

   case 3:System.out.println("You have a letter grade of F. Your average was: "+scoreaverage); //The statement will print out if the variable tenthsscoreaverage is equal to 3. This is equal to a average of 30. 
     break; //Prevents all of the cases below this from occuring. This prevents a user from getting two responses that contradict each other

   case 4: System.out.println("You have a letter grade of F. Your average was: "+scoreaverage); //The statement will print out if the variable tenthsscoreaverage is equal to 4. This is equal to a average of 40. 
     break; //Prevents all of the cases below this from occuring. This prevents a user from getting two responses that contradict each other

   case 5: System.out.println("You have a letter grade of F. Your average was: "+scoreaverage); //The statement will print out if the variable tenthsscoreaverage is equal to 5. This is equal to a average of 50. 
     break; //Prevents all of the cases below this from occuring. This prevents a user from getting two responses that contradict each other

   case 6: System.out.println("You have a letter grade of D. Your average was: "+scoreaverage); //The statement will print out if the variable tenthsscoreaverage is equal to 6. This is equal to a average of 60. 
     break; //Prevents all of the cases below this from occuring. This prevents a user from getting two responses that contradict each other

   case 7: System.out.println("You have a letter grade of c. Your average was: "+scoreaverage);
    //The statement will print out if the variable tenthsscoreaverage is equal to 7. This is equal to a average of 70. 
     break; //Prevents all of the cases below this from occuring. This prevents a user from getting two responses that contradict each other

   case 8: System.out.println("You have a letter grade of B. Your average was: "+scoreaverage); //The statement will print out if the variable tenthsscoreaverage is equal to 8. This is equal to a average of 80. 
     break; //Prevents all of the cases below this from occuring. This prevents a user from getting two responses that contradict each other

   case 9: System.out.println("You have a letter grade of A. Your average was: "+scoreaverage); //The statement will print out if the variable tenthsscoreaverage is equal to 9. This is equal to a average of 90. 
     break; //Prevents all of the cases below this from occuring. This prevents a user from getting two responses that contradict each other

   case 10:  System.out.println("You have a letter grade of A. Your average was: "+scoreaverage); //The statement will print out if the variable tenthsscoreaverage is equal to 10. This is equal to a average of 100. 
     break; //Prevents all of the cases below this from occuring. This prevents a user from getting two responses that contradict each other
  

  }
 }
}
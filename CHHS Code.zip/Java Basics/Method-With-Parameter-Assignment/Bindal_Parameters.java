
/* Parameters Psuedocode
 1. Get Information:
   1.1 Have the user enter a string value for the first method
   1.2 Have the user enter two integer values for the random method
   1.3 Have the user enter three double values for the rectangularprism method
   1.4 Have the user enter either true/false or a boolean statement for the boolean method
 2. Do Calculations: 
   2.1 Take two integer values in 1.2 and create a random number between the two values
   2.2 Multiply the three double values in 1.3 to find get the volume for the rectangular prism
 3. Print Results:
   3.1 Print string values in 1.1 
   3.2 Print random number calculated in 2.1
   3.3 Print the volume of the rectangluar prism calcualated in 2.2 
   3.4 If the statement in 1.4 is a true statement print that "They did a Good Job!" If the statement in 1.4 is a false statement print that "They failed!"
*/


class Main {

 public void methodone(String stringone) //Creates a new method with a string parameter
 {
   System.out.println("Hello, "+stringone+" how are you doing today, "+stringone+". Have a great day "+stringone+"."); //Prints out following statement
 }


 public void random(int randomone, int randomtwo) //Creates a new method with two integer parameters
 {
   int randomvalue=(int)(randomtwo*Math.random()+randomone); //Creates a new variable for a random number between the two parameters in line 21
   System.out.println("A random number between the two values the user entered: "+randomvalue); //Prints out following statement
 }


 public void rectangularprism(double length, double width, double height) //Creates a new method with three double parameters
 {
   double rectangularprismvolume=(length*width*height); //Creates a new variable for the volume and assigns it a value.
   System.out.println("The volume of a rentagular prism with the values the user entered: "+rectangularprismvolume); //Prints out following statement
 }

 
 public void booleanmethod(boolean booleanstatement) //Creates a new method with a boolean parameter
 {
   if (booleanstatement) //If the variable is true than the following statement prints out
   {
     System.out.println("You entered a "+booleanstatement+" statement! Great Job!"); //Prints out following statement
   }
   else //If the variable is false than the following statement prints out
   {
     System.out.println("You entered a "+booleanstatement+" statement! You failed!"); //Prints out the following statement
   }
 }


  public static void main(String[] args) {
   System.out.println("Void Methods"); //Write title for code
   System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
   System.out.println(""); //Add a space between lines
   Main run = new Main(); //Creating an object of this class


   System.out.println("String Value Method: "); //Gives Title for Method
   run.methodone(stringone);  //Calling methodone method with a string parameter
   System.out.println(""); //Add a space between lines


   System.out.println("Random Number Value Method: "); //Gives Title for Method
   run.random(randomone, randomtwo); //Calling random method with two integer parameter
   System.out.println(""); //Add a space between lines

   System.out.println("Rectangluar Prism Method: "); //Gives Title for Method
   run.rectangularprism(length, width, height); //Calling rectangularprism method with three double parameters
   System.out.println(""); //Add a space between lines

   System.out.println("Boolean Statement Method: "); //Gives Title for Method
   run.booleanmethod(booleanstatement); //Calling booleanmethod method with a boolean parameter


  }
}
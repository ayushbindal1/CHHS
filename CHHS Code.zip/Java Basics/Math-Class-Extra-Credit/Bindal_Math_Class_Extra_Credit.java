import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    System.out.println("Circle Circumference and Area Calculator: ");
    Scanner circle= new Scanner(System.in);
    double radius;
    System.out.println("Please enter the length of the radius:");
    radius=circle.nextDouble();
   System.out.println("Circumference: " +((Math.PI)*2*radius));
   System.out.println("Area of Circle: "+(Math.pow(radius,2)*(Math.PI)));

  }
}
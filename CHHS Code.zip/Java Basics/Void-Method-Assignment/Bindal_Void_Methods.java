import java.util.Scanner;

/* Void Methods Psuedocode
 Get Information:
   1.1 Have the user enter their name.
   1.2 Have the user enter their age.

 Print Results:
   2.1 Print information in 1.1.
   2.2 Print information in 1.2

*/

class Main {


 public String username; //Creates global variable to hold information
 public int age; //Creates global variable to hold information


 public void Intro() //Creates a new method
 {
   System.out.println("Void Methods"); //Write title for code
    System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class
   System.out.println("Hello, nice to meet you!"); //Prints out statement.
 }


 public void Input() //Creates a new method
 {
   Scanner voidmethod= new Scanner(System.in); //Creates a new scanner
   System.out.print("Please enter your name: "); //Prints out instructions.
   username=voidmethod.nextLine(); //Allows user to enter information
   System.out.print("Please enter your age: "); //Prints out instructions.
   age=voidmethod.nextInt(); //Allows user to enter information
 }


 public void PrintInfo() //Creates a new method
 {
   System.out.println("Hello "+username+". Hope you are doing well!"); //Prints out statement.
   System.out.println("According to what you have told us you are "+age+" year(s) old."); //Prints out statement.
 }


  public static void main(String[] args)
   {
     Main run = new Main();
     run.Intro(); //Calling Intro Method
     run.Input(); //Calling Input Method
     run.PrintInfo(); //Calling PrintInfo Method
  }
}
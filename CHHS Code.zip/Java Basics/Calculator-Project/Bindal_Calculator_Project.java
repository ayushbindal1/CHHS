import java.util.Scanner; //Imports scanner

/* Calculator Project Psuedocode:


1. Get Information:
  1.1 Allow user to enter integer value for what calculator operation they want to do.
  1.2 If the value in 1.1 is equal to 1 have the user enter in two double values for the add method 
 1.3 If the value in 1.1 is equal to 2 have the user enter in two double values for the subtract method
 1.4 If the value in 1.1 is equal to 3 have the user enter in two double values for the multiply method
 1.5 If the value in 1.1 is equal to 4 have the user enter in two double values for the divide method 
 1.6 If the value in 1.1 is equal to 5 have the user enter in one double value for the square method
 1.7 If the value in 1.1 is equal to 6 have the user enter in one double value for the cube method  
 1.8 If the value in 1.1 is equal to 7 have the user enter in four double values for (X1,Y1) and (X2,Y2) for the distance method
 1.9 If the value in 1.1 is equal to 8 have the user enter in three double values for the quadrootpositive and quadrootnegative method
 1.10 If the value in 1.1 is equal to 9 have the user enter in one double value for the circumference and areaofcircle method
 1.11 If the value in 1.1 is equal to 10 have the user enter in two double values for the hypotenuse method
 1.12 After the user has done an operation have the user enter 1 to continue to use the calculator. If they do not enter one end the program


2. Do Calculations:
 2.1 If user chooses 1.2 Sum=num1+num2
 2.2 If user chooses 1.3 Difference=num1-num2
 2.3 If user chooses 1.4 Product=num1*num2
 2.4 If user chooses 1.5 Quotient=num1/num2
 2.5 If user chooses 1.6 Square=num1^2
 2.6 If user chooses 1.7 Cube=num1^3
 2.7 If user chooses 1.8 Distance=Math.sqrt((X2-X1)^2+(Y2-Y1)^2)
 2.8 If user chooses 1.9 Quadrootpostive=(-b+Math.sqrt(b^2-4*a*c))/(2*a) and Quadrootnegative=(-b-Math.sqrt(b^2-4*a*c))/(2*a)
 2.9 If user chooses 1.10 Circumference=2*Math.PI*Radius and AreaofCircle=Math.PI*Radius^2
 2.10 If the user chooses 1.11 Hypotenuse=Math.sqrt(sidea^2+sideb^2)


3. Print Result:
 3.1 If user entered 1 in 1.1 return the Sum calculated in 2.1
 3.2 If user entered 2 in 1.1 return the Difference calculated in 2.2
 3.3 If user entered 3 in 1.1 return the Product calculated in 2.3
 3.4 If user entered 4 in 1.1 return the Quotient calculated in 2.4
 3.5 If user entered 5 in 1.1 return the Square calculated in 2.5
 3.6 If user entered 6 in 1.1 return the Cube calculated in 2.6
 3.7 If user entered 7 in 1.1 return the Distance calculated in 2.7
 3.8 If user entered 8 in 1.1 return the Quadrootpostive and Quadrootnegative calculated in 2.8
 3.9 If user entered 9 in 1.1 return the Circumference and AreaofCircle calculated in 2.9
 3.10 If user entered 10 in 1.1 return the Hypotenuse calculated in 2.10
 3.11 If the user entered 1 in 1.12 rerun the program from 1.1. If the user entered anything but 1 in 1.12 exit the program and tell them the caluclator is over.



*/



class Main {



 public double add(double numadd1, double numadd2) //Creates a new method that takes in two double values and returns the sum of the two values
 {
   double addanswer=numadd1+numadd2; //Caclulates sum of two double parameters
   return addanswer; //Returns double sum value 
 }



 public double subtract(double numsubtract1, double numsubtract2) //Creates a new method that takes in two double values and returns the difference of the two values
 {
   double subtractanswer=numsubtract1-numsubtract2; //Calculates difference of two double parameters
   return subtractanswer; //Returns double difference value
 }



 public double multiply(double nummultiply1, double nummultiply2) //Creates a new method that takes in two double values and returns the product of the two values
 {
   double multiplyanswer=nummultiply1*nummultiply2; //Calculates the product of the two double parametrs
   return multiplyanswer; //Returns double product value
 }



 public double divide(double numdivide1, double numdivide2) //Creates a new method that takes in two double values and returns the quotient of the two values
 {
   double divideanswer=numdivide1/numdivide2; //Calculates the quotient of the two double parameters
   return divideanswer; //Returns double quotient value
 }



 public double squared(double numsquared1) //Creates a new method that takes in one double value and returns the squared value of the parameter
 {
   double squaredanswer=(Math.pow(numsquared1, 2)); //Calculates the squared value of the double parameter
   return squaredanswer; //Returns the double squared value
 }



 public double cubed(double numcubed1) //Creates a new method that takes in one double value and returns the cubed value of the parameter
 {
   double cubedanswer=(Math.pow(numcubed1, 3)); //Calculates the cubed value of the double parameter
   return cubedanswer; //Returns the double cubed value
 }



 public double distance(double x1, double y1, double x2, double y2) //Creates a new method that takes in four double values for coordinates x and y postions and retunrns the distance between the (X1,Y1) and (X2,Y2)
 {
   double distanceanswer=(Math.sqrt(Math.pow(x2-x1, 2)+(Math.pow(y2-y1,2)))); //Calculates the distance between the four double values entered  (X1,Y1) and (X2,Y2).
   return distanceanswer; //Returns the double distance value
 }



 public double quadrootpositive(double a, double b, double c) //Creates a method that takes in three double values and returns the postive quadratic root of those values.
 {
   double quadrootpositiveanswer=(((-1*b)+Math.sqrt((Math.pow(b, 2))-(4*a*c)))/(2*a)); //Calculates the postive value of the quadratic root as there is a plus or minus sign in the formula using the three double values for a, b, and c
   return quadrootpositiveanswer; //Returns the double postive quadratic root value
 }

 public double quadrootnegative(double a, double b, double c) //Creates a method that takes in three double values and returns the negative quadratic root of those values.
 {
   double quadrootnegativeanswer=(((-1*b)-Math.sqrt((Math.pow(b, 2))-(4*a*c)))/(2*a)); //Calculates the negative value of the quadratic root as there is a plus or minus sign in the formula using the three double values for a, b, and c
   return quadrootnegativeanswer; //Returns the double negative quadratic root value
 }



 public double circumference(double radius) //Creates a new method that takes in one double value for the radius and returns the circumference of the circle.
 {
   double circumferenceanswer=(2*radius*Math.PI); //Calculates the circumference of the circle using the double radius value
   return circumferenceanswer; //Returns the double circumference value
 }

 public double areaofcircle(double radius) //Creates a new method that takes in one double value for the radius and returns the area of the circle.
 {
   double areaofcircleanswer=Math.PI*(Math.pow(radius, 2)); //Calculates the area of the circle using the double radius value
   return areaofcircleanswer; //Returns the double area of circle value
 }



 public double hypotenuse(double sidea, double sideb) //Creates a new method that takes in two double values for the sides of a right triangle and returns the hypotenuse
 {
   double csquared=(Math.pow(sidea, 2)+Math.pow(sideb, 2)); //Calculates the c squared value which is used to calculate the hypotenuse
   double hypotenuseanswer=Math.sqrt(csquared); //Takes the square root of the c squared value to calculate the hypotenuse.
   return hypotenuseanswer; //Returns the double hypotenuse length
 }



 public void menu() //Creates a method that runs all the other methods based on what the user wants. It is a menu
 {
   int calculatorloop=0; //Create variable to hold information. Used for looping the calculator
   int calculatortask=0; //Creaate variable to hold information. Used to determine which operation the user wants to do.
   System.out.println("1. Add, 2. Subtract, 3. Multiply, 4. Divide, 5. Square, 6. Cube, 7. Distance between Points, 8. Quadratic Root, 9. Area and Circumference of a Circle, 10. Hypotenuse"); //Prints out number values that coorespond to the different operations the user can choose.
   System.out.println("Calculator: "); //Prints out title



   do{ //Creates a do while loop
     Scanner calculator= new Scanner(System.in); //Create scanner for input
     System.out.println(""); //Add a space between lines
      System.out.print("Please enter the number that cooresponds with the calculator operation you want to do as shown above: "); //Prints out instructions for what the user should enter
     calculatortask=calculator.nextInt(); //Allows user to enter integer value to determine which operation the user wants to use


      if(calculatortask==1) //If the calculator task that the user entered is equal to 1 then it will print the following statement and run the add method
      {
        System.out.println(""); //Add a space between lines
        System.out.println("You chose the add operation."); //States what operation the user chose

        System.out.print("Please enter the first number: "); //Prints out instructions for what the user should enter
        double numadd1=calculator.nextDouble(); //ALlows user to enter first double value to be used in the add method

        System.out.print("Please enter the second number: "); //Prints out instructions for what the user should enter
        double numadd2=calculator.nextDouble(); //ALlows user to enter second double value to be to be used in the add method

        System.out.println("The sum of the two numbers entered: "+(add(numadd1, numadd2))); //Prints out following statement and calls the add method with two parameters entered
      }


      if(calculatortask==2) //If the calculator task that the user entered is equal to 2 then it will print the following statement and run the subtract method
      {
        System.out.println(""); //Add a space between lines
        System.out.println("You chose the subtract operation."); //States what operation the user chose

        System.out.print("Please enter the first number: "); //Prints out instructions for what the user should enter
        double numsubtract1=calculator.nextDouble(); //ALlows user to enter first double value to be used in the subtract method 

        System.out.print("Please enter the second number: "); //Prints out instructions for what the user should enter
        double numsubtract2=calculator.nextDouble(); //ALlows user to enter second double value to be used in the subtract method

        System.out.println("The difference of the two numbers entered: "+(subtract(numsubtract1, numsubtract2))); //Prints out following statement and calls the subtract method with two parameters entered
      }


      if(calculatortask==3) //If the calculator task that the user entered is equal to 3 then it will print the following statement and run the multiply method
      {
        System.out.println(""); //Add a space between lines
        System.out.println("You chose the multiply operation.");

        System.out.print("Please enter the first number: "); //Prints out instructions for what the user should enter
        double nummultiply1=calculator.nextDouble(); //ALlows user to enter first double value to be used in the multiply method

        System.out.print("Please enter the second number: "); //Prints out instructions for what the user should enter
        double nummultiply2=calculator.nextDouble(); //ALlows user to enter second double value to be used in the multiply method

        System.out.println("The product of the two numbers entered: "+(multiply(nummultiply1, nummultiply2))); //Prints out following statement and calls the multiply method with two parameters entered
      }


      if(calculatortask==4) //If the calculator task that the user entered is equal to 4 then it will print the following statement and run the divide method
      {
        System.out.println(""); //Add a space between lines
        System.out.println("You chose the divide operation."); //States what operation the user chose

        System.out.print("Please enter the first number: "); //Prints out instructions for what the user should enter
        double numdivide1=calculator.nextDouble(); //Allows user to enter first double value to be used in the divide method

        System.out.print("Please enter the second number: "); //Prints out instructions for what the user should enter
        double numdivide2=calculator.nextDouble(); //ALlows user to enter first double value to be used in the divide method

        System.out.println("The quotient of the two numbers entered: "+(divide(numdivide1, numdivide2))); //Prints out following statement and calls the divide method with two parameters entered
      }


      if(calculatortask==5) //If the calculator task that the user entered is equal to 5 then it will print the following statement and run the squared method
      {
        System.out.println(""); //Add a space between lines
        System.out.println("You chose the square operation."); //States what operation the user chose

        System.out.print("Please enter the number you want to square: "); //Prints out instructions for what the user should enter
        double numsquared1=calculator.nextDouble(); //ALlows user to enter double value to be used in the squared method

        System.out.println("The squared value of the number entered: "+(squared(numsquared1))); //Prints out following statement and calls the squared method with one parameter entered
      }


      if(calculatortask==6) //If the calculator task that the user entered is equal to 6 then it will print the following statement and run the cubed method
      {
        System.out.println(""); //Add a space between lines
        System.out.println("You chose the cube operation."); //States what operation the user chose

        System.out.print("Please enter the number you want to cube: "); //Prints out instructions for what the user should enter
        double numcubed1=calculator.nextDouble(); //ALlows user to enter double value to be used in the cubed method

        System.out.println("The cubed value of the number entered: "+(cubed(numcubed1))); //Prints out following statement and calls the cubed method with one parameter entered
      }


    if(calculatortask==7) //If the calculator task that the user entered is equal to 7 then it will print the following statement and run the distance method
      {
        System.out.println(""); //Add a space between lines
        System.out.println("You chose the distance between two coordinates operation."); //States what operation the user chose

        System.out.print("Please enter the first point's x value (X1): "); //Prints out instructions for what the user should enter
        double x1=calculator.nextDouble(); //Allows user to enter X1 postion double value to be used in the distance method

         System.out.print("Please enter the first point's y value (Y1): "); //Prints out instructions for what the user should enter
        double y1=calculator.nextDouble(); //Allows user to enter Y1 postion double value to be used in the distance method

         System.out.print("Please enter the second point's x value (X2): "); //Prints out instructions for what the user should enter
        double x2=calculator.nextDouble(); //Allows user to enter X2 postion double value to be used in the distance method

         System.out.print("Please enter the second point's y value (Y2): "); //Prints out instructions for what the user should enter
        double y2=calculator.nextDouble(); //Allows user to enter Y2 postion double value to be used in the distance method

        System.out.println("The distance of the two coordinates entered: "+(distance(x1, y1,x2,y2))); //Prints out following statement and calls the distance method with four parameters entered
      }


      if(calculatortask==8) //If the calculator task that the user entered is equal to 8 then it will print the following statement and run both the quadrootpostive and quadrootnegative method
      {
        System.out.println(""); //Add a space between lines
        System.out.println("You chose the quadratic root operation."); //States what operation the user chose

        System.out.print("Please enter the a value from the equation: "); //Prints out instructions for what the user should enter
        double a=calculator.nextDouble(); //Allows user to enter a double value to be used in both the quadrootpostive and quadrootnegative methods

        System.out.print("Please enter the b value from the equation: "); //Prints out instructions for what the user should enter
        double b=calculator.nextDouble(); //Allows user to enter b double value to be used in both the quadrootpostive and quadrootnegative methods

        System.out.print("Please enter the c value from the equation: "); //Prints out instructions for what the user should enter
        double c=calculator.nextDouble(); //Allows user to enter c double value to be used in both the quadrootpostive and quadrootnegative methods

        System.out.println("The postive quadratic root of the values entered: "+(quadrootpositive(a, b, c))); //Prints out following statement and calls the quadrootpositive method with three parameters entered as the quadratic root has a plus or minus

        System.out.println("The negative quadratic root of the values entered: "+(quadrootnegative(a, b, c))); //Prints out following statement and calls the quadrootpositive method with three parameters entered as the quadratic root has a plus or minus
      }


      if(calculatortask==9) //If the calculator task that the user entered is equal to 9 then it will print the following statement and run both the circumference and areaofcircle methods
      {
        System.out.println(""); //Add a space between lines
        System.out.println("You chose the circumference and area of a circle operation."); //States what operation the user chose

        System.out.print("Please enter the radius of the circle: "); //Prints out instructions for what the user should enter
        double radius=calculator.nextDouble(); //Allows user to enter radius double value to be used in both the circumference and areaofcircle methods

        System.out.println("The circumference of the radius entered: "+(circumference(radius))); //Prints out following statement and calls the circumfernce method with one parameter entered

        System.out.println("The area of the circle of the radius entered: "+(areaofcircle(radius))); //Prints out following statement and calls the areaofcircle method with one parameter entered
      }


      if(calculatortask==10) //If the calculator task that the user entered is equal to 10 then it will print the following statement and run the hypotenuse method
      {
        System.out.println(""); //Add a space between lines
        System.out.println("You chose the hypotenuse operation."); //States what operation the user chose

        System.out.print("Please enter the length of side a: "); //Prints out instructions for what the user should enter
        double sidea=calculator.nextDouble(); //Allows user to enter side a double value to be used in the hypotenuse method

        System.out.print("Please enter the length of side b: "); //Prints out instructions for what the user should enter
        double sideb=calculator.nextDouble(); //Allows user to enter side b double value to be used in the hypotenuse method

        System.out.println("The hypotenuse of the two sides entered: "+(hypotenuse(sidea, sideb))); //Prints out following statement and calls the hypotenuse method with two parameter entered

      }


     System.out.println(""); //Add a space between lines
     System.out.print("Enter 1 to do another calculation. Enter any other number to quit: "); //Prints out instructions for what the user should enter
     calculatorloop=calculator.nextInt(); //Allows user to enter an integer value that if !=1 will end the loop allowing the user to do multiple operations 
     System.out.println(""); //Adds space between line.


    }while (calculatorloop==1); //Contiunes to run the program until the statement becomes false. This means that the user entered any other number besides 1 which means they are done using the calculator


   System.out.println("Thank you for using the calculator!"); //Prints out following statement if user enters any number besides 1 on the calculator loop. This ends the program
 }



  public static void main(String[] args) {
    System.out.println(""); //Add a space between lines
   System.out.println("Calculator Project: "); //Write title for code
   System.out.println("Ayush Bindal 5th Period PAP CS"); //Write Name, Class Period, and Class

   Main run=new Main(); //Creating an object of this class
   run.menu(); //Calls the menu method which stores all the information about the calculator and the operations.
  }
} 
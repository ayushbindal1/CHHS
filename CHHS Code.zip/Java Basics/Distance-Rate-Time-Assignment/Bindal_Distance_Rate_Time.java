class Main {
  public static void main(String[] args) {
    double RateofTravel=0.0;
    double Timetraveled=0.0;
    double Distancetraveled=0.0;
    Distancetraveled=RateofTravel*Timetraveled;
    System.out.println("Rate of Travel: "+RateofTravel+ "MPH " +" Time Traveled: "+Timetraveled+"Hr(s)");
    System.out.println("Distance Traveled: "+Distancetraveled+ " mile(s)");
  }
}
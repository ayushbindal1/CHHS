import java.util.Scanner;

class Main {




  public static void main(String[] args) {



   System.out.println("Interest Calculator: "); 
   System.out.println("Ayush Bindal 3rd Period AP CSP\n");
   Scanner interestscanner= new Scanner(System.in);


   int choicevalue=0;

   double finalamount=0;
   double principalvalue=0;
   double interestrate=0;
   double years=0;

   double interestperperiod=0;


   System.out.print("1. Simple Interest\n2. Compound Interest\nPlease enter the number that cooresponds with what you want to solve for: ");
   choicevalue=interestscanner.nextInt();
   interestscanner.nextLine();



      if(choicevalue==1)
      {


           System.out.println("\n\nYou chose to do simple interest!\n");
           

           System.out.print("Please enter the principal value: ");
           principalvalue=interestscanner.nextDouble();
           interestscanner.nextLine();


           System.out.print("\nPlease enter the interest rate (Percentage): ");
           interestrate=interestscanner.nextDouble();
           interestscanner.nextLine();


           System.out.print("\nPlease enter the amount of time in years: ");
           years=interestscanner.nextDouble();
           interestscanner.nextLine();


           finalamount=principalvalue*(1+((interestrate/100)*years));

           System.out.println("\nFinal Amount: "+finalamount+"\n\n");


      }


       else if(choicevalue==2)
       {


           System.out.println("\n\nYou chose to do compound interest!\n");


           System.out.print("Please enter the principal value: ");
           principalvalue=interestscanner.nextDouble();
           interestscanner.nextLine();


           System.out.print("\nPlease enter the interest rate (Percentage): ");
           interestrate=interestscanner.nextDouble();
           interestscanner.nextLine();


           System.out.print("\nPlease enter the amount of time in years: ");
           years=interestscanner.nextDouble();
           interestscanner.nextLine();
           

           System.out.print("\nPlease enter the amount of times per year this is compounded: ");
           interestperperiod=interestscanner.nextDouble();
           interestscanner.nextLine();


           finalamount=principalvalue*Math.pow((1+((interestrate/100)/interestperperiod)),(interestperperiod*years));

           System.out.println("\nFinal Amount: "+finalamount+"\nInterest Gained: "+(finalamount-principalvalue));    


       }
   System.out.println("\n\nGoodbye!");  


  }




}
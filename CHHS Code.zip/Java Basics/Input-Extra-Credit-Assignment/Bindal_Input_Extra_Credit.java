import java.util.*;
class Main {
  public static void main(String[] args) {
   Scanner extra=new Scanner(System.in);
   double principal; //5.
   double rate; //5.
   double time; //5.
   double Finalamount; //5.
   double totalinterest; //5.
   System.out.println("Simple Interest Calculator:"); //5.
   System.out.println("Please enter your intital or principal amount."); //5.
   principal=extra.nextInt(); //5.
  System.out.println("Please enter the annual interest rate in percent form."); //5.
 rate=extra.nextDouble(); //5.
System.out.println("Please enter the amount of time in years."); //5.
time=extra.nextInt(); //5.
 Finalamount=principal*(1+(rate/100.00)*time); //5.
 totalinterest=principal*(rate/100.00)*time; //5.
 System.out.println("Total Interest: "+ totalinterest); //5.
 System.out.println("Final Amount: "+ Finalamount); //1.
 System.out.println("Faherenheit to Celsius Calculator:");  //1.
 double celsius; //1.
 double fahrenheit; //1.
 System.out.println("Please enter fahrenheit temperature: "); //1.
 fahrenheit=extra.nextInt(); //1.
 celsius=(5.0/9.0)*(fahrenheit-32); //1.
 System.out.println("Fahrenheit Temperature: "+fahrenheit); //1.
 System.out.println("Celsius Temperature: "+celsius); //1.
 System.out.println("Volume of Cylinder Calculator:"); //4.
 double radius; //4.
 double height; //4.
 double volume; //4.
 System.out.println("Please enter the radius length:"); //4.
 radius=extra.nextDouble(); //4.
 System.out.println("Please enter the height:"); //4.
height=extra.nextDouble(); //4.
volume=3.141*radius*radius*height; //4.
System.out.println("Radius: "+radius); //4.
System.out.println("Height: "+height); //4.
System.out.println("Volume of Cyclinder: "+volume); //4.
  }
}